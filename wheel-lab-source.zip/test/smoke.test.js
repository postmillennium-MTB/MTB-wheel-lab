// Runtime smoke test: loads the actual built dist/index.html into a
// simulated DOM and confirms the app mounts and renders real content
// without throwing. This is the strongest automated check available
// without a real browser -- it exercises the whole render tree (all
// four tabs' initial state), not just syntax.
import { JSDOM } from "jsdom";
import { readFileSync } from "node:fs";

const html = readFileSync(new URL("../dist/index.html", import.meta.url), "utf-8");

// jsdom doesn't implement ResizeObserver (used by Recharts' ResponsiveContainer);
// stub it so charts render at a fixed size instead of erroring.
class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}

// A real URL (rather than jsdom's default about:blank) so the app's
// hash <-> tab sync (history.replaceState on tab change) has somewhere
// valid to rewrite -- about:blank makes jsdom's History implementation
// throw, which the app's own try/catch there guards against, but giving
// a real URL here means this test still exercises that feature for real.
const dom = new JSDOM(html, { url: "https://example.com/wheel-lab/", runScripts: "dangerously", resources: "usable" });
dom.window.ResizeObserver = ResizeObserverStub;

// Recharts' ResponsiveContainer reads getBoundingClientRect for sizing.
dom.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});

let caughtError = null;
dom.window.addEventListener("error", (e) => {
  caughtError = e.error || e.message;
});

// give React a tick to render
await new Promise((resolve) => setTimeout(resolve, 300));

const root = dom.window.document.getElementById("root");

function fail(message) {
  console.error("Smoke test FAILED:", message);
  if (caughtError) console.error(caughtError);
  dom.window.close();
  process.exit(1);
}

if (!root || root.textContent.length === 0) fail("#root has no rendered content after initial mount.");
if (caughtError) fail("runtime error during initial render.");
if (!root.textContent.includes("Wheel Strength Lab")) fail("expected heading text not found after initial mount.");

// Click through every tab. Each tab renders a distinct code path (charts,
// the symmetry demo, etc.) that the default COMPARE-tab render never
// touches -- an undefined-variable bug in any of them would otherwise
// only surface when a real user happened to click there.
const TAB_SLUGS = { COMPARE: "compare", SYMMETRY: "symmetry", SIMULATION: "simulation", "DEEP DIVE": "deepdive", "TENSION BALANCE": "tensionbalance", "HUB SPECS": "hubspecs", INSIGHTS: "insights" };
const tabNames = ["SYMMETRY", "SIMULATION", "DEEP DIVE", "TENSION BALANCE", "HUB SPECS", "INSIGHTS", "COMPARE"];
for (const name of tabNames) {
  const buttons = [...dom.window.document.querySelectorAll("button")];
  const tabButton = buttons.find((b) => b.textContent.trim() === name);
  if (!tabButton) fail(`could not find a "${name}" tab button to click.`);
  tabButton.dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 150));
  if (caughtError) fail(`runtime error after switching to the ${name} tab.`);
  if (name === "HUB SPECS") {
    // The spec sheet lists every catalogue hub, one row each, with finite numbers.
    const rows = dom.window.document.querySelectorAll('table[aria-label="Hub specifications"] tbody tr');
    if (rows.length !== 30) fail(`HUB SPECS should list all 30 hubs, found ${rows.length} rows.`);
    if (/NaN|Infinity/.test(rows[0].parentElement.textContent)) fail("HUB SPECS table contains NaN/Infinity.");
  }
  if (name === "INSIGHTS") {
    // Four study-labelled sections, each naming its study, with charts and no NaN.
    const studies = [...dom.window.document.querySelectorAll("p")].filter((p) => p.textContent.startsWith("STUD"));
    if (studies.length !== 5) fail(`INSIGHTS should label 5 charts with their study, found ${studies.length}.`);
    const charts = ["Wind-up stiffness", "How far a", "Lateral stiffness against", "Spoke tension that buckles", "Spoke pitch against", "Keyboard showing"]
      .map((t) => dom.window.document.querySelector(`svg[aria-label^="${t}"]`));
    if (charts.some((c) => !c)) fail("INSIGHTS is missing one of its charts.");
    if (charts.some((c) => /NaN|Infinity/.test(c.outerHTML))) fail("an INSIGHTS chart drew NaN/Infinity.");
    if (!/Ford/.test(root.textContent)) fail("INSIGHTS must credit Matthew Ford.");
    // Each STUDY line has an EQUATION button that opens that chart's formula.
    const eqButtons = [...dom.window.document.querySelectorAll("button")].filter((b) => b.textContent.startsWith("EQUATION"));
    if (eqButtons.length !== 5) fail(`INSIGHTS should have 5 EQUATION buttons, found ${eqButtons.length}.`);
    eqButtons[0].dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
    await new Promise((resolve) => setTimeout(resolve, 50));
    const eqBox = dom.window.document.getElementById(eqButtons[0].getAttribute("aria-controls"));
    if (!eqBox || !eqBox.textContent.includes("tor")) fail("the wind-up EQUATION button did not open its formula.");
  }
  if (root.textContent.length === 0) fail(`#root emptied out after switching to the ${name} tab.`);
  const expectedHash = "#" + TAB_SLUGS[name];
  // The hash starts with the tab slug and then carries the build
  // ("#symmetry&h1=h6&h2=h7&w1=29&td1=120&ns=28").
  const hashNow = dom.window.location.hash;
  if (hashNow !== expectedHash && !hashNow.startsWith(expectedHash + "&")) {
    fail(`switching to the ${name} tab should set the URL hash to start with "${expectedHash}", got "${hashNow}".`);
  }
}

// The spoke ring (COMPARE) and load envelope (DEEP DIVE) draw from the
// engine's per-spoke output; check both render real numbers.
async function waitFor(sel, ms = 3000) {
  for (let t = 0; t < ms && !dom.window.document.querySelector(sel); t += 50) await new Promise((r) => setTimeout(r, 50));
  return dom.window.document.querySelector(sel);
}
const ringSvg = await waitFor('svg[aria-label^="Wheel with each spoke"]');
if (!ringSvg || ringSvg.querySelectorAll("line").length < 28 || /NaN|Infinity/.test(ringSvg.outerHTML)) {
  fail("the SPOKE RING on COMPARE did not draw a spoke for every spoke, or drew NaN.");
}
[...dom.window.document.querySelectorAll("button")].find((b) => b.textContent.trim() === "DEEP DIVE")
  .dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
const envSvg = await waitFor('svg[aria-label^="Load envelope"]');
if (!envSvg || !envSvg.querySelector("polygon") || /NaN|Infinity/.test(envSvg.outerHTML)) {
  fail("the LOAD ENVELOPE on DEEP DIVE did not draw, or drew NaN.");
}
[...dom.window.document.querySelectorAll("button")].find((b) => b.textContent.trim() === "COMPARE")
  .dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));

// The COMPARE tab's hub cross-section must redraw for the hub the user picks.
// It used to be wired to a fixed illustrative geometry, so it drew the same
// 37mm/20mm hub whatever the dropdown said -- while the strength figures
// beside it, and the TOTAL FLANGE WIDTH readout directly below it, followed
// the selection correctly. This checks the drawing actually moves.
const compareTab = [...dom.window.document.querySelectorAll("button")]
  .find((b) => b.textContent.trim() === "COMPARE");
compareTab.dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));

// The dimension callouts are the "<n>mm" texts inside the first cross-section.
function hubDimensions() {
  const svg = dom.window.document.querySelector('svg[viewBox="0 0 280 224"]');
  if (!svg) fail("could not find a hub cross-section SVG on the COMPARE tab.");
  return [...svg.querySelectorAll("text")]
    .map((t) => t.textContent)
    .filter((t) => /mm$/.test(t))
    .join(" ");
}

const hubSelect = dom.window.document.querySelector("select");
if (!hubSelect) fail("could not find the hub dropdown on the COMPARE tab.");
const options = [...hubSelect.querySelectorAll("option")].map((o) => o.value);
if (options.length < 2) fail("hub dropdown has fewer than two options to compare.");

const before = hubDimensions();
// React tracks a controlled <select>'s value, so assigning to .value alone is
// swallowed. Go through the prototype setter, then fire change, the same way
// a real selection does.
const setValue = Object.getOwnPropertyDescriptor(dom.window.HTMLSelectElement.prototype, "value").set;
setValue.call(hubSelect, options[options.length - 1]);
hubSelect.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));
if (caughtError) fail("runtime error after changing the hub selection.");

const after = hubDimensions();
if (before === after) {
  fail(`hub cross-section did not redraw when a different hub was selected (still "${before}").`);
}

// The Rim offset dial must reach the COMPARE tab. It used to feed only the
// SIMULATION/DEEP DIVE thresholds, so the headline 148-vs-157 comparison --
// the default view -- ignored it completely.
function compareReadout() {
  const svg = dom.window.document.querySelector('svg[viewBox="0 0 280 224"]');
  const angles = [...svg.querySelectorAll("text")]
    .map((t) => t.textContent)
    .filter((t) => /\u00B0$/.test(t))
    .join(" ");
  return { angles, text: root.textContent };
}

const sliders = [...dom.window.document.querySelectorAll('input[type="range"]')];
// The spoke ring's load slider sits below it, so find the offset slider by
// its 0-4mm range rather than by position.
const offsetSlider = sliders.find((r) => r.max === "4" && r.min === "0");
if (!offsetSlider) {
  fail(`expected a 0-4mm rim offset range input on COMPARE, got maxes ${sliders.map((r) => r.max).join(", ")}.`);
}

const beforeOffset = compareReadout();
const setRange = Object.getOwnPropertyDescriptor(dom.window.HTMLInputElement.prototype, "value").set;
setRange.call(offsetSlider, "4");
offsetSlider.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));
if (caughtError) fail("runtime error after moving the rim offset slider.");

const afterOffset = compareReadout();
if (beforeOffset.angles === afterOffset.angles) {
  fail(`rim offset did not change the bracing angles on the COMPARE tab (still "${beforeOffset.angles}").`);
}
if (beforeOffset.text === afterOffset.text) {
  fail("rim offset did not change any figure on the COMPARE tab.");
}

dom.window.close();

// A URL carrying a tab's hash should open directly on that tab -- the
// whole point of the hash convention (e.g. .../wheel-lab/#deepdive).
const dom2 = new JSDOM(html, { url: "https://example.com/wheel-lab/#deepdive", runScripts: "dangerously", resources: "usable" });
dom2.window.ResizeObserver = ResizeObserverStub;
dom2.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});
let dom2Error = null;
dom2.window.addEventListener("error", (e) => { dom2Error = e.error || e.message; });
await new Promise((resolve) => setTimeout(resolve, 300));
const root2 = dom2.window.document.getElementById("root");
if (dom2Error) { console.error("Smoke test FAILED: runtime error loading #deepdive directly.", dom2Error); dom2.window.close(); process.exit(1); }
if (!root2.textContent.includes("DEFLECTION CURVE")) {
  console.error(`Smoke test FAILED: loading with #deepdive in the URL should open directly on the DEEP DIVE tab, but its content wasn't found.`);
  dom2.window.close();
  process.exit(1);
}
dom2.window.close();

// A build link (as sent by the 148 vs 157 widget's "Explore why in the Lab")
// opens the Lab on that build: the hubs, rim size, tension and spoke count in
// the hash are applied, the address bar keeps the build, and "Quick compare"
// hands the same build back to the widget.
const dom3 = new JSDOM(html, {
  url: "https://example.com/wheel-lab/#compare&h1=h28&h2=h29&w1=32&td1=100&ns=36",
  runScripts: "dangerously", resources: "usable",
});
dom3.window.ResizeObserver = ResizeObserverStub;
dom3.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});
let dom3Error = null;
dom3.window.addEventListener("error", (e) => { dom3Error = e.error || e.message; });
await new Promise((resolve) => setTimeout(resolve, 300));
function fail3(msg) { console.error("Smoke test FAILED:", msg); dom3.window.close(); process.exit(1); }
if (dom3Error) fail3("runtime error loading a build link: " + dom3Error);
const selects3 = [...dom3.window.document.querySelectorAll("select")].map((x) => x.value);
if (selects3[0] !== "h28" || selects3[1] !== "h29") {
  fail3(`build link should select hubs h28 and h29, got ${JSON.stringify(selects3.slice(0, 2))}.`);
}
if (dom3.window.location.hash !== "#compare&h1=h28&h2=h29&w1=32&td1=100&ns=36") {
  fail3(`build link should survive load unchanged, got "${dom3.window.location.hash}".`);
}
const quick = [...dom3.window.document.querySelectorAll("a")].find((a) => a.textContent.includes("Quick compare"));
if (!quick) fail3('could not find the "Quick compare" link on the COMPARE tab.');
const wantQuick = "https://www.postmillenniumrenaissance.com/wheel-comparison-widget2/#h1=h28&h2=h29&w1=32&w2=32&td1=100&td2=100&ns=36";
if (quick.href !== wantQuick) fail3(`Quick compare link should be ${wantQuick}, got ${quick.href}.`);
// The FAILURE MAP draws on the COMPARE tab once the engine sweeps finish
// (they run after first paint so the tab is not blocked).
await new Promise((resolve) => setTimeout(resolve, 2500));
if (dom3Error) fail3("runtime error drawing the failure map: " + dom3Error);
const mapSvg = dom3.window.document.querySelector('svg[aria-label^="Failure map"]');
if (!mapSvg) fail3("COMPARE tab should draw a FAILURE MAP once its sweeps finish.");
if (mapSvg.querySelectorAll("path").length < 2 || /NaN|Infinity/.test(mapSvg.outerHTML)) {
  fail3("failure map drew no lines, or contains NaN/Infinity coordinates.");
}
dom3.window.close();

// A mangled build link must not break the page: bad values fall back to defaults.
const dom4 = new JSDOM(html, {
  url: "https://example.com/wheel-lab/#compare&h1=zzz&h2=h6&w1=99&td1=abc&ns=30&%E0%A4%A",
  runScripts: "dangerously", resources: "usable",
});
dom4.window.ResizeObserver = ResizeObserverStub;
dom4.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});
let dom4Error = null;
dom4.window.addEventListener("error", (e) => { dom4Error = e.error || e.message; });
// The app rewrites the hash in an effect after its first render; wait for
// that (up to 5 s) rather than a fixed delay, which a slower first render
// (more charts on COMPARE, a busy CI runner) can outlast.
for (let i = 0; i < 100 && !dom4.window.location.hash.startsWith("#compare&h1=h6"); i++) {
  await new Promise((resolve) => setTimeout(resolve, 50));
}
const selects4 = [...dom4.window.document.querySelectorAll("select")].map((x) => x.value);
if (dom4Error || selects4[0] !== "h6" || selects4[1] !== "h7" ||
    dom4.window.location.hash !== "#compare&h1=h6&h2=h7&w1=29&td1=120&ns=28") {
  console.error("Smoke test FAILED: a mangled build link should fall back to the defaults.", dom4Error, selects4, dom4.window.location.hash);
  dom4.window.close();
  process.exit(1);
}
dom4.window.close();

console.log("Smoke test passed: app mounted, every tab rendered, the spoke ring and load envelope drew, the hub diagram follows the dropdown, rim offset reaches COMPARE, tab switches update the URL hash, a URL hash opens directly on that tab, a build link restores the build and Quick compare hands it back, and a mangled link falls back to defaults.");
