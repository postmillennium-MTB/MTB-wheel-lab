// Runtime smoke test: loads the actual built dist/index.html into a
// simulated DOM and confirms the app mounts and renders real content
// without throwing. This is the strongest automated check available
// without a real browser -- it exercises the whole render tree (all
// four tabs' initial state), not just syntax.
import { JSDOM } from "jsdom";
import { readFileSync } from "node:fs";

const html = readFileSync(new URL("../dist/index.html", import.meta.url), "utf-8");

// jsdom doesn't implement ResizeObserver (used by Recharts' ResponsiveContainer);
// stub it so charts render at a fixed size instead of erroring.
class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}

// A real URL (rather than jsdom's default about:blank) so the app's
// hash <-> tab sync (history.replaceState on tab change) has somewhere
// valid to rewrite -- about:blank makes jsdom's History implementation
// throw, which the app's own try/catch there guards against, but giving
// a real URL here means this test still exercises that feature for real.
const dom = new JSDOM(html, { url: "https://example.com/wheel-lab/", runScripts: "dangerously", resources: "usable" });
dom.window.ResizeObserver = ResizeObserverStub;

// Recharts' ResponsiveContainer reads getBoundingClientRect for sizing.
dom.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});

let caughtError = null;
dom.window.addEventListener("error", (e) => {
  caughtError = e.error || e.message;
});

// give React a tick to render
await new Promise((resolve) => setTimeout(resolve, 300));

const root = dom.window.document.getElementById("root");

function fail(message) {
  console.error("Smoke test FAILED:", message);
  if (caughtError) console.error(caughtError);
  dom.window.close();
  process.exit(1);
}

if (!root || root.textContent.length === 0) fail("#root has no rendered content after initial mount.");
if (caughtError) fail("runtime error during initial render.");
if (!root.textContent.includes("Wheel Strength Lab")) fail("expected heading text not found after initial mount.");

// Click through every tab. Each tab renders a distinct code path (charts,
// the symmetry demo, etc.) that the default COMPARE-tab render never
// touches -- an undefined-variable bug in any of them would otherwise
// only surface when a real user happened to click there.
const TAB_SLUGS = { COMPARE: "compare", SYMMETRY: "symmetry", SIMULATION: "simulation", "DEEP DIVE": "deepdive", "TENSION BALANCE": "tensionbalance" };
const tabNames = ["SYMMETRY", "SIMULATION", "DEEP DIVE", "TENSION BALANCE", "COMPARE"];
for (const name of tabNames) {
  const buttons = [...dom.window.document.querySelectorAll("button")];
  const tabButton = buttons.find((b) => b.textContent.trim() === name);
  if (!tabButton) fail(`could not find a "${name}" tab button to click.`);
  tabButton.dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
  await new Promise((resolve) => setTimeout(resolve, 150));
  if (caughtError) fail(`runtime error after switching to the ${name} tab.`);
  if (root.textContent.length === 0) fail(`#root emptied out after switching to the ${name} tab.`);
  const expectedHash = "#" + TAB_SLUGS[name];
  if (dom.window.location.hash !== expectedHash) {
    fail(`switching to the ${name} tab should set the URL hash to "${expectedHash}", got "${dom.window.location.hash}".`);
  }
}

// The COMPARE tab's hub cross-section must redraw for the hub the user picks.
// It used to be wired to a fixed illustrative geometry, so it drew the same
// 37mm/20mm hub whatever the dropdown said -- while the strength figures
// beside it, and the TOTAL FLANGE WIDTH readout directly below it, followed
// the selection correctly. This checks the drawing actually moves.
const compareTab = [...dom.window.document.querySelectorAll("button")]
  .find((b) => b.textContent.trim() === "COMPARE");
compareTab.dispatchEvent(new dom.window.MouseEvent("click", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));

// The dimension callouts are the "<n>mm" texts inside the first cross-section.
function hubDimensions() {
  const svg = dom.window.document.querySelector('svg[viewBox="0 0 280 224"]');
  if (!svg) fail("could not find a hub cross-section SVG on the COMPARE tab.");
  return [...svg.querySelectorAll("text")]
    .map((t) => t.textContent)
    .filter((t) => /mm$/.test(t))
    .join(" ");
}

const hubSelect = dom.window.document.querySelector("select");
if (!hubSelect) fail("could not find the hub dropdown on the COMPARE tab.");
const options = [...hubSelect.querySelectorAll("option")].map((o) => o.value);
if (options.length < 2) fail("hub dropdown has fewer than two options to compare.");

const before = hubDimensions();
// React tracks a controlled <select>'s value, so assigning to .value alone is
// swallowed. Go through the prototype setter, then fire change, the same way
// a real selection does.
const setValue = Object.getOwnPropertyDescriptor(dom.window.HTMLSelectElement.prototype, "value").set;
setValue.call(hubSelect, options[options.length - 1]);
hubSelect.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));
if (caughtError) fail("runtime error after changing the hub selection.");

const after = hubDimensions();
if (before === after) {
  fail(`hub cross-section did not redraw when a different hub was selected (still "${before}").`);
}

// The Rim offset dial must reach the COMPARE tab. It used to feed only the
// SIMULATION/DEEP DIVE thresholds, so the headline 148-vs-157 comparison --
// the default view -- ignored it completely.
function compareReadout() {
  const svg = dom.window.document.querySelector('svg[viewBox="0 0 280 224"]');
  const angles = [...svg.querySelectorAll("text")]
    .map((t) => t.textContent)
    .filter((t) => /\u00B0$/.test(t))
    .join(" ");
  return { angles, text: root.textContent };
}

const sliders = [...dom.window.document.querySelectorAll('input[type="range"]')];
const offsetSlider = sliders[sliders.length - 1];
if (!offsetSlider || offsetSlider.max !== "4") {
  fail(`expected the last range input on COMPARE to be the 0-4mm rim offset, got max="${offsetSlider && offsetSlider.max}".`);
}

const beforeOffset = compareReadout();
const setRange = Object.getOwnPropertyDescriptor(dom.window.HTMLInputElement.prototype, "value").set;
setRange.call(offsetSlider, "4");
offsetSlider.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
await new Promise((resolve) => setTimeout(resolve, 150));
if (caughtError) fail("runtime error after moving the rim offset slider.");

const afterOffset = compareReadout();
if (beforeOffset.angles === afterOffset.angles) {
  fail(`rim offset did not change the bracing angles on the COMPARE tab (still "${beforeOffset.angles}").`);
}
if (beforeOffset.text === afterOffset.text) {
  fail("rim offset did not change any figure on the COMPARE tab.");
}

dom.window.close();

// A URL carrying a tab's hash should open directly on that tab -- the
// whole point of the hash convention (e.g. .../wheel-lab/#deepdive).
const dom2 = new JSDOM(html, { url: "https://example.com/wheel-lab/#deepdive", runScripts: "dangerously", resources: "usable" });
dom2.window.ResizeObserver = ResizeObserverStub;
dom2.window.HTMLElement.prototype.getBoundingClientRect = () => ({
  width: 600, height: 400, top: 0, left: 0, right: 600, bottom: 400, x: 0, y: 0, toJSON() {},
});
let dom2Error = null;
dom2.window.addEventListener("error", (e) => { dom2Error = e.error || e.message; });
await new Promise((resolve) => setTimeout(resolve, 300));
const root2 = dom2.window.document.getElementById("root");
if (dom2Error) { console.error("Smoke test FAILED: runtime error loading #deepdive directly.", dom2Error); dom2.window.close(); process.exit(1); }
if (!root2.textContent.includes("DEFLECTION CURVE")) {
  console.error(`Smoke test FAILED: loading with #deepdive in the URL should open directly on the DEEP DIVE tab, but its content wasn't found.`);
  dom2.window.close();
  process.exit(1);
}
dom2.window.close();

console.log("Smoke test passed: app mounted, every tab rendered, the hub diagram follows the dropdown, rim offset reaches COMPARE, tab switches update the URL hash, and a URL hash opens directly on that tab.");
