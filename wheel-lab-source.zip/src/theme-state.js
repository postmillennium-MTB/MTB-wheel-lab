// Sibling components (WheelDiagram, Section, sliders, etc.) read the active
// theme's colors from this shared module-level binding rather than via
// props or Context. This mirrors the original bundle's behavior exactly
// (it used a single mutable module-scope variable) rather than introducing
// a React Context, which would be a real behavioral change I didn't want
// to make silently. App.jsx calls setActiveTheme() once per render, right
// after computing the active theme; every component that imports `theme`
// reads the fresh value because ES module bindings are live references.
import { THEMES } from "./themes.js";

export let theme = THEMES.c3;

export function setActiveTheme(next) {
  theme = next;
}
