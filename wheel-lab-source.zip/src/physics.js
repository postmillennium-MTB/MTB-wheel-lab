// Wheel strength & simulation math.
//
// The core strength/stiffness calculation (computeWheelStrength) is no
// longer computed here -- it's imported from wheel-physics-core, a repo
// holding Matthew Ford's Mode Matrix method (his PhD thesis, Northwestern,
// 2018) vendored as real Python (his own bike-wheel-calc library,
// MIT-licensed, unmodified) plus a JS port that's checked against that
// Python on every commit -- see
// https://github.com/postmillennium-MTB/wheel-physics-core.
//
// This file previously contained its own hand-derived closed-form version
// of the same math. It was never checked against Ford's own library, and
// when it finally was, it read K_lat ~90% high and K_rad ~66% high across
// every hub tested -- consistently, not as noise. That is the reason this
// is an import now rather than a local formula: a formula nobody has
// checked against its own source is a claim, not a result.
//
// computeWheelStrength's signature and its three load-bearing return
// fields (ratio, K_lat, F_lat -- the only ones any UI in this app reads)
// are unchanged, so no call site elsewhere in src/ needed to change.
import { calc as computeWheelStrength, spokeTensions, firstSlackCombined, firstSlackTorque } from "wheel-physics-core";

import { RIDE_PROFILES, REFERENCE_RIDER_WEIGHT_KG, RIDE_LOAD_SCALE, PHYS_CONSTANTS } from "./data.js";

/**
 * Axial stiffness (E*A) of a single spoke, given its wire diameter in mm.
 * 21e10 Pa \u2248 steel's Young's modulus. Kept here because
 * bracingAngleDeg below doesn't go through wheel-physics-core's engine --
 * it's a small, self-contained geometry formula, not part of the
 * validated stiffness/strength calculation.
 */
function spokeAxialStiffness(e){return 21e10*Math.PI*Math.pow(e/2/1e3,2)}

/**
 * Spoke bracing angle in degrees for one side of a hub: the angle between the
 * spoke and the plane of the wheel. Bigger is better — it is the leverage the
 * spoke has to resist sideways loads.
 *
 * Measured against the same in-plane spoke length wheel-physics-core's
 * engine uses, NOT the naive atan(offset / ERD/2). Two corrections apply,
 * both matching that engine exactly (see js/engine.js in
 * wheel-physics-core) -- and they pull in OPPOSITE directions, so don't
 * assume they stack:
 *   - a 3-cross spoke does not run radially; it runs a chord from the
 *     flange's pitch circle out to the rim, which is shorter than the rim
 *     radius (~290mm on a 29" wheel, not 300) and on its own INCREASES
 *     the angle, by about 1.7% at typical MTB geometry;
 *   - the rim radius itself is ERD/2 + 11mm, not ERD/2 -- Ford's rim
 *     centroid sits ~11mm inboard of the nipple seat (Ford \u00a73.2) --
 *     which enlarges the effective radius and on its own DECREASES it.
 * Combined, the centroid correction wins narrowly: the real angle ends up
 * about 2% BELOW the naive figure, not above it. See the test suite for
 * the isolated, measured comparison -- this is a case where getting each
 * correction right individually and assuming they add is exactly how you
 * get the net direction wrong.
 *
 * @param e  rim diameter (mm)
 * @param x  flange-to-centre distance on this side (mm)
 * @param w  flange diameter on this side (mm)
 * @param s  spoke count
 */
function bracingAngleDeg(e,x,w,s){let p=e/2/1e3+.011,r=w/2/1e3,h=Math.cos(4*Math.PI*3/s),inPlane=Math.sqrt(p*p+r*r-2*p*r*h);return Math.atan(x/1e3/inPlane)*180/Math.PI}

/**
 * Applies an offset rim to a hub, returning the geometry the SPOKES see.
 *
 * An offset rim is drilled toward the non-drive side, which lengthens the
 * drive-side spoke's lateral run and shortens the non-drive side's. The hub
 * itself does not move -- only the rim's spoke bed -- so this is the geometry
 * for the strength calculation and the bracing angles, NOT for the flange
 * dimension labels on the diagram, which still describe the hub.
 *
 * Note this can over-correct: on a nearly symmetric hub (Hope Pro5 150 with
 * 157 endcaps is 28.0 / 26.8) even 1mm of offset flips which side is tighter.
 * See tightSideFirst().
 *
 * @param t    hub record { nds, ds, pds, pnds } in mm
 * @param off  rim offset (mm), 0 for a conventional centre-drilled rim
 */
function applyRimOffset(t,off){return{...t,ds:t.ds+off,nds:t.nds-off}}

/**
 * Orders a hub's two sides so the tighter one is `ds`, which is what
 * computeWheelStrength assumes: it takes `ds` as the side built to the
 * tension you set and derives `nds` from lateral equilibrium, so `nds` is
 * always the slack side and F_lat is the load that takes IT to zero.
 *
 * Feed it a hub whose `ds` is actually the looser side and it reports a
 * tension ratio above 100% and a lateral strength for the wrong spoke --
 * too high, because it measured the side with margin to spare. Passing
 * geometry through here first means an over-corrected offset rim reads as
 * what it is: balance improving up to 100%, then falling away again as the
 * imbalance reopens on the other side.
 *
 * Ordered by BRACING ANGLE, not by flange-to-centre distance. Those usually
 * agree, but not when a hub's two flange diameters differ: Project 321's 157
 * is 60.5mm on the drive side and 55mm on the non-drive, so at 3mm of rim
 * offset its two flanges sit at an identical 29mm from centre and the drive
 * side is still the tighter one, because its larger pull circle shortens the
 * spoke. Comparing offsets alone misses that and lets the ratio drift just
 * over 100%.
 *
 * @param t  hub record { nds, ds, pds, pnds } in mm
 * @param e  rim diameter (mm)
 * @param s  spoke count
 */
function tightSideFirst(t,e,s){return bracingAngleDeg(e,t.ds,t.pds,s)<=bracingAngleDeg(e,t.nds,t.pnds,s)?t:{...t,ds:t.nds,nds:t.ds,pds:t.pnds,pnds:t.pds}}

/** Deterministic PRNG (mulberry32-style) so ride simulations are seed-reproducible. */
function seededRandom(e){let t=e>>>0;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}

/** Layered pseudo-random noise trace of length t, normalized to [-1, 1]. */
function generateNoiseTrace(e,t,r=3){let n=new Array(t).fill(0);for(let o=0;o<r;o++){let a=seededRandom(e+o*1013),l=Math.pow(2,o),u=Math.pow(.55,o),s=0,f=new Array(t);for(let c=0;c<t;c++)s+=(a()-.5)*.5,s*=.96,f[c]=s;for(let c=0;c<t;c++){let p=c*l%t;n[c]+=f[Math.floor(p)]*u}}let i=Math.max(...n.map(Math.abs))||1;return n.map(o=>o/i)}

/**
 * Generates an illustrative 280-sample lateral-load trace for a ride profile
 * (see RIDE_PROFILES), scaled by rider+bike weight and a "chaos" (0-5) knob.
 */
function simulateRideLoad(e,{chaos:t=3,weightKg:r=REFERENCE_RIDER_WEIGHT_KG,runSeed:n=0}={}){let i=RIDE_PROFILES[e],o=280,a=Math.pow(r/REFERENCE_RIDER_WEIGHT_KG,.85),l=i.noise*(.15+t*.17),u=generateNoiseTrace(i.seed+n*7919,o,3),s=new Array(o);for(let f=0;f<o;f++)s[f]=Math.max(2,i.base+u[f]*l);return i.spikes.forEach(({t:f,peak:c,w:p=5})=>{for(let d=-p;d<=p;d++){let x=f+d;if(x<0||x>=o)continue;let y=Math.pow(1-Math.abs(d)/(p+1),1.8),w=s[x]+(c-s[x])*y;w>s[x]&&(s[x]=w)}}),s.map((f,c)=>({t:c,load:+Math.min(90,Math.max(0,f*a*RIDE_LOAD_SCALE)).toFixed(1)}))}

/** Counts distinct load excursions above threshold t in a load trace e. */
function countOverloadEvents(e,t){let r=0,n=!1;for(let i of e)i.load>t&&!n?(r++,n=!0):i.load<=t&&(n=!1);return r}

/** Single-impact force-vs-time curve (120 samples) for a given scenario + rider weight. */
function impactForceCurve(e,t){let n=Math.pow(t/REFERENCE_RIDER_WEIGHT_KG,.85),i=e.refPeak*n*RIDE_LOAD_SCALE,o=new Array(120).fill(0);if(e.shape==="sharp")for(let a=0;a<120;a++){let u=a-30;o[a]=i*Math.exp(-(u*u)/40)}else if(e.shape==="broad")for(let a=0;a<120;a++){let u=a-45;o[a]=i*Math.exp(-(u*u)/320)}else if(e.shape==="repeat"){let a=[22,45,68,91];for(let l=0;l<120;l++){let u=0;a.forEach((s,f)=>{let c=l-s;u=Math.max(u,i*(1-f*.08)*Math.exp(-(c*c)/28))}),o[l]=u}}else for(let a=0;a<120;a++)a<28?o[a]=i*Math.exp(-((a-28)*(a-28))/24):o[a]=i*Math.exp(-(a-28)/18);return o.map((a,l)=>({t:l,force:+a.toFixed(1)}))}

/**
 * How much softer the wheel gets, laterally, once its first spokes go slack.
 * Past first-slack the slack spokes stop pulling, so the wheel loses a large
 * share of its lateral stiffness; 2x compliance is an illustrative stand-in
 * for that, not a Mode Matrix output (the engine is linear and stops at
 * first-slack). Used only to draw the curve beyond the knee.
 */
const POST_SLACK_SOFTENING = 2;

/** Rim lateral deflection (mm) under force f (kgf), for a wheel whose first spoke goes slack at t (kgf) with lateral stiffness k (N/mm). */
function lateralDeflection(f,t,k){let c=9.81/k;return f<=t?f*c:t*c+(f-t)*c*POST_SLACK_SOFTENING}

/**
 * Converts a force trace into a rim-deflection trace. t = first-spoke-slack
 * load (kgf, Mode Matrix F_lat), r = lateral stiffness (N/mm, Mode Matrix
 * K_lat). The wheel springs back once the hit passes: first-slack is not
 * yield, so no permanent set is modelled. `ratio` = peak force / t.
 */
function deflectionTrace(e,t,r){let p=0;return{trace:e.map(({t:l,force:u})=>(p=Math.max(p,u),{t:l,deflection:+lateralDeflection(u,t,r).toFixed(3),force:u})),failed:p>t,ratio:+(p/t).toFixed(3)}}

/**
 * Classifies a single hit by how far its peak went past first-slack
 * (e = peak / F_lat). The 1.5x line between "Slack" and "Overload" is an
 * illustrative marker for "well past the working range", not a computed
 * failure load -- this model does not predict where a wheel folds.
 */
function classifyImpact(e){let p=Math.round((e-1)*100);return e<=1?{word:"Holds",tone:"ok",note:"every spoke stayed tight"}:e<=1.5?{word:"Slack",tone:"warn",note:`${p}% past first-slack`}:{word:"Overload",tone:"fail",note:`${p}% past \u2014 true at risk`}}

/** Force-vs-deflection curve for the DEEP DIVE chart: e = first-slack load (kgf), t = lateral stiffness (N/mm). */
function deflectionCurve(e,t){let n=[],i=e*1.35;for(let o=0;o<=i;o+=1)n.push({f:+o.toFixed(0),d:+lateralDeflection(o,e,t).toFixed(3)});return n}

/** The STRENGTH METRICS panel's numbers, straight from a computeWheelStrength result. */
function strengthMetrics(r){return{"Lateral Strength":r.F_lat,"Lateral Stiffness":r.K_lat,"Radial Strength":r.F_rad,"Tension Balance":r.ratio}}

/**
 * As-built spoke tension around the wheel, alternating DS/NDS. Every spoke on
 * a side carries the same tension, which is what the model assumes of a wheel
 * built to spec; an earlier version added a small made-up spoke-to-spoke
 * wobble for looks, which was not a model output and has been removed.
 */
function spokeTensionDistribution(e,t,r=32,rt){let n=rt!=null?rt/100:e.flangeR/e.flangeL,i=t,o=Math.round(t*n),a=r,l=[];for(let u=0;u<a;u++){let s=u%2===0;l.push({spoke:u+1,tension:s?i:o,side:s?"DS":"NDS"})}return{rows:l,dsT:i,ndsT:o,ratio:Math.round(n*100)}}

// Gavin (1996) ASCE J. Eng. Mech. 122(8) Eq. 10: log S = a log N + b, S in MPa.
const GAVIN_SN={a:-0.30,b:4.12,Vb:0.017,minTested:174};
function gavinCycles(S,sig=0){const b=GAVIN_SN.b*(1+sig*GAVIN_SN.Vb);return Math.pow(10,(Math.log10(S)-b)/GAVIN_SN.a)}

/**
 * The SYMMETRY tab's pair of wheels: one perfectly centred, one with its
 * flanges moved `offset` mm off centre, both with the same total flange
 * width (60 mm, 58 mm flanges) and the SAME AVERAGE spoke tension, so that
 * balance is the only thing that differs.
 *
 * Why average and not drive-side tension: the tension slider sets the drive
 * side, and on a real dished wheel the non-drive side then sits well below
 * it. Feeding the slider value straight to a centred wheel puts BOTH sides at
 * that figure, about 20% more total tension than any real wheel at the same
 * setting, which pushed the centred wheel close to the rim's buckling tension
 * (81% at the default 29" / 28h / 120 kgf) and past its own lateral-strength
 * peak. Dishing it then lowered total tension as well as balance: two
 * variables, not one.
 *
 * SYMMETRY_AVG_FACTOR turns the slider's drive-side figure into the average
 * held here: 5/6, the average of a wheel whose non-drive side is at two
 * thirds of its drive side (on a 29" wheel the catalogue's 148x12 hubs run
 * 56-77%, median 64%, and its 157x12 hubs 60-83%, median 69%). So at that
 * typical dish the drive side reads exactly
 * the slider value, and the centred wheel has both sides at 5/6 of it.
 *
 * The drive-side tension for a given offset follows from the engine's own
 * NDS/DS ratio, which depends on geometry only:
 *   T_DS = 2 * T_avg / (1 + ratio),  T_NDS = ratio * T_DS.
 * No new physics: the same wheel-physics-core call, with that T_DS.
 */
const SYMMETRY_AVG_FACTOR = 5 / 6;
const SYMMETRY_HUB = { width: 60, flange: 58 };
function symmetryBuild(erd,offset,spokes,sliderTension){
  let {EIL:e,EIR:t,GJ:r,EA_rim:n,modes:i}=PHYS_CONSTANTS,half=SYMMETRY_HUB.width/2,fl=SYMMETRY_HUB.flange,
      tAvg=sliderTension*SYMMETRY_AVG_FACTOR,
      run=(off,T)=>computeWheelStrength(erd,{nds:half+off,ds:half-off,pds:fl,pnds:fl},2,2,T,e,t,r,n,spokes,i),
      base=run(0,tAvg),
      ratio=offset===0?1:run(offset,tAvg).ratio/100,
      tDS=2*tAvg/(1+ratio),
      cur=offset===0?base:run(offset,tDS);
  return{base,cur,tAvg,tDS,tNDS:tDS*ratio};
}

/**
 * Drive-side tension (kgf) at which a build's lateral strength (F_lat, first
 * spoke slack) is highest, and that strength. Below it more tension buys more
 * margin before a spoke goes slack; above it the rim is close enough to its
 * buckling tension that more tension makes the wheel weaker sideways. Ford
 * (2018, ch. 5) derives a rule of thumb for this optimum, T_opt = 0.5 T_c,
 * from the approximation K_lat(T) = K_lat(0)(1 - T/T_c), which he calls rough
 * and conservative; with the engine's exact tension-dependent stiffness the
 * peak sits higher, at about 0.7 T_c in average-tension terms for the default
 * CK Centerlock 148x12 build and for the SYMMETRY tab's centred wheel. Found by
 * golden-section search on the engine's own F_lat between 40 kgf and the
 * build's buckling tension, so it is the engine's number, not a rule of thumb.
 * Independent of the tension slider.
 *
 * @param erd rim diameter (mm); hub { nds, ds, pds, pnds }; Ns spoke count; offset rim offset (mm)
 * @returns { tension, F_lat } with tension rounded to 1 kgf, or null if the search fails
 */
function peakLateralTension(erd,hub,Ns,offset=0){
  let {EIL:e,EIR:t,GJ:r,EA_rim:n,modes:i}=PHYS_CONSTANTS,g=tightSideFirst(applyRimOffset(hub,offset),erd,Ns),
      f=T=>{let m=computeWheelStrength(erd,g,2,2,T,e,t,r,n,Ns,i);return m.T_safety<100&&m.F_lat>0?m.F_lat:0},
      hi=computeWheelStrength(erd,g,2,2,100,e,t,r,n,Ns,i).T_c_DS;
  if(!(hi>40))return null;
  let lo=40,ph=(Math.sqrt(5)-1)/2,a=hi-ph*(hi-lo),b=lo+ph*(hi-lo),fa=f(a),fb=f(b);
  for(let k=0;k<22&&hi-lo>.4;k++){if(fa<fb){lo=a;a=b;fa=fb;b=lo+ph*(hi-lo);fb=f(b)}else{hi=b;b=a;fb=fa;a=hi-ph*(hi-lo);fa=f(a)}}
  let T=Math.round((lo+hi)/2);
  return{tension:T,F_lat:f(T)};
}

/**
 * One build's per-spoke model for the spoke ring and load envelope: the
 * engine result with `spokes` (every spoke's tension change per unit load,
 * from Ford's discrete-spoke Mode Matrix; see wheel-physics-core), plus
 * `swapped` when tightSideFirst() had to swap the hub's sides, so that the
 * engine's "DS"/"NDS" and its +lateral direction (toward its `nds` side)
 * can be mapped back to the real drive side. 2.0 mm spokes, stock rim, as
 * everywhere else in the Lab.
 *
 * realSide(i) = "DS" | "NDS" for spoke i; toNDS = the engine lateral sign
 * that pushes toward the real non-drive side.
 */
function spokeModel(hub,erd,Ns,offset,tension){let a=applyRimOffset(hub,offset),g=tightSideFirst(a,erd,Ns),swapped=g!==a,{EIL:e,EIR:t,GJ:r,EA_rim:n,modes:i}=PHYS_CONSTANTS,res=computeWheelStrength(erd,g,2,2,tension,e,t,r,n,Ns,i,{spokes:!0});return{res,swapped,toNDS:swapped?-1:1,realSide:o=>swapped?(res.spokes.side[o]==="DS"?"NDS":"DS"):res.spokes.side[o],pastBuckling:!(res.T_safety<100)||!(res.F_lat>0)}}

export {
  spokeAxialStiffness,
  computeWheelStrength,
  bracingAngleDeg,
  applyRimOffset,
  tightSideFirst,
  seededRandom,
  generateNoiseTrace,
  simulateRideLoad,
  countOverloadEvents,
  impactForceCurve,
  deflectionTrace,
  classifyImpact,
  deflectionCurve,
  strengthMetrics,
  spokeTensionDistribution,
  symmetryBuild,
  SYMMETRY_AVG_FACTOR,
  peakLateralTension,
  gavinCycles,
  GAVIN_SN,
  spokeModel,
  spokeTensions,
  firstSlackCombined,
  firstSlackTorque,
};
