// Wheel strength & simulation math.
//
// A note on style: the functions below are left in their original dense,
// single-letter-variable form on purpose. This is real engineering math
// (Ford's Mode Matrix method for spoked-wheel lateral/radial stiffness —
// see https://github.com/dashdotrobot/bike-wheel-calc), and hand-renaming
// variables inside a 20-term trigonometric expression is a great way to
// silently introduce a sign error nobody will spot in review. Only the
// function names themselves (and the few cross-references between them)
// were renamed, and every rename was verified mechanically against the
// original bundle before/after — see wheel-lab-src/README.md.

import { RIDE_PROFILES, REFERENCE_RIDER_WEIGHT_KG } from "./data.js";

/**
 * Axial stiffness (E*A) of a single spoke, given its wire diameter in mm.
 * 21e10 Pa \u2248 steel's Young's modulus.
 */
function spokeAxialStiffness(e){return 21e10*Math.PI*Math.pow(e/2/1e3,2)}

/**
 * Core wheel-strength calculation (Ford Mode Matrix method).
 * @param e  rim diameter (mm)
 * @param t  hub flange geometry { nds, ds, pds, pnds }
 * @param r  drive-side spoke wire diameter (mm)
 * @param n  non-drive-side spoke wire diameter (mm)
 * @param i  spoke tension (kgf)
 * @param o  rim lateral bending stiffness EIL
 * @param a  rim radial bending stiffness EIR
 * @param l  rim torsional stiffness GJ
 * @param u  rim axial stiffness EA
 * @param s  spoke count
 * @param f  number of harmonic modes to sum
 * @returns  { ratio, K_lat, K_rad, F_lat, F_rad, T_c, T_c_ratio, F_slack }
 *           ratio = NDS/DS tension balance (%), F_lat = lateral strength (kgf)
 */
function computeWheelStrength(e,t,r,n,i,o,a,l,u,s,f){let c=i*9.81,p=e/2/1e3,d=p+.011,x=t.ds/1e3,y=t.nds/1e3,w=t.pds/2/1e3,m=t.pnds/2/1e3,h=Math.cos(4*Math.PI*3/s),g=p*p+w*w-2*p*w*h,S=p*p+m*m-2*p*m*h,v=Math.sqrt(x*x+g),b=Math.sqrt(y*y+S),A=x/v,T=y/b,N=A/T,D=c*N,F=spokeAxialStiffness(r),L=spokeAxialStiffness(n),H=F/v,q=L/b,$=c/v+H*A*A,O=D/b+q*T*T,P=c/v+H*(g/(x*x+g)),k=D/b+q*(S/(y*y+S)),E=s/2*($+O),C=s/2*(P+k),M=Math.PI/(d*d*d),R=s/(2*Math.PI)*(c*(g/(v*p))+D*(S/(b*p))),B=1/(2*E),K=1/(2*C);for(let Se=1;Se<=f;Se++){let Te=Se*Se-1,We=M*(o*Te*Te+l*Te),ft=R*Te/(d*d),je=M*a*Te*Te,de=E+We-ft,Tn=C+je;de>0&&(B+=1/de),Tn>0&&(K+=1/Tn)}let Q=1/B/1e3,Z=1/K/1e3,ee=D*(Q*1e3)*b/(L*T),fe=Math.sqrt(g)/v,G=c*(Z*1e3)*v/(F*fe),ae=H*A*A,J=q*T*T,z=s/2*(ae+J),ie=s/2*(1/v+N/b),ue=s/(2*Math.PI)*(g/(v*p)+N*S/(b*p)),ge=1/0;for(let Se=2;Se<=f;Se++){let Te=Se*Se-1,We=M*(o*Te*Te+l*Te),ft=z+We,je=ue*Te/(d*d)-ie;if(je>0){let de=ft/je;de>0&&de<ge&&(ge=de)}}let he=ge/9.81,Me=Math.sqrt(S)/b,Pt=D*(s/2)/Me/9.81;return{ratio:N*100,K_lat:Q,K_rad:Z,F_lat:ee/9.81,F_rad:G/9.81,T_c:he,T_c_ratio:i/he*100,F_slack:Pt}}

/**
 * Spoke bracing angle in degrees for one side of a hub: the angle between the
 * spoke and the plane of the wheel. Bigger is better — it is the leverage the
 * spoke has to resist sideways loads.
 *
 * Measured against the same in-plane spoke length computeWheelStrength uses,
 * NOT the rim radius. A 3-cross spoke does not run radially; it runs a chord
 * from the flange's pitch circle out to the rim, which is shorter than the rim
 * radius (~290mm on a 29" wheel, not 300). Dividing by the rim radius instead
 * understates every bracing angle by roughly 3.5%.
 *
 * @param e  rim diameter (mm)
 * @param x  flange-to-centre distance on this side (mm)
 * @param w  flange diameter on this side (mm)
 * @param s  spoke count
 */
function bracingAngleDeg(e,x,w,s){let p=e/2/1e3,r=w/2/1e3,h=Math.cos(4*Math.PI*3/s),inPlane=Math.sqrt(p*p+r*r-2*p*r*h);return Math.atan(x/1e3/inPlane)*180/Math.PI}

/** Deterministic PRNG (mulberry32-style) so ride simulations are seed-reproducible. */
function seededRandom(e){let t=e>>>0;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}

/** Layered pseudo-random noise trace of length t, normalized to [-1, 1]. */
function generateNoiseTrace(e,t,r=3){let n=new Array(t).fill(0);for(let o=0;o<r;o++){let a=seededRandom(e+o*1013),l=Math.pow(2,o),u=Math.pow(.55,o),s=0,f=new Array(t);for(let c=0;c<t;c++)s+=(a()-.5)*.5,s*=.96,f[c]=s;for(let c=0;c<t;c++){let p=c*l%t;n[c]+=f[Math.floor(p)]*u}}let i=Math.max(...n.map(Math.abs))||1;return n.map(o=>o/i)}

/**
 * Generates an illustrative 280-sample lateral-load trace for a ride profile
 * (see RIDE_PROFILES), scaled by rider+bike weight and a "chaos" (0-5) knob.
 */
function simulateRideLoad(e,{chaos:t=3,weightKg:r=REFERENCE_RIDER_WEIGHT_KG,runSeed:n=0}={}){let i=RIDE_PROFILES[e],o=280,a=Math.pow(r/REFERENCE_RIDER_WEIGHT_KG,.85),l=i.noise*(.15+t*.17),u=generateNoiseTrace(i.seed+n*7919,o,3),s=new Array(o);for(let f=0;f<o;f++)s[f]=Math.max(2,i.base+u[f]*l);return i.spikes.forEach(({t:f,peak:c,w:p=5})=>{for(let d=-p;d<=p;d++){let x=f+d;if(x<0||x>=o)continue;let y=Math.pow(1-Math.abs(d)/(p+1),1.8),w=s[x]+(c-s[x])*y;w>s[x]&&(s[x]=w)}}),s.map((f,c)=>({t:c,load:+Math.min(90,Math.max(0,f*a)).toFixed(1)}))}

/** Counts distinct load excursions above threshold t in a load trace e. */
function countOverloadEvents(e,t){let r=0,n=!1;for(let i of e)i.load>t&&!n?(r++,n=!0):i.load<=t&&(n=!1);return r}

/** Single-impact force-vs-time curve (120 samples) for a given scenario + rider weight. */
function impactForceCurve(e,t){let n=Math.pow(t/REFERENCE_RIDER_WEIGHT_KG,.85),i=e.refPeak*n,o=new Array(120).fill(0);if(e.shape==="sharp")for(let a=0;a<120;a++){let u=a-30;o[a]=i*Math.exp(-(u*u)/40)}else if(e.shape==="broad")for(let a=0;a<120;a++){let u=a-45;o[a]=i*Math.exp(-(u*u)/320)}else if(e.shape==="repeat"){let a=[22,45,68,91];for(let l=0;l<120;l++){let u=0;a.forEach((s,f)=>{let c=l-s;u=Math.max(u,i*(1-f*.08)*Math.exp(-(c*c)/28))}),o[l]=u}}else for(let a=0;a<120;a++)a<28?o[a]=i*Math.exp(-((a-28)*(a-28))/24):o[a]=i*Math.exp(-(a-28)/18);return o.map((a,l)=>({t:l,force:+a.toFixed(1)}))}

/** Converts a force trace into a rim-deflection trace, tracking permanent (plastic) set past yield threshold t. */
function deflectionTrace(e,t,r){let n=.02*(100/r),i=0,o=!1;return{trace:e.map(({t:l,force:u})=>{let s;if(u<=t)s=u*n+i;else{let f=u-t,c=f*n*(1+f*.35);i+=f*n*.18,o=!0,s=t*n+c+i}return{t:l,deflection:+s.toFixed(3),force:u}}),plastic:+i.toFixed(2),failed:o}}

/** Classifies a rim's permanent deflection (mm) as Holds / Bends / Taco'd. */
function classifyPermanentSet(e){return e<=0?{word:"Holds",tone:"ok",note:"sprang back"}:e<.5?{word:"Bends",tone:"warn",note:`${e}mm out of true`}:{word:"Taco'd",tone:"fail",note:`${e}mm \u2014 folded`}}

/** Force-vs-deflection curve for the DEEP DIVE chart, given a yield threshold t and stiffness r. */
function deflectionCurve(e,t){let r=.02*(100/t),n=[],i=e*1.35;for(let o=0;o<=i;o+=1){let a;if(o<=e)a=o*r;else{let l=o-e;a=e*r+l*r*(1+l*.35)}n.push({f:+o.toFixed(0),d:+a.toFixed(3)})}return n}

/** Per-spoke tension distribution around the wheel, alternating DS/NDS. */
function spokeTensionDistribution(e,t,r=32,rt){let n=rt!=null?rt/100:e.flangeR/e.flangeL,i=t,o=Math.round(t*n),a=r,l=[];for(let u=0;u<a;u++){let s=u%2===0,f=(u*7%5-2)*.6;l.push({spoke:u+1,tension:Math.round((s?i:o)+f),side:s?"DS":"NDS"})}return{rows:l,dsT:i,ndsT:o,ratio:Math.round(n*100)}}

/** Illustrative S-N (stress vs. cycles-to-failure) fatigue curve for a given yield strength e. */
function fatigueSNCurve(e){let t=[];for(let r=40;r<=130;r+=5){let n=r/100*e,o=Math.pow(e/n,5.5)*1500;t.push({stress:+n.toFixed(0),cycles:Math.max(1,Math.round(o))})}return t}

export {
  spokeAxialStiffness,
  computeWheelStrength,
  bracingAngleDeg,
  seededRandom,
  generateNoiseTrace,
  simulateRideLoad,
  countOverloadEvents,
  impactForceCurve,
  deflectionTrace,
  classifyPermanentSet,
  deflectionCurve,
  spokeTensionDistribution,
  fatigueSNCurve,
};
