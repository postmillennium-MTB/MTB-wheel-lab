// Wheel strength & simulation math.
//
// The core strength/stiffness calculation (computeWheelStrength) is no
// longer computed here -- it's imported from wheel-physics-core, a repo
// holding Matthew Ford's Mode Matrix method (his PhD thesis, Northwestern,
// 2018) vendored as real Python (his own bike-wheel-calc library,
// MIT-licensed, unmodified) plus a JS port that's checked against that
// Python on every commit -- see
// https://github.com/postmillennium-MTB/wheel-physics-core.
//
// This file previously contained its own hand-derived closed-form version
// of the same math. It was never checked against Ford's own library, and
// when it finally was, it read K_lat ~90% high and K_rad ~66% high across
// every hub tested -- consistently, not as noise. That is the reason this
// is an import now rather than a local formula: a formula nobody has
// checked against its own source is a claim, not a result.
//
// computeWheelStrength's signature and its three load-bearing return
// fields (ratio, K_lat, F_lat -- the only ones any UI in this app reads)
// are unchanged, so no call site elsewhere in src/ needed to change.
import { calc as computeWheelStrength } from "wheel-physics-core";

import { RIDE_PROFILES, REFERENCE_RIDER_WEIGHT_KG } from "./data.js";

/**
 * Axial stiffness (E*A) of a single spoke, given its wire diameter in mm.
 * 21e10 Pa \u2248 steel's Young's modulus. Kept here because
 * bracingAngleDeg below doesn't go through wheel-physics-core's engine --
 * it's a small, self-contained geometry formula, not part of the
 * validated stiffness/strength calculation.
 */
function spokeAxialStiffness(e){return 21e10*Math.PI*Math.pow(e/2/1e3,2)}

/**
 * Spoke bracing angle in degrees for one side of a hub: the angle between the
 * spoke and the plane of the wheel. Bigger is better — it is the leverage the
 * spoke has to resist sideways loads.
 *
 * Measured against the same in-plane spoke length wheel-physics-core's
 * engine uses, NOT the naive atan(offset / ERD/2). Two corrections apply,
 * both matching that engine exactly (see js/engine.js in
 * wheel-physics-core) -- and they pull in OPPOSITE directions, so don't
 * assume they stack:
 *   - a 3-cross spoke does not run radially; it runs a chord from the
 *     flange's pitch circle out to the rim, which is shorter than the rim
 *     radius (~290mm on a 29" wheel, not 300) and on its own INCREASES
 *     the angle, by about 1.7% at typical MTB geometry;
 *   - the rim radius itself is ERD/2 + 11mm, not ERD/2 -- Ford's rim
 *     centroid sits ~11mm inboard of the nipple seat (Ford \u00a73.2) --
 *     which enlarges the effective radius and on its own DECREASES it.
 * Combined, the centroid correction wins narrowly: the real angle ends up
 * about 2% BELOW the naive figure, not above it. See the test suite for
 * the isolated, measured comparison -- this is a case where getting each
 * correction right individually and assuming they add is exactly how you
 * get the net direction wrong.
 *
 * @param e  rim diameter (mm)
 * @param x  flange-to-centre distance on this side (mm)
 * @param w  flange diameter on this side (mm)
 * @param s  spoke count
 */
function bracingAngleDeg(e,x,w,s){let p=e/2/1e3+.011,r=w/2/1e3,h=Math.cos(4*Math.PI*3/s),inPlane=Math.sqrt(p*p+r*r-2*p*r*h);return Math.atan(x/1e3/inPlane)*180/Math.PI}

/**
 * Applies an offset rim to a hub, returning the geometry the SPOKES see.
 *
 * An offset rim is drilled toward the non-drive side, which lengthens the
 * drive-side spoke's lateral run and shortens the non-drive side's. The hub
 * itself does not move -- only the rim's spoke bed -- so this is the geometry
 * for the strength calculation and the bracing angles, NOT for the flange
 * dimension labels on the diagram, which still describe the hub.
 *
 * Note this can over-correct: on a nearly symmetric hub (Hope Pro5 150 with
 * 157 endcaps is 28.0 / 26.8) even 1mm of offset flips which side is tighter.
 * See tightSideFirst().
 *
 * @param t    hub record { nds, ds, pds, pnds } in mm
 * @param off  rim offset (mm), 0 for a conventional centre-drilled rim
 */
function applyRimOffset(t,off){return{...t,ds:t.ds+off,nds:t.nds-off}}

/**
 * Orders a hub's two sides so the tighter one is `ds`, which is what
 * computeWheelStrength assumes: it takes `ds` as the side built to the
 * tension you set and derives `nds` from lateral equilibrium, so `nds` is
 * always the slack side and F_lat is the load that takes IT to zero.
 *
 * Feed it a hub whose `ds` is actually the looser side and it reports a
 * tension ratio above 100% and a lateral strength for the wrong spoke --
 * too high, because it measured the side with margin to spare. Passing
 * geometry through here first means an over-corrected offset rim reads as
 * what it is: balance improving up to 100%, then falling away again as the
 * imbalance reopens on the other side.
 *
 * Ordered by BRACING ANGLE, not by flange-to-centre distance. Those usually
 * agree, but not when a hub's two flange diameters differ: Project 321's 157
 * is 60.5mm on the drive side and 55mm on the non-drive, so at 3mm of rim
 * offset its two flanges sit at an identical 29mm from centre and the drive
 * side is still the tighter one, because its larger pull circle shortens the
 * spoke. Comparing offsets alone misses that and lets the ratio drift just
 * over 100%.
 *
 * @param t  hub record { nds, ds, pds, pnds } in mm
 * @param e  rim diameter (mm)
 * @param s  spoke count
 */
function tightSideFirst(t,e,s){return bracingAngleDeg(e,t.ds,t.pds,s)<=bracingAngleDeg(e,t.nds,t.pnds,s)?t:{...t,ds:t.nds,nds:t.ds,pds:t.pnds,pnds:t.pds}}

/** Deterministic PRNG (mulberry32-style) so ride simulations are seed-reproducible. */
function seededRandom(e){let t=e>>>0;return()=>(t=Math.imul(t,1664525)+1013904223>>>0,t/4294967296)}

/** Layered pseudo-random noise trace of length t, normalized to [-1, 1]. */
function generateNoiseTrace(e,t,r=3){let n=new Array(t).fill(0);for(let o=0;o<r;o++){let a=seededRandom(e+o*1013),l=Math.pow(2,o),u=Math.pow(.55,o),s=0,f=new Array(t);for(let c=0;c<t;c++)s+=(a()-.5)*.5,s*=.96,f[c]=s;for(let c=0;c<t;c++){let p=c*l%t;n[c]+=f[Math.floor(p)]*u}}let i=Math.max(...n.map(Math.abs))||1;return n.map(o=>o/i)}

/**
 * Generates an illustrative 280-sample lateral-load trace for a ride profile
 * (see RIDE_PROFILES), scaled by rider+bike weight and a "chaos" (0-5) knob.
 */
function simulateRideLoad(e,{chaos:t=3,weightKg:r=REFERENCE_RIDER_WEIGHT_KG,runSeed:n=0}={}){let i=RIDE_PROFILES[e],o=280,a=Math.pow(r/REFERENCE_RIDER_WEIGHT_KG,.85),l=i.noise*(.15+t*.17),u=generateNoiseTrace(i.seed+n*7919,o,3),s=new Array(o);for(let f=0;f<o;f++)s[f]=Math.max(2,i.base+u[f]*l);return i.spikes.forEach(({t:f,peak:c,w:p=5})=>{for(let d=-p;d<=p;d++){let x=f+d;if(x<0||x>=o)continue;let y=Math.pow(1-Math.abs(d)/(p+1),1.8),w=s[x]+(c-s[x])*y;w>s[x]&&(s[x]=w)}}),s.map((f,c)=>({t:c,load:+Math.min(90,Math.max(0,f*a)).toFixed(1)}))}

/** Counts distinct load excursions above threshold t in a load trace e. */
function countOverloadEvents(e,t){let r=0,n=!1;for(let i of e)i.load>t&&!n?(r++,n=!0):i.load<=t&&(n=!1);return r}

/** Single-impact force-vs-time curve (120 samples) for a given scenario + rider weight. */
function impactForceCurve(e,t){let n=Math.pow(t/REFERENCE_RIDER_WEIGHT_KG,.85),i=e.refPeak*n,o=new Array(120).fill(0);if(e.shape==="sharp")for(let a=0;a<120;a++){let u=a-30;o[a]=i*Math.exp(-(u*u)/40)}else if(e.shape==="broad")for(let a=0;a<120;a++){let u=a-45;o[a]=i*Math.exp(-(u*u)/320)}else if(e.shape==="repeat"){let a=[22,45,68,91];for(let l=0;l<120;l++){let u=0;a.forEach((s,f)=>{let c=l-s;u=Math.max(u,i*(1-f*.08)*Math.exp(-(c*c)/28))}),o[l]=u}}else for(let a=0;a<120;a++)a<28?o[a]=i*Math.exp(-((a-28)*(a-28))/24):o[a]=i*Math.exp(-(a-28)/18);return o.map((a,l)=>({t:l,force:+a.toFixed(1)}))}

/** Converts a force trace into a rim-deflection trace, tracking permanent (plastic) set past yield threshold t. */
function deflectionTrace(e,t,r){let n=.02*(100/r),i=0,o=!1;return{trace:e.map(({t:l,force:u})=>{let s;if(u<=t)s=u*n+i;else{let f=u-t,c=f*n*(1+f*.35);i+=f*n*.18,o=!0,s=t*n+c+i}return{t:l,deflection:+s.toFixed(3),force:u}}),plastic:+i.toFixed(2),failed:o}}

/** Classifies a rim's permanent deflection (mm) as Holds / Bends / Taco'd. */
function classifyPermanentSet(e){return e<=0?{word:"Holds",tone:"ok",note:"sprang back"}:e<.5?{word:"Bends",tone:"warn",note:`${e}mm out of true`}:{word:"Taco'd",tone:"fail",note:`${e}mm \u2014 folded`}}

/** Force-vs-deflection curve for the DEEP DIVE chart, given a yield threshold t and stiffness r. */
function deflectionCurve(e,t){let r=.02*(100/t),n=[],i=e*1.35;for(let o=0;o<=i;o+=1){let a;if(o<=e)a=o*r;else{let l=o-e;a=e*r+l*r*(1+l*.35)}n.push({f:+o.toFixed(0),d:+a.toFixed(3)})}return n}

/** Per-spoke tension distribution around the wheel, alternating DS/NDS. */
function spokeTensionDistribution(e,t,r=32,rt){let n=rt!=null?rt/100:e.flangeR/e.flangeL,i=t,o=Math.round(t*n),a=r,l=[];for(let u=0;u<a;u++){let s=u%2===0,f=(u*7%5-2)*.6;l.push({spoke:u+1,tension:Math.round((s?i:o)+f),side:s?"DS":"NDS"})}return{rows:l,dsT:i,ndsT:o,ratio:Math.round(n*100)}}

/** Illustrative S-N (stress vs. cycles-to-failure) fatigue curve for a given yield strength e. */
function fatigueSNCurve(e){let t=[];for(let r=40;r<=130;r+=5){let n=r/100*e,o=Math.pow(e/n,5.5)*1500;t.push({stress:+n.toFixed(0),cycles:Math.max(1,Math.round(o))})}return t}

export {
  spokeAxialStiffness,
  computeWheelStrength,
  bracingAngleDeg,
  applyRimOffset,
  tightSideFirst,
  seededRandom,
  generateNoiseTrace,
  simulateRideLoad,
  countOverloadEvents,
  impactForceCurve,
  deflectionTrace,
  classifyPermanentSet,
  deflectionCurve,
  spokeTensionDistribution,
  fatigueSNCurve,
};
