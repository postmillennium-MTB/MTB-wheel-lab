import { createRoot } from "react-dom/client";
import * as _ from "react/jsx-runtime";
import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";

const root = document.getElementById("root");
createRoot(root).render(
  (0, _.jsx)(ErrorBoundary, { children: (0, _.jsx)(App, {}) })
);
