// --- Hub databases -----------------------------------------------------
// nds/ds = flange-to-center distance (mm) on the non-drive / drive side.
// pds/pnds = flange diameter (mm) on the drive / non-drive side (pull circle).
export const HUBS_148 = [
  { id: "h1", name: "Onyx MFU 148x12", nds: 36.9, ds: 22.92, pds: 50, pnds: 50 },
  { id: "h5", name: "Spank Hex J-Type 148x12", nds: 37, ds: 25, pds: 64, pnds: 58 },
  { id: "h6", name: "CK Centerlock 148x12", nds: 36.3, ds: 24, pds: 57.4, pnds: 57.4 },
  { id: "h8", name: "Project 321 G3 148x12", nds: 32, ds: 22, pds: 60.5, pnds: 55 },
  { id: "h10", name: "I9 Hydra Mountain 6-Bolt 148x12", nds: 38, ds: 25, pds: 60, pnds: 58 },
  { id: "h12", name: "I9 Hydra Centerlock 148x12", nds: 39, ds: 24, pds: 60, pnds: 49 },
  { id: "h14", name: "I9 1/1 Mountain 6-Bolt 148x12", nds: 37, ds: 23, pds: 60, pnds: 58 },
  { id: "h15", name: "Hope Pro5 6-Bolt 148x12", nds: 35, ds: 22.6, pds: 59, pnds: 57 },
  { id: "h17", name: "Erase MTB IS V2 148x12", nds: 38, ds: 25, pds: 56, pnds: 50 },
  { id: "h20", name: "Hadley 148x12", nds: 37.1, ds: 22.9, pds: 59, pnds: 52 },
  { id: "h21", name: "OneUp 148x12", nds: 38, ds: 23, pds: 48, pnds: 52 },
  { id: "h23", name: "KOM Xeno 148x12", nds: 30.5, ds: 23.5, pds: 46, pnds: 46 },
  { id: "h27", name: "DMR Zone Centerlock 148x12", nds: 38, ds: 21, pds: 56, pnds: 56 },
  { id: "h28", name: "DT Swiss 350 6-Bolt 148x12", nds: 36.6, ds: 23.3, pds: 52, pnds: 58 },
  { id: "h30", name: "e*thirteen Sidekick 148x12", nds: 38, ds: 21, pds: 60, pnds: 60 },
];

export const HUBS_157 = [
  { id: "h2", name: "Onyx 157x12", nds: 41.4, ds: 27.42, pds: 50, pnds: 50 },
  { id: "h3", name: "Onyx Vesper 157x12", nds: 41.4, ds: 26.97, pds: 50, pnds: 42 },
  { id: "h4", name: "Spank Hex J-Type 157x12", nds: 39.5, ds: 29.5, pds: 64, pnds: 58 },
  { id: "h7", name: "CK Centerlock 157x12", nds: 40.3, ds: 28.8, pds: 57.4, pnds: 57.4 },
  { id: "h9", name: "Project 321 G3 157x12", nds: 32, ds: 26.5, pds: 60.5, pnds: 55 },
  { id: "h11", name: "I9 Hydra 6-Bolt 157x12", nds: 41, ds: 29, pds: 60, pnds: 58 },
  { id: "h13", name: "I9 Hydra Centerlock 157x12", nds: 43, ds: 28, pds: 60, pnds: 49 },
  { id: "h16", name: "Hope Pro5 6-Bolt 157x12", nds: 39.6, ds: 27, pds: 59, pnds: 57 },
  { id: "h18", name: "Erase MTB IS V2 157x12", nds: 42.5, ds: 29.5, pds: 56, pnds: 50 },
  { id: "h19", name: "Hadley 157x12", nds: 41.5, ds: 27.5, pds: 59, pnds: 59 },
  { id: "h22", name: "OneUp 157x12", nds: 35, ds: 26, pds: 48, pnds: 52.5 },
  { id: "h24", name: "KOM Xeno 157x12", nds: 35, ds: 28, pds: 46, pnds: 46 },
  // h25 (Hope Pro5 150 6-bolt w/ 157 endcap conv) removed 2026-09: a 150
  // shell converted with endcaps is barely dished to begin with, so its
  // ~96% tension-balance ratio was an outlier next to every other 157 here
  // (the next-highest sits around 82%) -- not a well-balanced conventional
  // build, just a different thing to measure. See wheel-comparison-widget2's
  // README for the fuller removal note and this hub's sourcing history.
  { id: "h26", name: "DMR Zone Centerlock 157x12", nds: 41, ds: 25, pds: 56, pnds: 56 },
  { id: "h29", name: "DT Swiss 350 6-Bolt 157x12", nds: 41.1, ds: 27.9, pds: 50.5, pnds: 60 },
  { id: "h31", name: "e*thirteen Sidekick Pro 157x12", nds: 42.5, ds: 25.5, pds: 60, pnds: 60 },
];

// Where each hub's geometry was read from, for the HUB SPECS tab. Only hubs
// whose source document was recorded are listed (see wheel-comparison-widget2's
// README, "Primary source documents"); the rest show "source file not
// recorded". straightPull marks hubs built with straight-pull spokes (every
// other hub in the catalogue is J-bend).
const SRC = {
  KOM: "KOM 2023v8.0 hub offset/PCD PDF",
  HOPE: "Hope Pro5 PCD J-Bend 2025 PDF",
  DT: "DT Swiss spoke calculator",
  DMR: "DMR Zone product pages",
  ONEUP: "OneUp product pages",
  E13: "e*thirteen Sidekick dimensions article",
};
export const HUB_SOURCES = {
  h15: { source: SRC.HOPE }, h16: { source: SRC.HOPE },
  h21: { source: SRC.ONEUP }, h22: { source: SRC.ONEUP },
  h23: { source: SRC.KOM, straightPull: true }, h24: { source: SRC.KOM, straightPull: true },
  h26: { source: SRC.DMR }, h27: { source: SRC.DMR },
  h28: { source: SRC.DT }, h29: { source: SRC.DT },
  h30: { source: SRC.E13 }, h31: { source: SRC.E13 },
};

// Effective rim diameter (mm) by wheel size, used as the "rim diameter" input
// to the Mode Matrix stiffness/strength calculation. One typical value per
// size, each from a manufacturer's published spec (not the TK540's own ERD;
// real rims vary by a few mm, e.g. Reserve 30|XC 29" is 599 vs 605):
//   26"   538  DT Swiss FR 560 26", "Reference diameter ERD 538 mm"
//   27.5" 567  Tenet Coven AL, "ERD 567 mm (27.5) / 605 mm (29)"
//   29"   605  Tenet Coven AL, same page
//   32"   649  Reserve 30|XC 32", "32" ERD 649mm"
// Until Nov 2026 these were 534 / 559 / 600 / 667 mm with no source recorded.
export const RIM_ERD_BY_SIZE = { 26: 538, "27.5": 567, 29: 605, 32: 649 };

// Physical constants for the wheel model (Ford Mode Matrix method).
// EIL/EIR: rim lateral/radial bending stiffness (N*m^2).
// GJ: rim torsional stiffness (N*m^2). EA_rim: rim axial stiffness (N).
// modes: number of vibration-mode harmonics summed in the calculation.
// Units are N*m^2: computeWheelStrength works in metres throughout.
//
// The rim is the DT Swiss TK540 as measured by Ford, Peng & Balogun's
// acoustic method (Ford, Peng and Balogun 2018; values from Ford's rim
// stiffness library, https://bicyclewheel.info/rim-stiffness/):
// EI_lat 260, EI_rad 211, GJ 75 N*m^2, mass 550 g. The library lists no
// axial stiffness, so EA_rim follows Ford's wheel-app: E * mass /
// (2*pi*r*rho) with alloy E 69 GPa, rho 2700 kg/m^3, r = 0.311 m (622 mm
// bead seat), giving 7.2 MN. Every wheel size and build uses this one rim.
// Until Nov 2026 the tools used 50/150/22 N*m^2 and 11.5 MN, an unsourced
// placeholder softer laterally than any rim Ford measured.
export const PHYS_CONSTANTS = { EIL: 260, EIR: 211, GJ: 75, EA_rim: 72e5, modes: 24 };

// Static illustrative geometry for the two hub standards: labels, tags and
// the fallback diagram dimensions. The SIMULATION tab's "STRENGTH METRICS"
// panel used to read hand-set index numbers from here (75 vs 100 and so on);
// it now reads the Mode Matrix result for the two selected hubs instead.
export const HUB_GEOMETRY = {
  148: {
    label: "148mm Boost", tag: "Trail / XC / Enduro",
    DS_px: 39, NDS_px: 72, flangeR: 20, flangeL: 37,
    DS_angle: "4.0\xB0", NDS_angle: "7.3\xB0",
  },
  157: {
    label: "157mm Super Boost", tag: "Enduro / DH / Aggressive",
    DS_px: 49, NDS_px: 81, flangeR: 24.5, flangeL: 41.5,
    DS_angle: "4.8\xB0", NDS_angle: "8.2\xB0",
  },
};

// The SIMULATION and DEEP DIVE tabs used to draw their strength lines from
// two fixed numbers here (36 kgf for 148, 42 for 157) scaled by spoke count,
// wheel size, offset and tension -- never by the hub you picked, and never
// agreeing with the COMPARE tab. They now use the same Mode Matrix F_lat as
// COMPARE, for the two hubs selected there.

// Rows of the STRENGTH METRICS panel. Every value comes from the Mode Matrix
// result for the two selected hubs (see strengthMetrics in physics.js).
// Torsional stiffness was dropped: nothing in this app computes it.
export const STRENGTH_METRIC_LIST = [
  { key: "Lateral Strength", note: "side load before the first spoke goes slack", unit: "kgf", digits: 1 },
  { key: "Lateral Stiffness", note: "side-flex resistance", unit: "N/mm", digits: 1 },
  { key: "Radial Strength", note: "vertical hit before the first spoke goes slack", unit: "kgf", digits: 0 },
  { key: "Tension Balance", note: "NDS/DS spoke tension ratio", unit: "%", digits: 1 },
];

// Reference rider+bike weight (kg) that the illustrative load curves below
// were tuned against; simulated loads scale from this baseline.
export const REFERENCE_RIDER_WEIGHT_KG = 82;

// The ride profiles and impact scenarios below were authored against the old
// fixed 36/42 kgf thresholds. The thresholds are now the Mode Matrix F_lat
// (first-spoke-slack). For the default CK pair (29", 28 spokes, 120 kgf) on
// the measured TK540 rim and ERD 605 mm that is 38.3 and 45.8 kgf, about
// 1.06x and 1.09x the old figures. Every simulated load is multiplied by this one factor so
// the scripted rides keep the same relation to the reference build they were
// drawn for. (It was 0.55 while the tools used the softer 50/150/22 rim,
// whose F_lat was about half as high, and 1.09 at ERD 600 mm.) The loads stay illustrative: they are
// not measured trail data. The factor stays tied to that 28-spoke build;
// the default became 32 spokes on Nov 12 2026 (to match the widget), which
// raises F_lat to 42.5 / 50.9 kgf, so the same loads now sit a little
// further under both lines.
export const RIDE_LOAD_SCALE = 1.08;

// Illustrative ride-load profiles used on the SIMULATION tab. Each has a
// baseline noise floor plus a handful of scripted "spike" impacts.
export const RIDE_PROFILES = {
  XC: { base: 8, noise: 5, seed: 42, spikes: [{ t: 55, peak: 24, w: 4 }, { t: 135, peak: 22, w: 3 }, { t: 200, peak: 26, w: 4 }] },
  Trail: { base: 11, noise: 7, seed: 137, spikes: [{ t: 45, peak: 29, w: 4 }, { t: 93, peak: 32, w: 4 }, { t: 148, peak: 38, w: 5 }, { t: 196, peak: 33, w: 4 }, { t: 246, peak: 37, w: 5 }] },
  Enduro: { base: 15, noise: 9, seed: 256, spikes: [{ t: 30, peak: 32, w: 4 }, { t: 76, peak: 37, w: 5 }, { t: 112, peak: 40, w: 5 }, { t: 158, peak: 37, w: 4 }, { t: 196, peak: 41, w: 6 }, { t: 242, peak: 37, w: 5 }, { t: 268, peak: 34, w: 3 }] },
  DH: { base: 20, noise: 10, seed: 999, spikes: [{ t: 28, peak: 38, w: 5 }, { t: 62, peak: 41, w: 5 }, { t: 92, peak: 37, w: 4 }, { t: 124, peak: 44, w: 5 }, { t: 155, peak: 39, w: 4 }, { t: 184, peak: 45, w: 5 }, { t: 213, peak: 38, w: 5 }, { t: 247, peak: 41, w: 5 }, { t: 270, peak: 38, w: 4 }] },
};

export const RIDE_PROFILE_META = {
  XC: { label: "XC / Gravel", desc: "Smooth surfaces, minimal tech" },
  Trail: { label: "Trail", desc: "Mixed singletrack with rocks and roots" },
  Enduro: { label: "Enduro", desc: "Technical descents, chunky terrain" },
  DH: { label: "Downhill", desc: "Extreme terrain, jumps, high-speed impacts" },
};

// Single-impact scenarios used on the "SLOW-MO SINGLE IMPACT" panel.
// refPeak is the hit's sideways part and refDown its straight-down part, in
// kgf for the 82 kg reference rider+bike, before RIDE_LOAD_SCALE and the
// rider-weight scaling in hitLoads(). Both are ESTIMATES chosen for
// illustration, not measured trail loads: the Lab has no sourced MTB hit
// data. refDown was added in Nov 2026 so SIMULATION can plot each hit on
// the load envelope; whether a dot lands inside or outside the shape is
// exact in Ford's model, only the hit size is a guess.
export const IMPACT_SCENARIOS = {
  rock: { label: "Rock strike", refPeak: 33, refDown: 60, shape: "sharp", desc: "Sudden edge hit \u2014 sharp, narrow spike" },
  huck: { label: "Huck to flat", refPeak: 41, refDown: 150, shape: "broad", desc: "Flat landing off a drop \u2014 big sustained load" },
  garden: { label: "Rock garden", refPeak: 36, refDown: 40, shape: "repeat", desc: "Rapid repeated medium hits" },
  cased: { label: "Cased a double", refPeak: 50, refDown: 180, shape: "slam", desc: "Came up short \u2014 hard rim slam" },
};
