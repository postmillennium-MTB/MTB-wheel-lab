// --- Hub databases -----------------------------------------------------
// nds/ds = flange-to-center distance (mm) on the non-drive / drive side.
// pds/pnds = flange diameter (mm) on the drive / non-drive side (pull circle).
export const HUBS_148 = [
  { id: "h1", name: "Onyx 148 MFU", nds: 36.9, ds: 22.92, pds: 50, pnds: 50 },
  { id: "h5", name: "Spank Hex J-Type Boost R148", nds: 37, ds: 25, pds: 64, pnds: 58 },
  { id: "h6", name: "CK 148x12 Centerlock Rear", nds: 36.3, ds: 24, pds: 57.4, pnds: 57.4 },
  { id: "h8", name: "Project 321 G3 148x12", nds: 32, ds: 22, pds: 60.5, pnds: 55 },
  { id: "h10", name: "Hydra Mountain 6-Bolt 148", nds: 38, ds: 25, pds: 60, pnds: 58 },
  { id: "h12", name: "I9 Hydra Centerlock 148", nds: 39, ds: 24, pds: 60, pnds: 49 },
  { id: "h14", name: "I9 1/1 Mountain 6-Bolt 148", nds: 37, ds: 23, pds: 60, pnds: 58 },
  { id: "h15", name: "Hope Pro5 148 6-bolt", nds: 35, ds: 22.6, pds: 59, pnds: 57 },
  { id: "h17", name: "Erase MTB IS 148x12 V2", nds: 38, ds: 25, pds: 56, pnds: 50 },
  { id: "h20", name: "Hadley 148x12", nds: 37.1, ds: 22.9, pds: 59, pnds: 52 },
];

export const HUBS_157 = [
  { id: "h2", name: "Onyx 150/157", nds: 41.4, ds: 27.42, pds: 50, pnds: 50 },
  { id: "h3", name: "Onyx 150/157 Vesper", nds: 41.4, ds: 26.97, pds: 50, pnds: 42 },
  { id: "h4", name: "Spank Hex J-Type R150/157", nds: 39.5, ds: 29.5, pds: 64, pnds: 58 },
  { id: "h7", name: "CK 157 SB Centerlock Rear", nds: 40.3, ds: 28.8, pds: 57.4, pnds: 57.4 },
  { id: "h9", name: "Project 321 G3 157 SB", nds: 32, ds: 26, pds: 60.5, pnds: 55 },
  { id: "h11", name: "I9 Hydra 6-Bolt 150/157", nds: 41, ds: 29, pds: 60, pnds: 58 },
  { id: "h13", name: "I9 Hydra Centerlock 157 SB", nds: 43, ds: 28, pds: 60, pnds: 49 },
  { id: "h16", name: "Hope Pro5 150/157 6-bolt", nds: 28, ds: 25.8, pds: 59, pnds: 57 },
  { id: "h18", name: "Erase MTB IS 157x12 V2", nds: 42.5, ds: 29.5, pds: 56, pnds: 50 },
  { id: "h19", name: "Hadley 150/157", nds: 41.5, ds: 27.5, pds: 59, pnds: 59 },
];

// Effective rim diameter (mm) by wheel size, used as the "rim diameter" input
// to the Mode Matrix stiffness/strength calculation.
export const RIM_ERD_BY_SIZE = { 26: 534, "27.5": 559, 29: 600, 32: 667 };

// Physical constants for the wheel model (Ford Mode Matrix method).
// EIL/EIR: rim lateral/radial bending stiffness (N*mm^2).
// GJ: rim torsional stiffness (N*mm^2). EA_rim: rim axial stiffness (N).
// modes: number of vibration-mode harmonics summed in the calculation.
export const PHYS_CONSTANTS = { EIL: 50, EIR: 150, GJ: 22, EA_rim: 115e5, modes: 24 };

// Static illustrative geometry + relative strength-index metrics for the
// two hub standards, used on the COMPARE tab's "STRENGTH METRICS" panel.
export const HUB_GEOMETRY = {
  148: {
    label: "148mm Boost", tag: "Trail / XC / Enduro",
    DS_px: 39, NDS_px: 72, flangeR: 20, flangeL: 37,
    DS_angle: "4.0\xB0", NDS_angle: "7.3\xB0",
    metrics: { "Lateral Stiffness": 75, "Bracing Balance": 60, "Tension Balance": 70, "Torsional Stiffness": 88 },
  },
  157: {
    label: "157mm Super Boost", tag: "Enduro / DH / Aggressive",
    DS_px: 49, NDS_px: 81, flangeR: 24.5, flangeL: 41.5,
    DS_angle: "4.8\xB0", NDS_angle: "8.2\xB0",
    metrics: { "Lateral Stiffness": 100, "Bracing Balance": 83, "Tension Balance": 83, "Torsional Stiffness": 100 },
  },
};

// Base illustrative overload thresholds (kgf) for the SIMULATION tab's ride-load
// chart, at reference conditions (28 spokes, 29" wheel, no rim offset, 100kgf
// tension). Scaled by spoke count/rim size/offset/tension at the call site.
// Distinct from the Mode Matrix F_lat strength figure used on the COMPARE tab.
export const BASE_THRESHOLD_157 = 42;
export const BASE_THRESHOLD_148 = 36;

export const STRENGTH_METRIC_LIST = [
  { key: "Lateral Stiffness", note: "side-flex resistance" },
  { key: "Bracing Balance", note: "DS vs NDS angle symmetry" },
  { key: "Tension Balance", note: "NDS/DS spoke tension ratio" },
  { key: "Torsional Stiffness", note: "brake/pedal torque resistance" },
];

// Reference rider+bike weight (kg) that the illustrative load curves below
// were tuned against; simulated loads scale from this baseline.
export const REFERENCE_RIDER_WEIGHT_KG = 82;

// Illustrative ride-load profiles used on the SIMULATION tab. Each has a
// baseline noise floor plus a handful of scripted "spike" impacts.
export const RIDE_PROFILES = {
  XC: { base: 8, noise: 5, seed: 42, spikes: [{ t: 55, peak: 24, w: 4 }, { t: 135, peak: 22, w: 3 }, { t: 200, peak: 26, w: 4 }] },
  Trail: { base: 11, noise: 7, seed: 137, spikes: [{ t: 45, peak: 29, w: 4 }, { t: 93, peak: 32, w: 4 }, { t: 148, peak: 38, w: 5 }, { t: 196, peak: 33, w: 4 }, { t: 246, peak: 37, w: 5 }] },
  Enduro: { base: 15, noise: 9, seed: 256, spikes: [{ t: 30, peak: 32, w: 4 }, { t: 76, peak: 37, w: 5 }, { t: 112, peak: 40, w: 5 }, { t: 158, peak: 37, w: 4 }, { t: 196, peak: 41, w: 6 }, { t: 242, peak: 37, w: 5 }, { t: 268, peak: 34, w: 3 }] },
  DH: { base: 20, noise: 10, seed: 999, spikes: [{ t: 28, peak: 38, w: 5 }, { t: 62, peak: 41, w: 5 }, { t: 92, peak: 37, w: 4 }, { t: 124, peak: 44, w: 5 }, { t: 155, peak: 39, w: 4 }, { t: 184, peak: 45, w: 5 }, { t: 213, peak: 38, w: 5 }, { t: 247, peak: 41, w: 5 }, { t: 270, peak: 38, w: 4 }] },
};

export const RIDE_PROFILE_META = {
  XC: { label: "XC / Gravel", desc: "Smooth surfaces, minimal tech" },
  Trail: { label: "Trail", desc: "Mixed singletrack with rocks and roots" },
  Enduro: { label: "Enduro", desc: "Technical descents, chunky terrain" },
  DH: { label: "Downhill", desc: "Extreme terrain, jumps, high-speed impacts" },
};

// Single-impact scenarios used on the "SLOW-MO SINGLE IMPACT" panel.
export const IMPACT_SCENARIOS = {
  rock: { label: "Rock strike", refPeak: 33, shape: "sharp", desc: "Sudden edge hit \u2014 sharp, narrow spike" },
  huck: { label: "Huck to flat", refPeak: 41, shape: "broad", desc: "Flat landing off a drop \u2014 big sustained load" },
  garden: { label: "Rock garden", refPeak: 36, shape: "repeat", desc: "Rapid repeated medium hits" },
  cased: { label: "Cased a double", refPeak: 50, shape: "slam", desc: "Came up short \u2014 hard rim slam" },
};
