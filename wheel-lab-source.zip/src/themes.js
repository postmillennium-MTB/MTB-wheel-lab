// Four selectable color themes for the app chrome.
// h148/h157 are the two hubs' colors, used for everything that belongs to one
// hub: its lines, bars, values and its first-slack threshold. A hub never gets
// a second color (the SIMULATION thresholds used to have their own cap148/
// cap157 pair, which collided with the hub colors in two themes and failed the
// colorblind check in two more), and nothing else is drawn in a hub color: the
// SIMULATION ride-load trace is drawn in the text color. Roly-Poly's h148 is a
// dark raspberry rather than the lighter pink it started as, because that pink
// and the teal had the same lightness and merged under deuteranopia
// (OKLab dE 3.9; now 11.5). slack/taco are the
// failure map's two line colors (a spoke goes slack / the rim tacos), kept
// apart from the hub colors so each line means one thing in every theme.
// grid = [minor, major] opacity of the graph-paper background lines (8px
// minor / 40px major), drawn in the theme's text color so the texture is
// neutral and never reads as a data color. Light themes need a little more
// ink than dark ones for the same visibility.
export const THEMES = {
  c1: {
    name: "No Quarter",
    bg: "#1A1614", surf: "#241E1B", surfl: "#2E2723", bdr: "#473C35",
    txt: "#F0E8E2", muted: "#A8978C", dim: "#5A4D44", acc: "#C9A227",
    ok: "#C9A227", warn: "#E08A2B", fail: "#D6452B",
    h148: "#C9A227", h157: "#D6452B",
    slack: "#FF6A45", taco: "#7FA6E8",
    grid: [0.035, 0.05],
  },
  c2: {
    name: "Space Force",
    bg: "#141826", surf: "#1C2236", surfl: "#252C44", bdr: "#3A445E",
    txt: "#E6ECFF", muted: "#8A96B8", dim: "#4A5578", acc: "#22D3EE",
    ok: "#22D3EE", warn: "#A78BFA", fail: "#F472B6",
    h148: "#8B5CF6", h157: "#22D3EE",
    slack: "#FB923C", taco: "#A3E635",
    grid: [0.035, 0.05],
  },
  c3: {
    name: "Roly-Poly",
    bg: "#E8E6EA", surf: "#F3F1F5", surfl: "#FAF8FC", bdr: "#C9C3CF",
    txt: "#2A2230", muted: "#675D72", dim: "#A89EB2", acc: "#0C9488",
    ok: "#0C9488", warn: "#B45309", fail: "#DC2626",
    h148: "#A21C5C", h157: "#0C9488",
    slack: "#E8401C", taco: "#2C5BA6",
    grid: [0.045, 0.06],
  },
  c4: {
    name: "Paperboy",
    bg: "#1C2433", surf: "#26303F", surfl: "#303B4D", bdr: "#445063",
    txt: "#EAF0F7", muted: "#90A0B5", dim: "#4E5C72", acc: "#22C55E",
    ok: "#22C55E", warn: "#FACC15", fail: "#EF4444",
    h148: "#3B82F6", h157: "#F97316",
    slack: "#EC4899", taco: "#93C5FD",
    grid: [0.035, 0.05],
  },
};

// Graph-paper line color: the theme's text color at the theme's grid opacity,
// as an 8-digit hex. which = 0 (minor, 8px) or 1 (major, 40px).
export function gridInk(t, which) {
  const a = Math.round(((t.grid || [0, 0])[which]) * 255);
  return t.txt + a.toString(16).padStart(2, "0");
}

export const THEME_KEYS = ["c1", "c2", "c3", "c4"];

export function nextThemeKey(currentKey) {
  const i = THEME_KEYS.indexOf(currentKey);
  return THEME_KEYS[(i + 1) % THEME_KEYS.length];
}
