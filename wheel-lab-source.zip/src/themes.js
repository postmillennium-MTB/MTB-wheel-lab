// Four selectable color themes for the app chrome.
// h148/h157/cap148/cap157/impact are used specifically for the 148mm-vs-157mm
// comparison visuals (lines, dots, highlight badges).
export const THEMES = {
  c1: {
    name: "No Quarter",
    bg: "#1A1614", surf: "#241E1B", surfl: "#2E2723", bdr: "#473C35",
    txt: "#F0E8E2", muted: "#A8978C", dim: "#5A4D44", acc: "#C9A227",
    ok: "#C9A227", warn: "#E08A2B", fail: "#D6452B",
    h148: "#C9A227", h157: "#D6452B", cap148: "#D6452B", cap157: "#FF6B3D",
    impact: "#E8C24A",
  },
  c2: {
    name: "Space Force",
    bg: "#141826", surf: "#1C2236", surfl: "#252C44", bdr: "#3A445E",
    txt: "#E6ECFF", muted: "#8A96B8", dim: "#4A5578", acc: "#22D3EE",
    ok: "#22D3EE", warn: "#A78BFA", fail: "#F472B6",
    h148: "#8B5CF6", h157: "#22D3EE", cap148: "#A78BFA", cap157: "#F0F9FF",
    impact: "#38BDF8",
  },
  c3: {
    name: "Roly-Poly",
    bg: "#E8E6EA", surf: "#F3F1F5", surfl: "#FAF8FC", bdr: "#C9C3CF",
    txt: "#2A2230", muted: "#675D72", dim: "#A89EB2", acc: "#0C9488",
    ok: "#0C9488", warn: "#B45309", fail: "#DC2626",
    h148: "#DB2777", h157: "#0C9488", cap148: "#B45309", cap157: "#DC2626",
    impact: "#DB2777",
  },
  c4: {
    name: "Paperboy",
    bg: "#1C2433", surf: "#26303F", surfl: "#303B4D", bdr: "#445063",
    txt: "#EAF0F7", muted: "#90A0B5", dim: "#4E5C72", acc: "#22C55E",
    ok: "#22C55E", warn: "#FACC15", fail: "#EF4444",
    h148: "#3B82F6", h157: "#F97316", cap148: "#22C55E", cap157: "#EF4444",
    impact: "#60A5FA",
  },
};

export const THEME_KEYS = ["c1", "c2", "c3", "c4"];

export function nextThemeKey(currentKey) {
  const i = THEME_KEYS.indexOf(currentKey);
  return THEME_KEYS[(i + 1) % THEME_KEYS.length];
}
