import * as React from "react";
import { HUBS_148, HUBS_157 } from "../data.js";

// "Compare these two": turns a pick in a catalogue table (TENSION BALANCE's
// highlighted rows, HUB SPECS' picked rows) into the COMPARE tab's two hubs.
// COMPARE always holds one 148 and one 157 hub, so the newest pick of each
// standard is used; a standard with no pick keeps the hub COMPARE already
// has, and the button says so. Colors come from the host tab (`ink`), since
// HUB SPECS has its own palette.

const nameOf = (list, id) => (list.find((h) => h.id === id) || {}).name || "";

// The newest picked id of each standard, from an insertion-ordered list.
export function newestPicks(ids) {
  let a = null, b = null;
  for (const id of ids) {
    if (HUBS_148.some((h) => h.id === id)) a = id;
    else if (HUBS_157.some((h) => h.id === id)) b = id;
  }
  return [a, b];
}

export default function CompareThese({ picks, current, onCompare, ink, hint }) {
  const [p148, p157] = picks;
  if (!onCompare) return null;
  if (!p148 && !p157) {
    return hint ? <div style={{ fontSize: 11, color: ink.muted, margin: "0 0 8px" }}>{hint}</div> : null;
  }
  const a = p148 || current[0], b = p157 || current[1];
  const label = (id, picked, list) => nameOf(list, id) + (picked ? "" : " (already in COMPARE)");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, margin: "0 0 10px" }}>
      <button type="button" onClick={() => onCompare(a, b)}
        style={{ font: "700 12px Space Grotesk, system-ui, sans-serif", color: ink.fg, background: ink.panel, border: `1.5px solid ${ink.fg}`, borderRadius: 6, padding: "7px 12px", cursor: "pointer", textAlign: "left", lineHeight: 1.35 }}>
        Compare {label(a, !!p148, HUBS_148)} vs {label(b, !!p157, HUBS_157)} {"→"}
      </button>
      {!(p148 && p157) && <span style={{ fontSize: 10.5, color: ink.muted }}>Pick a {p148 ? "157" : "148"} hub too to choose both.</span>}
    </div>
  );
}
