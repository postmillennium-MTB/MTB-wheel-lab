import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

/** Segmented-button toggle group (e.g. spoke count, rim size, ride profile). */
function ToggleGroup({label:e,opts:t,val:r,set:n,activeColor:i}){return(0,_.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:6},children:[(0,_.jsx)("span",{style:{fontSize:10,color:j.muted},children:e}),(0,_.jsx)("div",{style:{display:"flex",border:`1px solid ${j.bdr}`,borderRadius:5,overflow:"hidden"},children:t.map((o,a)=>(0,_.jsx)("button",{onClick:()=>n(o),style:{padding:"4px 9px",border:"none",cursor:"pointer",borderLeft:a?`1px solid ${j.bdr}`:"none",background:r===o?i||j.acc:j.surfl,color:r===o?j.bg:j.muted,fontSize:10,fontFamily:"Space Mono, monospace",fontWeight:r===o?700:400},children:o},o))})]})}

export default ToggleGroup;
