import * as React from "react";
import { theme as j } from "../theme-state.js";
import { spokeModel, spokeTensions, firstSlackTorque } from "../physics.js";
import Section from "./Section.jsx";
import ToggleGroup from "./ToggleGroup.jsx";
import { useHubFade, useNarrow, fadeStyle, HubFadeControls, HubFadeTitle } from "./HubFade.jsx";
import { WindUpSection, Study, Lead, Foot, MONO } from "./InsightsTab.jsx";

// TORSION: everything about pedal and brake torque in one place.
//
//   1. Torque spoke ring (strength). Every spoke's tension while the hub is
//      twisted, from wheel-physics-core's per-spoke output: with the hub held
//      still, as in Matthew Ford's model, the ground's push on the tire is
//      applied as a tangential load torque / R at the contact point
//      (spokeTensions { torque }, firstSlackTorque). Checked against Ford's
//      bike-wheel-calc in the core's validation/spokes/, with the radial and
//      tangential components applied in one F_ext call. Exact in his linear
//      model up to the first spoke going slack.
//   2. Wind-up stiffness (stiffness), moved here from INSIGHTS, closed by
//      default.

const MODES = ["Pedal", "Rear brake"];
const RIDER = ["No rider", "Rider on"];
const REAR_SHARE = 0.6;          // share of rider + bike on the rear wheel, seated (estimate)
const PRESET = { Pedal: 300, "Rear brake": 200 };   // N·m, estimates (see Foot)
const WIDE = { w: 640, h: 470, cx: 200, cy: 200, Rr: 168, Rh: 30, sx: 418, sw: 206, top: 34, bot: 360 };
const NARROW = { w: 420, h: 730, cx: 210, cy: 196, Rr: 170, Rh: 30, sx: 46, sw: 352, top: 478, bot: 640 };
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

// Same color rule as the COMPARE spoke ring: tighter than built shades toward
// `taco`, losing tension toward `slack`; slack spokes are also dashed.
function tensionColor(pct) {
  if (pct <= 0) return j.slack;
  if (pct >= 1) {
    const a = Math.min(1, (pct - 1) / 0.25);
    return a < 0.15 ? j.txt : `color-mix(in srgb, ${j.taco} ${Math.round(a * 100)}%, ${j.txt})`;
  }
  const a = Math.min(1, (1 - pct) / 0.7);
  return a < 0.15 ? j.txt : `color-mix(in srgb, ${j.slack} ${Math.round(a * 100)}%, ${j.txt})`;
}

function Ring({ cases, torque, mode, shown, narrow }) {
  const L = narrow ? NARROW : WIDE;
  const { cx, cy, Rr, Rh, sx, sw, top, bot } = L;
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 12.5 : 11 };
  const lbl = { fill: j.txt, fontFamily: "Space Grotesk, system-ui", fontSize: narrow ? 13.5 : 12.5, fontWeight: 500 };
  const tmax = Math.ceil(Math.max(...cases.map((c) => Math.max(...c.now, ...c.T0))) * 1.1 / 40) * 40;
  const Ys = (v) => bot - Math.max(-12, v) / tmax * (bot - top);
  const yTicks = [];
  for (let v = 0; v <= tmax - 10; v += 40) yTicks.push(v);
  const fade = fadeStyle();
  // +torque = the ground pushing the tire toward increasing rim angle, which
  // is to the left at the bottom of this drawing.
  const dir = mode === MODES[0] ? -1 : 1;

  const layer = (c, k) => {
    const s = c.m.res.spokes, p0 = s.loadTh[c.pos];
    const ang = (th) => th - p0 + Math.PI / 2;          // contact point at the bottom
    const order = s.T.map((_, i) => i).sort((a, b) => (c.m.realSide(a) === "DS") - (c.m.realSide(b) === "DS"));
    const rel = s.th.map((th, i) => {
      let a = th - p0;
      while (a > Math.PI) a -= 2 * Math.PI;
      while (a <= -Math.PI) a += 2 * Math.PI;
      return { i, a };
    }).sort((u, v) => v.a - u.a);                       // left of the bars = left of the wheel
    const bw = sw / rel.length;
    return (
      <g key={k} style={{ opacity: shown === k ? 1 : 0, transition: fade }} aria-hidden={shown !== k}>
        {order.map((i) => {
          const a = ang(s.th[i]), ah = ang(s.thHub[i]);
          return (
            <line key={i} x1={cx + Rh * Math.cos(ah)} y1={cy + Rh * Math.sin(ah)} x2={cx + (Rr - 2) * Math.cos(a)} y2={cy + (Rr - 2) * Math.sin(a)}
              stroke={tensionColor(c.now[i] / c.T0[i])} strokeWidth={c.m.realSide(i) === "DS" ? 2.6 : 1.4} strokeLinecap="round"
              strokeDasharray={c.now[i] <= 0 ? "3 4" : undefined} />
          );
        })}
        {rel.map(({ i }, n) => {
          const v = c.now[i], x = sx + n * bw + 1, y0 = Ys(0), y1 = Ys(v);
          return (
            <g key={i}>
              <rect x={x} y={Math.min(y0, y1)} width={Math.max(0.5, bw - 2)} height={Math.max(1.5, Math.abs(y1 - y0))}
                fill={tensionColor(v / c.T0[i])} opacity={c.m.realSide(i) === "DS" ? 1 : 0.62} />
              <line x1={x} x2={x + bw - 2} y1={Ys(c.T0[i])} y2={Ys(c.T0[i])} stroke={j.muted} strokeWidth={1} />
            </g>
          );
        })}
      </g>
    );
  };

  const g = cy + Rr + 22;
  return (
    <svg viewBox={`0 0 ${L.w} ${L.h}`} role="img" aria-label="Wheel with each spoke colored by its tension under pedal or brake torque"
      style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}>
      <circle cx={cx} cy={cy} r={Rr + 14} fill="none" stroke={j.muted} strokeWidth={10} opacity={0.18} />
      <circle cx={cx} cy={cy} r={Rr} fill="none" stroke={j.txt} strokeWidth={4} />
      <text {...lbl} x={sx} y={top - 16}>each spoke, under torque (kgf)</text>
      {yTicks.map((v) => (
        <g key={v}>
          <line x1={sx} x2={sx + sw} y1={Ys(v)} y2={Ys(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.6} />
          <text {...txt} x={sx - 4} y={Ys(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      {cases.map(layer)}
      <circle cx={cx} cy={cy} r={Rh + 3} fill={j.surf} stroke={j.txt} strokeWidth={2} />
      <circle cx={cx} cy={cy} r={9} fill={j.txt} />
      <line x1={cx - 120} x2={cx + 120} y1={g} y2={g} stroke={j.muted} strokeWidth={2} />
      <path d={`M${cx},${g - 7} h${dir * 40}`} stroke={j.slack} strokeWidth={3} fill="none" />
      <path d={`M${cx + dir * 54},${g - 7} l${-dir * 14},-7 v14 z`} fill={j.slack} />
      <text {...lbl} x={cx} y={cy + Rr + (narrow ? 58 : 50)} textAnchor="middle"
        style={{ stroke: j.surf, strokeWidth: 4, paintOrder: "stroke", strokeLinejoin: "round" }}>
        {`${mode === MODES[0] ? "ground pushes tire forward" : "ground drags tire back"} · ${fmt(torque)} N·m`}
      </text>
      <text {...txt} x={sx} y={bot + 16}>← half a turn</text>
      <text {...txt} x={sx + sw} y={bot + 16} textAnchor="end">half a turn →</text>
      <text {...txt} x={sx + sw / 2} y={bot + 32} textAnchor="middle" fill={j.slack}>▲ contact</text>
      <text {...txt} x={sx} y={bot + 56}>tick = tension as built</text>
      <text {...txt} x={sx} y={bot + 72}>faded bar = non-drive side</text>
    </svg>
  );
}

const Swatch = ({ bg }) => <i style={{ display: "inline-block", width: 18, height: 3, background: bg, flex: "0 0 auto" }} />;

function TorqueRing({ hubs, names, erd, spokes, offset, tension, narrow, riderKgf }) {
  const fade = useHubFade();
  const [mode, setMode] = React.useState(MODES[0]);
  const [rider, setRider] = React.useState(RIDER[1]);
  const [tqSet, setTq] = React.useState(null);        // null = this mode's preset
  const [models, setModels] = React.useState(null);
  React.useEffect(() => {
    const id = setTimeout(() => setModels(hubs.map((h) => spokeModel(h, erd, spokes, offset, tension))), 20);
    return () => clearTimeout(id);
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);
  React.useEffect(() => setTq(null), [mode]);

  if (!models) return <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the ring…</p>;
  if (models.some((m) => m.pastBuckling)) {
    return (
      <p style={{ fontSize: 11, color: j.warn, margin: "8px 0 0", lineHeight: 1.6 }}>
        At this rim size and tension {models.every((m) => m.pastBuckling) ? "both builds are" : models[0].pastBuckling ? "the 148 build is" : "the 157 build is"} at or past the rim's buckling tension, so spoke tensions under torque have no meaningful value. Lower the tension or pick a smaller rim.
      </p>
    );
  }
  const sign = mode === MODES[0] ? 1 : -1, W = rider === RIDER[1] ? riderKgf : 0;
  const first = models.map((m) => ({ m, ...firstSlackTorque(m.res, { sign, rad: W }) }));
  const maxM = Math.max(...first.map((c) => c.torque));
  const sliderMax = Math.max(100, Math.ceil(maxM * 1.3 / 10) * 10);
  const torque = Math.min(sliderMax, tqSet != null ? tqSet : PRESET[mode]);
  const cases = first.map((c) => ({
    ...c, T0: c.m.res.spokes.T,
    now: spokeTensions(c.m.res, { torque: sign * torque, rad: W, pos: c.pos }),
  }));

  const k = fade.lastShown, c = cases[k], o = cases[1 - k];
  const side = (i) => (c.m.realSide(i) === "DS" ? "drive-side" : "non-drive-side");
  let lo = 0, hi = 0;
  c.now.forEach((v, i) => {
    if (v < c.now[lo]) lo = i;
    if (v - c.T0[i] > c.now[hi] - c.T0[hi]) hi = i;
  });
  const past = torque > c.torque + 1e-9;
  const short = (n) => (n === 0 ? "148" : "157");
  const twist = torque / c.m.res.K_tor;
  const verdict = past
    ? `Past first slack on the ${names[k]}: a ${side(c.spoke)} spoke runs out of tension at ${fmt(c.torque)} N·m. From here on a slack spoke carries nothing and Ford's linear model no longer describes the wheel, so the colors are an extrapolation.` +
      (torque <= o.torque ? ` The ${short(1 - k)} still has every spoke under tension at this torque.` : "")
    : `At ${fmt(torque)} N·m on the ${names[k]}${W ? ` with ${fmt(W)} kgf of rider and bike on the rear` : ""}, the most-loaded spoke picks up ${fmt(c.now[hi] - c.T0[hi], 1)} kgf and the loosest is ${side(lo)} with ${fmt(Math.max(0, c.now[lo]), 1)} kgf left (${fmt(Math.max(0, c.now[lo] / c.T0[lo] * 100))}% of its ${fmt(c.T0[lo])}). The first spoke goes slack at ${fmt(c.torque)} N·m, against ${fmt(o.torque)} on the ${short(1 - k)}. The rim turns about ${fmt(twist, 2)}° against the hub, too little to feel.`;
  const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };

  return (
    <>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 14px", marginBottom: 10 }}>
        <HubFadeControls fade={fade} />
        <ToggleGroup label="TORQUE" opts={MODES} val={mode} set={setMode} />
        <ToggleGroup label="WEIGHT" opts={RIDER} val={rider} set={setRider} />
      </div>
      <HubFadeTitle fade={fade} names={names} narrow={narrow} />
      <Ring cases={cases} torque={torque} mode={mode} shown={fade.shown} narrow={narrow} />
      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 10px", fontFamily: MONO }}>
        <span style={keyRow}><Swatch bg={j.taco} />tighter than built</span>
        <span style={keyRow}><Swatch bg={j.txt} />as built</span>
        <span style={keyRow}><Swatch bg={j.slack} />losing tension</span>
        <span style={keyRow}><Swatch bg={`repeating-linear-gradient(90deg, ${j.slack} 0 3px, transparent 3px 6px)`} />slack</span>
        <span>thick = drive side · thin = non-drive side · hub drawn ~2× scale</span>
      </div>
      <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 10, color: j.muted, fontFamily: MONO }}>
        TORQUE
        <input type="range" min={0} max={sliderMax} step={10} value={torque} onChange={(e) => setTq(Number(e.target.value))}
          aria-label="Torque at the hub, N·m" style={{ flex: 1, minWidth: 0, accentColor: j.slack }} />
        <span style={{ color: j.txt, fontWeight: 700, minWidth: 72, textAlign: "right" }}>{fmt(torque)} N·m</span>
      </label>
      <p style={{ fontSize: 11, color: past ? j.warn : j.txt, margin: "12px 0 0", lineHeight: 1.6 }}>{verdict}</p>
    </>
  );
}

const TORQUE_EQ = {
  lines: [
    <>K · d = F,   F = B(θ<sub>c</sub>)<sup>T</sup> · [0, W, M / R, 0]</>,
    <>ΔT<sub>i</sub> = −(EA / L)<sub>i</sub> · n<sub>i</sub> · d(θ<sub>i</sub>)</>,
    <>first slack: smallest M with T<sub>i</sub> + ΔT<sub>i</sub> = 0 for some spoke i</>,
  ],
  where: <>K the wheel's stiffness matrix with every spoke modelled separately (rim terms plus each spoke at its own rim angle, tension included); B(θ<sub>c</sub>) the rim's mode shapes at the contact point; W the rider's weight on the rear (radial, toward the hub); M the torque at the hub and R the rim radius, so M / R is the ground's push along the rim; d the rim's movement; for each spoke, EA its stretch stiffness, L its length, n its direction and T its built tension. The hub is held still, so it makes no difference whether the torque enters at the cassette or the rotor.</>,
  note: <>Ford's Mode Matrix (thesis ch. 2), as bike-wheel-calc's ModeMatrix.F_ext and Spoke.calc_tension_change compute it, with the tangential component of the load. Checked in wheel-physics-core's validation/spokes/.</>,
};

export default function TorsionTab({ hubs, erd, spokes, tension, offset, riderKg = 82 }) {
  const riderKgf = riderKg * REAR_SHARE;
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, true);
  const names = hubs.map((h) => h.name);
  const ford = <>Ford, Matthew. <i>Reinventing the Wheel: Stress Analysis, Stability, and Optimization of the Bicycle Wheel</i>. 2018. Northwestern University, PhD dissertation.</>;
  return (
    <div ref={wrap}>
      <p style={{ fontSize: 11, color: j.muted, margin: "0 0 12px", lineHeight: 1.6 }}>
        Pedaling and disc braking twist the hub against the rim. Two different questions follow. <b style={{ color: j.txt }}>Strength:</b> how much torque before a spoke goes slack? That is the spoke ring. <b style={{ color: j.txt }}>Stiffness:</b> how far does the rim turn per unit of torque? That is wind-up, at the bottom. A wheel can be stiff and still weak, or the other way round, so they are kept apart here.
      </p>

      <Section title="TORQUE SPOKE RING" subtitle="strength · torque to the first slack spoke">
        <Study eq={TORQUE_EQ} part="ch. 2, Mode Matrix with a tangential point load" cites={[ford]} />
        <Lead>The chain or the rotor turns the hub, and the tire pushes back on the ground. Half the spokes pull the rim along and tighten; the other half push and loosen. Drag the torque up and watch which spoke runs out of tension first. Rider weight (from the Rider+bike slider) presses down at the same spot.</Lead>
        <TorqueRing hubs={hubs} names={names} erd={erd} spokes={spokes} offset={offset} tension={tension} narrow={narrow} riderKgf={riderKgf} />
        <Foot>Spoke tensions come from Matthew Ford's discrete-spoke Mode Matrix with the ground's push at the contact patch; exact in his model up to the first spoke going slack. The start values are estimates, not measurements: about 300 N·m for a hard granny-gear effort (around 175 N·m at the crank through a 30/52 gear) and 200 N·m for hard rear braking. Rider weight is {Math.round(REAR_SHARE * 100)}% of the Rider+bike setting on the rear wheel, {fmt(riderKgf)} kgf now, also an estimate. Spokes are 3-cross 2.0 mm; hub shell and freehub twist are not included.</Foot>
      </Section>

      <WindUpSection hubs={hubs} erd={erd} spokes={spokes} tension={tension} offset={offset} narrow={narrow}
        defaultOpen={false} subtitle="stiffness, not strength" />

      <p style={{ fontSize: 9.5, color: j.muted, margin: "4px 0 0", lineHeight: 1.6 }}>
        Both come from Matthew Ford's Mode Matrix method (PhD thesis, Northwestern University, 2018) and his MIT-licensed bike-wheel-calc library, ported in wheel-physics-core and checked against his code to floating-point precision. Stock rim throughout.
      </p>
    </div>
  );
}
