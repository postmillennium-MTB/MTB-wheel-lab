import * as React from "react";
import { theme as j } from "../theme-state.js";

// ISO 4210-7:2023 §4.2 static strength test: a sideways force on the rim of
// 370 N for mountain bikes (250 N for city, trekking, young adult and racing
// bikes), held 1 min, then the permanent set is measured. It is a different
// criterion from F_lat (Ford's first-spoke-slack load, which is elastic), so
// it is shown as a note rather than as a line on the charts.
export const ISO_SIDE_LOAD_N = 370;
export const ISO_SIDE_LOAD_KGF = ISO_SIDE_LOAD_N / 9.80665;

export default function IsoNote({ style }) {
  return (
    <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6, ...style }}>
      ISO check: the bicycle safety standard (ISO 4210-7) pushes a mountain-bike rim sideways with {ISO_SIDE_LOAD_N} N ({ISO_SIDE_LOAD_KGF.toFixed(1)} kgf) and checks that it is not left permanently bent. Lateral strength here is an earlier, springy limit, the first spoke going slack, so a figure below {ISO_SIDE_LOAD_KGF.toFixed(1)} kgf does not mean the wheel fails ISO.
    </p>
  );
}
