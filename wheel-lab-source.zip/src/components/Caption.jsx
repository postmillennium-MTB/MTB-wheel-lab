import * as React from "react";

// Caption motion: when a caption's wording changes, its words rise into place
// one after another, like a subtitle track, so a reader sees that the verdict
// text changed and not only a number. Matches wheel-comparison-widget2.
//
// `capKey` names what the caption says, minus live figures. A new key replays
// the motion; a changed figure under the same key (any slider drag) updates
// in place. mode "words" staggers word by word; "whole" moves it as one piece.
// Opacity and transform only, so colors and contrast are unchanged. The CSS
// (.pmr-cw, pmrCapIn) lives in App's style block and is switched off under
// prefers-reduced-motion.

const STAGGER_CAP = 24; // the tail stops staggering at ~0.6 s

// Words are runs between whitespace. A run can span several children, e.g.
// "(" + "92.3" or "12" + <Pct/>, and stays one unit so it never line-breaks
// apart or enters in pieces.
function splitWords(children) {
  const out = [];
  let run = [], i = 0;
  const flush = () => {
    if (!run.length) return;
    out.push(<span key={"w" + i} className="pmr-cw" style={{ "--i": Math.min(i, STAGGER_CAP) }}>{run}</span>);
    run = []; i++;
  };
  React.Children.toArray(children).forEach((c) => {
    if (typeof c !== "string" && typeof c !== "number") { run.push(c); return; }
    String(c).split(/(\s+)/).forEach((part) => {
      if (!part) return;
      if (/^\s+$/.test(part)) { flush(); out.push(part); }
      else run.push(part);
    });
  });
  flush();
  return out;
}

export default function Caption({ capKey, mode = "words", children }) {
  if (mode === "whole") {
    return <span key={capKey} className="pmr-cw" style={{ "--i": 0 }}>{children}</span>;
  }
  return <React.Fragment key={capKey}>{splitWords(children)}</React.Fragment>;
}
