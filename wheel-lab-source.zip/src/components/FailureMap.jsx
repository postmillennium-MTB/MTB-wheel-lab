import * as React from "react";
import { theme as j } from "../theme-state.js";
import { PHYS_CONSTANTS } from "../data.js";
import { computeWheelStrength, applyRimOffset, tightSideFirst } from "../physics.js";
import ToggleGroup from "./ToggleGroup.jsx";
import Section from "./Section.jsx";

// FAILURE MAP: load against drive-side spoke tension for the two selected
// hubs. Orange-style "a spoke goes slack" line = engine F_rad / F_lat (Ford's
// discrete-spoke first-slack load). Dashed "rim tacos" line = engine F_taco,
// Ford & Balogun (2017) Eq. 2, a rough approximation that applies to radial
// load only. Past the buckling tension (T_c_DS) tension alone can taco the
// rim, so no strength figure applies there.

const XMIN = 40, STEP = 3;
const WIDE = { l: 64, r: 22, t: 20, b: 54, w: 760, h: 440 };
const NARROW = { l: 46, r: 10, t: 16, b: 50, w: 420, h: 420 };
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

function interp(sw, t, key) {
  if (t <= sw[0].t) return sw[0][key];
  for (let i = 1; i < sw.length; i++) {
    if (sw[i].t >= t) {
      const a = sw[i - 1], b = sw[i], f = (t - a.t) / (b.t - a.t);
      return a[key] + f * (b[key] - a[key]);
    }
  }
  return sw[sw.length - 1][key];
}

// Where the slack line meets the taco line (the tension that gives the most
// straight-down strength), found numerically on the sweep.
function crossing(sw) {
  for (let i = 1; i < sw.length; i++) {
    const a = sw[i - 1], b = sw[i];
    if (a.taco > a.rad && b.taco <= b.rad) {
      const f = (a.taco - a.rad) / ((a.taco - a.rad) - (b.taco - b.rad));
      return { t: a.t + f * (b.t - a.t), load: a.rad + f * (b.rad - a.rad) };
    }
  }
  return null;
}

// One hub's sweep from XMIN up to its buckling tension. Points where the
// engine reports no meaningful strength (at or past buckling) are dropped.
function sweepFor(hub, erd, Ns, offset) {
  const geo = tightSideFirst(applyRimOffset(hub, offset), erd, Ns);
  const { EIL, EIR, GJ, EA_rim, modes } = PHYS_CONSTANTS;
  const run = (t) => computeWheelStrength(erd, geo, 2, 2, t, EIL, EIR, GJ, EA_rim, Ns, modes);
  const ref = run(100);
  const Tc = ref.T_c_DS;
  const pts = [];
  for (let t = XMIN; t < Tc - 1; t += STEP) {
    const r = run(t);
    if (!(r.T_safety < 100) || !(r.F_lat > 0)) continue;
    pts.push({ t, rad: r.F_rad, lat: r.F_lat, taco: r.F_taco, safety: r.T_safety });
  }
  return { pts, Tc, ratio: ref.ratio };
}

// Area under the drawn safe-zone outline, XMIN to the buckling tension.
function safeArea(s, down) {
  const pts = s.pts.map((p) => [p.t, down ? Math.min(p.rad, p.taco) : p.lat]);
  pts.push([s.Tc, down ? 0 : interp(s.pts, s.Tc, "lat")]);
  let A = 0;
  for (let i = 1; i < pts.length; i++) A += (pts[i][0] - pts[i - 1][0]) * (pts[i][1] + pts[i - 1][1]) / 2;
  return A;
}

function useNarrow(ref, ready) {
  const [narrow, setNarrow] = React.useState(false);
  React.useEffect(() => {
    const f = () => setNarrow((ref.current ? ref.current.clientWidth : 720) < 560);
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, [ready]);
  return narrow;
}

function Chart({ sweeps, colors, names, which, down, tension, narrow }) {
  const M = narrow ? NARROW : WIDE;
  const key = down ? "rad" : "lat";
  const ymaxData = Math.max(...sweeps.map((s) => Math.max(...s.pts.map((p) => (down ? Math.min(p.rad, p.taco) : p.lat)))));
  const ymax = down ? Math.max(100, Math.ceil(ymaxData * 1.15 / 100) * 100) : Math.max(10, Math.ceil(ymaxData * 1.2 / 5) * 5);
  const yStep = down ? (ymax > 800 ? 200 : 100) : 5;
  const XMAX = Math.ceil((Math.max(...sweeps.map((s) => s.Tc)) + 10) / 20) * 20;
  const X = (t) => M.l + (t - XMIN) / (XMAX - XMIN) * (M.w - M.l - M.r);
  const Y = (v) => M.h - M.b - v / ymax * (M.h - M.t - M.b);
  const path = (s, k) => "M" + s.pts.map((p) => `${X(p.t)},${Y(Math.min(p[k], ymax * 1.2))}`).join("L");
  const txt = { fill: j.muted, fontFamily: "Space Mono, monospace", fontSize: narrow ? 12.5 : 11 };
  const lbl = { fill: j.txt, fontFamily: "Space Grotesk, system-ui", fontSize: narrow ? 13.5 : 12.5, fontWeight: 500 };
  const ticks = [];
  for (let v = 0; v <= ymax; v += yStep) ticks.push(v);
  const xTicks = [];
  for (let t = XMIN; t <= XMAX; t += narrow ? 40 : 20) xTicks.push(t);
  const ym = M.t + (M.h - M.t - M.b) / 2;
  const yl = narrow ? 12 : 16;
  const yTitle = down ? (narrow ? "straight-down load (kgf)" : "straight-down load at the tire (kgf)") : (narrow ? "sideways load (kgf)" : "sideways load at the rim (kgf)");

  const layer = (s, i) => {
    const sel = i === which;
    const col = colors[i];
    const limit = (p) => (down ? Math.min(p.rad, p.taco) : p.lat);
    const poly = `${X(s.pts[0].t)},${Y(0)} ` + s.pts.map((p) => `${X(p.t)},${Y(limit(p))}`).join(" ")
      + ` ${X(s.Tc)},${Y(down ? 0 : interp(s.pts, s.Tc, "lat"))} ${X(s.Tc)},${Y(0)}`;
    const c = down ? crossing(s.pts) : null;
    const pk = s.pts.reduce((a, b) => (b.lat > a.lat ? b : a));
    const room = M.w - M.r - X(s.Tc) > 96;
    const wx = room ? X(s.Tc) + 6 : X(s.Tc) - 6, wa = room ? "start" : "end";
    const t = tension;
    const v = t < s.Tc ? (down ? Math.min(interp(s.pts, t, "rad"), interp(s.pts, t, "taco")) : interp(s.pts, t, "lat")) : null;
    if (!sel) {
      return (
        <g key={i} clipPath="url(#fm-clip)">
          <path d={path(s, key)} fill="none" stroke={col} strokeWidth={1.2} strokeDasharray="2 4" opacity={0.75} />
          {down && <path d={path(s, "taco")} fill="none" stroke={col} strokeWidth={1.2} strokeDasharray="2 4" opacity={0.75} />}
        </g>
      );
    }
    return (
      <g key={i}>
        <g clipPath="url(#fm-clip)">
          <polygon points={poly} fill={col} opacity={0.12} />
          <rect x={X(s.Tc)} y={M.t} width={Math.max(0, X(XMAX) - X(s.Tc))} height={M.h - M.t - M.b} fill="url(#fm-hatch)" />
          <line x1={X(s.Tc)} x2={X(s.Tc)} y1={M.t} y2={M.h - M.b} stroke={j.txt} strokeWidth={1.5} />
          <path d={path(s, key)} fill="none" stroke={col} strokeWidth={2.8} />
          {down && <path d={path(s, "taco")} fill="none" stroke={col} strokeWidth={2.8} strokeDasharray="9 5" />}
        </g>
        {narrow
          ? <text {...lbl} x={X(s.Tc) + 5} y={M.t + 8} transform={`rotate(90 ${X(s.Tc) + 5} ${M.t + 8})`}>{`tension alone tacos it · ≥ ${fmt(s.Tc)} kgf`}</text>
          : <g>
              <text {...lbl} x={wx} y={M.t + 16} textAnchor={wa}>tension alone</text>
              <text {...lbl} x={wx} y={M.t + 31} textAnchor={wa}>tacos the rim</text>
              <text {...txt} x={wx} y={M.t + 46} textAnchor={wa}>{`≥ ${fmt(s.Tc)} kgf`}</text>
            </g>}
        {down && <text {...lbl} fill={col} x={X(64)} y={Y(interp(s.pts, 64, "rad")) - 18}>a spoke goes slack</text>}
        {!down && <text {...lbl} fill={col} x={X(56)} y={Y(interp(s.pts, 56, "lat")) - 16}>a spoke goes slack</text>}
        {down && (() => {
          const top = s.pts.find((p) => p.taco <= ymax * 0.93) || s.pts[0];
          return (
            <g>
              <text {...lbl} fill={col} x={X(top.t) - 10} y={M.t + 16} textAnchor="end">rim tacos (estimate)</text>
              {!narrow && <text {...txt} x={X(top.t) - 10} y={M.t + 31} textAnchor="end">{`keeps rising to ${fmt(s.pts[0].taco)} kgf`}</text>}
            </g>
          );
        })()}
        {c && (
          <g>
            <circle cx={X(c.t)} cy={Y(c.load)} r={6.5} fill={j.surf} stroke={j.txt} strokeWidth={2} />
            <text {...lbl} x={X(c.t) - 12} y={Y(c.load) - 14} textAnchor="end">
              {narrow ? `best ≈ ${fmt(c.t)} → ${fmt(c.load)} kgf` : `strongest ≈ ${fmt(c.t)} kgf tension → ${fmt(c.load)} kgf`}
            </text>
          </g>
        )}
        {!down && (
          <g>
            <circle cx={X(pk.t)} cy={Y(pk.lat)} r={6.5} fill={j.surf} stroke={j.txt} strokeWidth={2} />
            <text {...lbl} x={X(pk.t)} y={Y(pk.lat) - 14} textAnchor="middle">
              {narrow ? `best ≈ ${pk.t} → ${fmt(pk.lat, 1)} kgf` : `best ≈ ${pk.t} kgf tension → ${fmt(pk.lat, 1)} kgf`}
            </text>
          </g>
        )}
        {v != null ? (
          <g>
            <line x1={X(t)} x2={X(t)} y1={Y(0)} y2={Y(v)} stroke={j.txt} strokeWidth={1} strokeDasharray="3 3" />
            <circle cx={X(t)} cy={Y(v)} r={7.5} fill={j.txt} stroke={j.surf} strokeWidth={2} />
            {(() => {
              // keep the label clear of the "best" marker when the two are close
              const left = !down && Math.abs(t - pk.t) < 30 && t <= pk.t;
              return <text {...lbl} x={left ? X(t) - 11 : X(t) + 11} y={Y(v) + 19} textAnchor={left ? "end" : "start"}>your build</text>;
            })()}
          </g>
        ) : (
          <circle cx={X(t)} cy={Y(0)} r={7.5} fill={j.fail} stroke={j.surf} strokeWidth={2} />
        )}
      </g>
    );
  };

  return (
    <svg viewBox={`0 0 ${M.w} ${M.h}`} role="img" aria-label={`Failure map for ${names[which]}: load against spoke tension`}
      style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}>
      <defs>
        <clipPath id="fm-clip"><rect x={M.l} y={M.t} width={M.w - M.l - M.r} height={M.h - M.t - M.b} /></clipPath>
        <pattern id="fm-hatch" width={7} height={7} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1={0} y1={0} x2={0} y2={7} stroke={j.muted} strokeWidth={1.2} opacity={0.45} />
        </pattern>
      </defs>
      {ticks.map((v) => (
        <g key={v}>
          <line x1={M.l} x2={M.w - M.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={M.l - 8} y={Y(v) + 4} textAnchor="end">{fmt(v)}</text>
        </g>
      ))}
      {xTicks.map((t) => (
        <g key={t}>
          <line x1={X(t)} x2={X(t)} y1={M.h - M.b} y2={M.h - M.b + 5} stroke={j.muted} />
          <text {...txt} x={X(t)} y={M.h - M.b + 18} textAnchor="middle">{t}</text>
        </g>
      ))}
      <text {...txt} x={(M.l + M.w - M.r) / 2} y={M.h - 12} textAnchor="middle">drive-side spoke tension (kgf)</text>
      <text {...txt} x={yl} y={ym} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym})`}>{yTitle}</text>
      {sweeps.map((s, i) => (i === which ? null : layer(s, i)))}
      {layer(sweeps[which], which)}
    </svg>
  );
}

/**
 * hubs = [hub148, hub157]; names = their display names. erd in mm, spokes =
 * spoke count, offset = rim offset, tension = the Lab's drive-side tension.
 */
export default function FailureMap({ hubs, names, erd, spokes, offset, tension }) {
  const [which, setWhich] = React.useState(1);
  const [dir, setDir] = React.useState("Straight down");
  // The two sweeps are ~100 engine calls, so they run after the tab has
  // painted rather than blocking it; the previous map stays up until the new
  // one is ready.
  const [sweeps, setSweeps] = React.useState(null);
  React.useEffect(() => {
    const id = setTimeout(() => setSweeps(hubs.map((h) => sweepFor(h, erd, spokes, offset))), 20);
    return () => clearTimeout(id);
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset]);
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, sweeps !== null);
  const down = dir === "Straight down";
  if (!sweeps) {
    return (
      <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={true}>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the map…</p>
      </Section>
    );
  }
  const colors = [j.h148, j.h157];
  const labels = ["148x12", "157x12"];

  if (sweeps.some((s) => s.pts.length < 2)) {
    return (
      <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={false}>
        <p style={{ fontSize: 11, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
          At this rim size one of these builds reaches its buckling tension below {XMIN} kgf, so there is no range to draw.
        </p>
      </Section>
    );
  }

  const gain = (d) => (safeArea(sweeps[1], d) / safeArea(sweeps[0], d) - 1) * 100;
  const s = sweeps[which], other = sweeps[1 - which];
  const t = tension;
  const stat = (label, val, on) => (
    <div style={{ display: "flex", alignItems: "baseline", gap: 10, opacity: on ? 1 : 0.55, fontSize: 11, color: j.muted }}>
      <span style={{ fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 24, color: j.txt }}>
        {(val >= 0 ? "+" : "") + fmt(val)}%
      </span>
      <span>{label}</span>
    </div>
  );

  let verdict;
  if (t >= s.Tc) {
    verdict = `At ${t} kgf the ${names[which]} is past its buckling tension (${fmt(s.Tc)} kgf), so tension alone could taco the rim.`;
  } else if (down) {
    const rad = interp(s.pts, t, "rad"), taco = interp(s.pts, t, "taco");
    verdict = rad < taco
      ? `On the ${names[which]}, a spoke goes slack first, at ${fmt(rad)} kgf, well before the rim would taco.`
      : `On the ${names[which]}, the rim would taco first, at about ${fmt(taco)} kgf. This tension is past the strongest point.`;
  } else {
    const a = interp(s.pts, t, "lat");
    verdict = `Sideways, a spoke on the ${names[which]} goes slack at ${fmt(a, 1)} kgf` +
      (other.Tc > t ? `, against ${fmt(interp(other.pts, t, "lat"), 1)} kgf on the ${names[1 - which]}.` : ".");
  }

  return (
    <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={true}>
      <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 10px", lineHeight: 1.6 }}>
        Which gives up first when you land hard: the spokes or the rim? You are safe under both lines. The dot is your build at the current tension.
      </p>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "8px 14px", marginBottom: 8 }}>
        <ToggleGroup label="HUB" opts={labels} val={labels[which]} set={(o) => setWhich(labels.indexOf(o))} activeColor={colors[which]} />
        <ToggleGroup label="LOAD" opts={["Straight down", "Sideways"]} val={dir} set={setDir} />
      </div>
      <div ref={wrap}>
        <Chart sweeps={sweeps} colors={colors} names={names} which={which} down={down} tension={t} narrow={narrow} />
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 16px", fontSize: 10, color: j.muted, margin: "6px 0 10px", fontFamily: "Space Mono, monospace" }}>
        <span>solid: a spoke goes slack</span>
        {down && <span>dashed: rim tacos (estimate)</span>}
        <span>dotted: the other hub</span>
        <span>hatched: past buckling</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "8px 18px", borderTop: `1px solid ${j.bdr}`, borderBottom: `1px solid ${j.bdr}`, padding: "10px 0" }}>
        {stat("larger safe zone on the 157, straight down", gain(true), down)}
        {stat("larger safe zone on the 157, sideways", gain(false), !down)}
        <p style={{ gridColumn: "1 / -1", fontSize: 10, color: j.muted, margin: 0, lineHeight: 1.55 }}>
          Area of the shaded zone from {XMIN} kgf up to each hub's buckling tension. Part of the 157's gain comes from its higher buckling tension, which adds width on the right. The straight-down figure also depends on the taco estimate.
        </p>
      </div>
      <p style={{ fontSize: 11, color: j.txt, margin: "10px 0 0", lineHeight: 1.6 }}>{verdict}</p>
      <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
        The slack line is the engine's first-slack load from Matthew Ford's discrete-spoke Mode Matrix. The taco line is Ford &amp; Balogun (2017), Eq. 2: P = K⁰<sub>lat</sub>·R·(1 − T/T<sub>c</sub>), which they present as a rough approximation, and it applies to straight-down loads only; Ford has no sideways taco formula. The hatched zone starts at each hub's buckling tension.
      </p>
    </Section>
  );
}
