import * as React from "react";
import { theme as j } from "../theme-state.js";
import { PHYS_CONSTANTS } from "../data.js";
import { computeWheelStrength, applyRimOffset, tightSideFirst } from "../physics.js";
import ToggleGroup from "./ToggleGroup.jsx";
import { FADE_MS, reducedMotion, useHubFade, useNarrow, HubFadeControls, HubFadeTitle } from "./HubFade.jsx";
import Section from "./Section.jsx";
import IsoNote from "./IsoNote.jsx";

// FAILURE MAP: load against drive-side spoke tension for the two selected
// hubs. Solid "a spoke goes slack" line = engine F_rad / F_lat (Ford's
// discrete-spoke first-slack load). Dashed "rim tacos" line = engine F_taco,
// Ford & Balogun (2017) Eq. 2, a rough approximation that applies to radial
// load only. Past the buckling tension (T_c_DS) tension alone can taco the
// rim, so no strength figure applies there.

const XMIN = 40, STEP = 3;
const WIDE = { l: 64, r: 22, t: 20, b: 54, w: 760, h: 440 };
const NARROW = { l: 52, r: 10, t: 16, b: 50, w: 420, h: 420 };
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

function interp(sw, t, key) {
  if (t <= sw[0].t) return sw[0][key];
  for (let i = 1; i < sw.length; i++) {
    if (sw[i].t >= t) {
      const a = sw[i - 1], b = sw[i], f = (t - a.t) / (b.t - a.t);
      return a[key] + f * (b[key] - a[key]);
    }
  }
  return sw[sw.length - 1][key];
}

// Where the slack line meets the taco line (the tension that gives the most
// straight-down strength), found numerically on the sweep.
function crossing(sw) {
  for (let i = 1; i < sw.length; i++) {
    const a = sw[i - 1], b = sw[i];
    if (a.taco > a.rad && b.taco <= b.rad) {
      const f = (a.taco - a.rad) / ((a.taco - a.rad) - (b.taco - b.rad));
      return { t: a.t + f * (b.t - a.t), load: a.rad + f * (b.rad - a.rad) };
    }
  }
  return null;
}

// One hub's sweep from XMIN up to its buckling tension. Points where the
// engine reports no meaningful strength (at or past buckling) are dropped.
function sweepFor(hub, erd, Ns, offset) {
  const geo = tightSideFirst(applyRimOffset(hub, offset), erd, Ns);
  const { EIL, EIR, GJ, EA_rim, modes } = PHYS_CONSTANTS;
  const run = (t) => computeWheelStrength(erd, geo, 2, 2, t, EIL, EIR, GJ, EA_rim, Ns, modes);
  const ref = run(100);
  const Tc = ref.T_c_DS;
  const pts = [];
  for (let t = XMIN; t < Tc - 1; t += STEP) {
    const r = run(t);
    if (!(r.T_safety < 100) || !(r.F_lat > 0)) continue;
    pts.push({ t, rad: r.F_rad, lat: r.F_lat, taco: r.F_taco, safety: r.T_safety });
  }
  return { pts, Tc, ratio: ref.ratio };
}

// Area under the drawn safe-zone outline, XMIN to the buckling tension.
function safeArea(s, down) {
  const pts = s.pts.map((p) => [p.t, down ? Math.min(p.rad, p.taco) : p.lat]);
  pts.push([s.Tc, down ? 0 : interp(s.pts, s.Tc, "lat")]);
  let A = 0;
  for (let i = 1; i < pts.length; i++) A += (pts[i][0] - pts[i - 1][0]) * (pts[i][1] + pts[i - 1][1]) / 2;
  return A;
}

// Both hubs are always drawn, each in its own layer; `shown` picks the layer
// at full opacity (null = both faded out, mid-crossfade). Axes are shared so
// the fade shows the map shifting, not the scale changing.
function Chart({ sweeps, names, which, shown, down, tension, narrow }) {
  const M = narrow ? NARROW : WIDE;
  const key = down ? "rad" : "lat";
  const limit = (p) => (down ? Math.min(p.rad, p.taco) : p.lat);
  // Headroom above the data keeps the top labels clear of the curves.
  const ymaxData = Math.max(...sweeps.map((s) => Math.max(...s.pts.map(limit))));
  const ymax = down ? Math.max(100, Math.ceil(ymaxData * 1.5 / 100) * 100) : Math.max(10, Math.ceil(ymaxData * 1.45 / 5) * 5);
  const yStep = down ? (ymax > 800 ? 200 : 100) : (ymax > 40 ? 10 : 5);
  // Room right of the later buckling wall for its label.
  const XMAX = Math.ceil((Math.max(...sweeps.map((s) => s.Tc)) + (narrow ? 10 : 26)) / 10) * 10;
  const X = (t) => M.l + (t - XMIN) / (XMAX - XMIN) * (M.w - M.l - M.r);
  const Y = (v) => M.h - M.b - v / ymax * (M.h - M.t - M.b);
  const path = (s, k) => "M" + s.pts.map((p) => `${X(p.t)},${Y(Math.min(p[k], ymax * 1.2))}`).join("L");
  const txt = { fill: j.muted, fontFamily: "Space Mono, monospace", fontSize: narrow ? 12.5 : 11 };
  const lbl = { fill: j.txt, fontFamily: "Space Grotesk, system-ui", fontSize: narrow ? 13.5 : 12.5, fontWeight: 500 };
  const ticks = [];
  for (let v = 0; v <= ymax; v += yStep) ticks.push(v);
  const xTicks = [];
  for (let t = XMIN; t <= XMAX; t += narrow ? 40 : 20) xTicks.push(t);
  const ym = M.t + (M.h - M.t - M.b) / 2;
  const yl = narrow ? 12 : 16;
  const yTitle = down ? (narrow ? "straight-down load (kgf)" : "straight-down load at the tire (kgf)") : (narrow ? "sideways load (kgf)" : "sideways load at the rim (kgf)");
  const fade = reducedMotion() ? "none" : `opacity ${FADE_MS}ms ease-in-out`;
  const ghost = { fill: "none", stroke: j.muted, strokeWidth: 1, strokeDasharray: "2 4", opacity: 0.7 };

  const layer = (s, i) => {
    const poly = `${X(s.pts[0].t)},${Y(0)} ` + s.pts.map((p) => `${X(p.t)},${Y(limit(p))}`).join(" ")
      + ` ${X(s.Tc)},${Y(down ? 0 : interp(s.pts, s.Tc, "lat"))} ${X(s.Tc)},${Y(0)}`;
    const c = down ? crossing(s.pts) : null;
    const pk = s.pts.reduce((a, b) => (b.lat > a.lat ? b : a));
    const room = M.w - M.r - X(s.Tc) > 96;
    const wx = room ? X(s.Tc) + 6 : X(s.Tc) - 6, wa = room ? "start" : "end";
    const t = tension;
    const v = t < s.Tc ? (down ? Math.min(interp(s.pts, t, "rad"), interp(s.pts, t, "taco")) : interp(s.pts, t, "lat")) : null;
    // "a spoke goes slack" sits just under the rising line, inside the safe zone
    const st = down ? 64 : 56;
    return (
      <g key={i} style={{ opacity: shown === i ? 1 : 0, transition: fade }} aria-hidden={shown !== i}>
        <g clipPath="url(#fm-clip)">
          <polygon points={poly} fill={j.txt} opacity={0.07} />
          <rect x={X(s.Tc)} y={M.t} width={Math.max(0, X(XMAX) - X(s.Tc))} height={M.h - M.t - M.b} fill="url(#fm-hatch)" />
          <line x1={X(s.Tc)} x2={X(s.Tc)} y1={M.t} y2={M.h - M.b} stroke={j.txt} strokeWidth={1.5} />
          <path d={path(s, key)} fill="none" stroke={j.slack} strokeWidth={2.8} strokeLinejoin="round" />
          {down && <path d={path(s, "taco")} fill="none" stroke={j.taco} strokeWidth={2.8} strokeDasharray="9 5" />}
        </g>
        {narrow
          ? <text {...lbl} x={X(s.Tc) + 5} y={M.t + 8} transform={`rotate(90 ${X(s.Tc) + 5} ${M.t + 8})`}>{`tension alone tacos it · ≥ ${fmt(s.Tc)} kgf`}</text>
          : <g>
              <text {...lbl} x={wx} y={M.t + 16} textAnchor={wa}>tension alone</text>
              <text {...lbl} x={wx} y={M.t + 31} textAnchor={wa}>tacos the rim</text>
              <text {...txt} x={wx} y={M.t + 46} textAnchor={wa}>{`≥ ${fmt(s.Tc)} kgf`}</text>
            </g>}
        <text {...lbl} fill={j.slack} x={X(st)} y={Y(interp(s.pts, st, key)) + (narrow ? 26 : 24)}>a spoke goes slack</text>
        {down && (() => {
          const top = s.pts.find((p) => p.taco <= ymax * 0.93) || s.pts[0];
          return (
            <g>
              <text {...lbl} fill={j.taco} x={X(top.t) - 10} y={M.t + 16} textAnchor="end">rim tacos (estimate)</text>
              {!narrow && <text {...txt} x={X(top.t) - 10} y={M.t + 31} textAnchor="end">{`keeps rising to ${fmt(s.pts[0].taco)} kgf`}</text>}
            </g>
          );
        })()}
        {c && (
          <g>
            <circle cx={X(c.t)} cy={Y(c.load)} r={6.5} fill={j.surf} stroke={j.txt} strokeWidth={2} />
            <text {...lbl} x={X(c.t) - 12} y={Y(c.load) - 14} textAnchor="end">
              {narrow ? `best ≈ ${fmt(c.t)} → ${fmt(c.load)} kgf` : `strongest ≈ ${fmt(c.t)} kgf tension → ${fmt(c.load)} kgf`}
            </text>
          </g>
        )}
        {!down && (
          <g>
            <circle cx={X(pk.t)} cy={Y(pk.lat)} r={6.5} fill={j.surf} stroke={j.txt} strokeWidth={2} />
            <text {...lbl} x={X(pk.t)} y={Y(pk.lat) - 14} textAnchor="middle">
              {narrow ? `best ≈ ${pk.t} → ${fmt(pk.lat, 1)} kgf` : `best ≈ ${pk.t} kgf tension → ${fmt(pk.lat, 1)} kgf`}
            </text>
          </g>
        )}
        {v != null ? (
          <g>
            <line x1={X(t)} x2={X(t)} y1={Y(0)} y2={Y(v)} stroke={j.txt} strokeWidth={1} strokeDasharray="3 3" />
            <circle cx={X(t)} cy={Y(v)} r={7.5} fill={j.txt} stroke={j.surf} strokeWidth={2} />
            {(() => {
              // keep the label clear of the "best" marker when the two are close
              const left = !down && Math.abs(t - pk.t) < 30 && t <= pk.t;
              return <text {...lbl} x={left ? X(t) - 11 : X(t) + 11} y={Y(v) + (left ? 26 : 19)} textAnchor={left ? "end" : "start"}>your build</text>;
            })()}
          </g>
        ) : (
          <circle cx={X(t)} cy={Y(0)} r={7.5} fill={j.fail} stroke={j.surf} strokeWidth={2} />
        )}
      </g>
    );
  };

  return (
    <svg viewBox={`0 0 ${M.w} ${M.h}`} role="img" aria-label={`Failure map for ${names[which]}: load against spoke tension`}
      style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}>
      <defs>
        <clipPath id="fm-clip"><rect x={M.l} y={M.t} width={M.w - M.l - M.r} height={M.h - M.t - M.b} /></clipPath>
        <pattern id="fm-hatch" width={7} height={7} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1={0} y1={0} x2={0} y2={7} stroke={j.muted} strokeWidth={1.2} opacity={0.45} />
        </pattern>
      </defs>
      {ticks.map((v) => (
        <g key={v}>
          <line x1={M.l} x2={M.w - M.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={M.l - 8} y={Y(v) + 4} textAnchor="end">{fmt(v)}</text>
        </g>
      ))}
      {xTicks.map((t) => (
        <g key={t}>
          <line x1={X(t)} x2={X(t)} y1={M.h - M.b} y2={M.h - M.b + 5} stroke={j.muted} />
          <text {...txt} x={X(t)} y={M.h - M.b + 18} textAnchor="middle">{t}</text>
        </g>
      ))}
      <text {...txt} x={(M.l + M.w - M.r) / 2} y={M.h - 12} textAnchor="middle">drive-side spoke tension (kgf)</text>
      <text {...txt} x={yl} y={ym} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym})`}>{yTitle}</text>
      {/* faint outlines of both hubs, always visible, so the fade shows the shift */}
      <g clipPath="url(#fm-clip)">
        {sweeps.map((s, i) => (
          <g key={i}>
            <path d={path(s, key)} style={ghost} />
            {down && <path d={path(s, "taco")} style={ghost} />}
          </g>
        ))}
      </g>
      {sweeps.map(layer)}
    </svg>
  );
}

const Swatch = ({ bg, h = 3, op = 1 }) => (
  <i style={{ display: "inline-block", width: 18, height: h, background: bg, opacity: op, flex: "0 0 auto" }} />
);

/**
 * hubs = [hub148, hub157]; names = their display names. erd in mm, spokes =
 * spoke count, offset = rim offset, tension = the Lab's drive-side tension.
 * fade = shared hub choice and Play state from useHubFade() (FailureViews
 * passes the one it shares with the spoke ring); the map keeps its own
 * when none is given.
 */
export default function FailureMap({ hubs, names, erd, spokes, offset, tension, fade: shared }) {
  const own = useHubFade();
  const fade = shared || own;
  const { which, shown } = fade;
  const [dir, setDir] = React.useState("Straight down");
  // The two sweeps are ~100 engine calls, so they run after the tab has
  // painted rather than blocking it; the previous map stays up until the new
  // one is ready.
  const [sweeps, setSweeps] = React.useState(null);
  React.useEffect(() => {
    const id = setTimeout(() => setSweeps(hubs.map((h) => sweepFor(h, erd, spokes, offset))), 20);
    return () => clearTimeout(id);
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset]);
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, sweeps !== null);
  const down = dir === "Straight down";
  if (!sweeps) {
    return (
      <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={true}>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the map…</p>
      </Section>
    );
  }

  if (sweeps.some((s) => s.pts.length < 2)) {
    return (
      <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={false}>
        <p style={{ fontSize: 11, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
          At this rim size one of these builds reaches its buckling tension below {XMIN} kgf, so there is no range to draw.
        </p>
      </Section>
    );
  }

  const gain = (d) => (safeArea(sweeps[1], d) / safeArea(sweeps[0], d) - 1) * 100;
  const s = sweeps[which], other = sweeps[1 - which];
  const t = tension;
  const stat = (label, val, on) => (
    <div style={{ opacity: on ? 1 : 0.5, transition: "opacity .4s ease" }}>
      <div style={{ fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: narrow ? 26 : 30, lineHeight: 1.1, color: j.txt }}>
        {(val >= 0 ? "+" : "") + fmt(val)}%
      </div>
      <div style={{ fontSize: 11, color: j.muted, marginTop: 2 }}>{label}</div>
    </div>
  );

  let verdict;
  if (t >= s.Tc) {
    verdict = `At ${t} kgf the ${names[which]} is past its buckling tension (${fmt(s.Tc)} kgf), so tension alone could taco the rim.`;
  } else if (down) {
    const rad = interp(s.pts, t, "rad"), taco = interp(s.pts, t, "taco");
    verdict = rad < taco
      ? `On the ${names[which]}, a spoke goes slack first, at ${fmt(rad)} kgf, well before the rim would taco.`
      : `On the ${names[which]}, the rim would taco first, at about ${fmt(taco)} kgf. This tension is past the strongest point.`;
  } else {
    const a = interp(s.pts, t, "lat");
    verdict = `Sideways, a spoke on the ${names[which]} goes slack at ${fmt(a, 1)} kgf` +
      (other.Tc > t ? `, against ${fmt(interp(other.pts, t, "lat"), 1)} kgf on the ${names[1 - which]}.` : ".");
  }

  const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };
  return (
    <Section title="FAILURE MAP" subtitle="spokes vs rim" defaultOpen={true}>
      <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 12px", lineHeight: 1.6 }}>
        Which gives up first when you land hard: the spokes or the rim? You are safe under both lines. Press Play to fade between the two hubs every 4 seconds.
      </p>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 14px", marginBottom: 10 }}>
        <HubFadeControls fade={fade} />
        <ToggleGroup label="LOAD" opts={["Straight down", "Sideways"]} val={dir} set={setDir} />
      </div>
      <HubFadeTitle fade={fade} names={names} narrow={narrow} />
      <div ref={wrap}>
        <Chart sweeps={sweeps} names={names} which={which} shown={shown} down={down} tension={t} narrow={narrow} />
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 12px", fontFamily: "Space Mono, monospace" }}>
        <span style={keyRow}><Swatch bg={j.slack} />a spoke goes slack</span>
        {down && <span style={keyRow}><Swatch bg={`repeating-linear-gradient(90deg, ${j.taco} 0 6px, transparent 6px 9px)`} />rim tacos (estimate)</span>}
        <span style={keyRow}><Swatch bg={j.txt} h={10} op={0.12} />safe zone</span>
        <span style={keyRow}><Swatch bg={`repeating-linear-gradient(90deg, ${j.muted} 0 2px, transparent 2px 6px)`} />both hubs' outlines</span>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: narrow ? "minmax(0, 1fr)" : "repeat(2, minmax(0, 1fr))", gap: "12px 18px", borderTop: `1px solid ${j.bdr}`, borderBottom: `1px solid ${j.bdr}`, padding: "12px 0" }}>
        {stat("larger safe zone on the 157, straight down", gain(true), down)}
        {stat("larger safe zone on the 157, sideways", gain(false), !down)}
        <p style={{ gridColumn: "1 / -1", fontSize: 10, color: j.muted, margin: 0, lineHeight: 1.55 }}>
          Area of the shaded zone from {XMIN} kgf up to each hub's buckling tension. Part of the 157's gain comes from its higher buckling tension, which adds width on the right. The straight-down figure also depends on the taco estimate.
        </p>
      </div>
      <p style={{ fontSize: 11, color: j.txt, margin: "12px 0 0", lineHeight: 1.6 }}>{verdict}</p>
      <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
        The slack line is the engine's first-slack load from Matthew Ford's discrete-spoke Mode Matrix. The taco line is Ford &amp; Balogun (2017), Eq. 2: P = K⁰<sub>lat</sub>·R·(1 − T/T<sub>c</sub>), which they present as a rough approximation, and it applies to straight-down loads only; Ford has no sideways taco formula. The hatched zone starts at each hub's buckling tension.
      </p>
      <IsoNote />
    </Section>
  );
}
