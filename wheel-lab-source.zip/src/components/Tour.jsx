import * as React from "react";
import { theme as j } from "../theme-state.js";

// START HERE: a five-stop guided path through the Lab for a first visit.
//
// The Lab has eight tabs. Five ideas carry most of what a rider needs, in
// this order: the verdict, why balance drives it, what gives first, what
// real (mixed) hits do, and what margin looks like on a ride. Each stop
// opens the tab that shows the idea (and scrolls to the chart, where the
// chart is not at the top, opening it if the reader had minimized it) and
// names the chart and says in two or three sentences what to look
// at. The reader sets the pace with Back / Next; nothing auto-advances.
// The remaining tabs are named at the last stop as reference material.
//
// `tab` must be an exact tab name from App.jsx's tab bar; `anchor` is the
// id of a wrapper element App.jsx puts around that chart.
export const TOUR_STOPS = [
  { tab: "COMPARE", anchor: null, title: "The verdict",
    text: "Pick a 148 hub and a 157 hub. The big number is how much more sideways load the 157 wheel takes before its first spoke goes slack. That is strength: the load at which something gives. Stiffness, how far the wheel flexes under a load, is a different thing and has its own numbers." },
  { tab: "SYMMETRY", anchor: null, title: "Why: balance",
    text: "One wheel, one variable. Drag the slider to move the flanges off-center and watch lateral strength fall while flange width and average spoke tension stay the same. Flange position, not axle width, is the thing to compare between hubs." },
  { tab: "COMPARE", anchor: "pmr-failure-map", title: "What gives first",
    text: "Look at the FAILURE MAP chart below. A wheel gives in one of two ways: a spoke goes slack, or the rim tacos. Under both lines you are safe. More spoke tension helps up to a point, then the rim's line comes down to meet you. Press Play to fade between the two hubs." },
  { tab: "DEEP DIVE", anchor: "pmr-load-envelope", title: "Real hits are mixed",
    text: "Look at the LOAD ENVELOPE chart below. Landing while leaned into a berm pushes the wheel down and sideways at once. The triangle is every combination the wheel takes before a spoke goes slack. Compare the two axes: it takes far more load straight down than sideways." },
  { tab: "SIMULATION", anchor: null, title: "What margin looks like",
    text: "Press Simulate for an illustrative ride. Loads under a hub's line keep every spoke tight; loads over it slacken spokes for a moment. The ride is scripted, the two lines are calculated. That is the core of the Lab: TENSION BALANCE, HUB SPECS, TORSION and INSIGHTS are reference tabs for going deeper." },
];

const KEY = "pmr-wheel-lab-tour-dismissed";
// Storage can be unavailable (private windows, blocked site data, the smoke
// test's DOM); the invite then simply shows again on the next visit.
export function tourDismissed() { try { return localStorage.getItem(KEY) === "1"; } catch (err) { return false; } }
export function dismissTour() { try { localStorage.setItem(KEY, "1"); } catch (err) {} }

const GROTESK = "Space Grotesk, system-ui";
const btn = (primary) => ({
  padding: "6px 12px", borderRadius: 7, cursor: "pointer", fontSize: 10.5, fontFamily: GROTESK, fontWeight: 700,
  background: primary ? j.txt : j.surfl, color: primary ? j.surf : j.muted, border: `1.5px solid ${primary ? j.txt : j.bdr}`,
});

/** The one-line invitation shown at the top of COMPARE until the tour is started or dismissed. */
export function TourInvite({ start, dismiss }) {
  return (
    <div style={{ background: j.surf, border: `1px solid ${j.bdr}`, borderLeft: `3px solid ${j.txt}`, borderRadius: 8, padding: "9px 12px", marginBottom: 12, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
      <div style={{ flex: "1 1 200px", minWidth: 0 }}>
        <span style={{ fontSize: 11, color: j.txt, fontWeight: 700, fontFamily: GROTESK, letterSpacing: "0.04em" }}>NEW HERE? START HERE</span>
        <span style={{ fontSize: 10.5, color: j.muted }}> · five stops, about two minutes, through what matters most.</span>
      </div>
      <button onClick={start} style={btn(true)}>▶ Start the tour</button>
      <button onClick={dismiss} aria-label="Hide the tour invitation" title="Hide" style={{ ...btn(false), padding: "6px 9px" }}>✕</button>
    </div>
  );
}

/** The tour's panel: sticks to the top of the window while a stop is open. */
export function TourBar({ step, go, exit }) {
  const s = TOUR_STOPS[step], n = TOUR_STOPS.length, last = step === n - 1;
  return (
    <div role="region" aria-label="Guided tour" style={{ position: "sticky", top: 6, zIndex: 30, background: j.surf, border: `1.5px solid ${j.txt}`, borderRadius: 8, padding: "10px 12px", marginBottom: 12, boxShadow: `0 3px 14px ${j.bg}cc` }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4 }}>
        <span style={{ fontSize: 9, color: j.muted, fontFamily: "Space Mono, monospace", whiteSpace: "nowrap" }}>STOP {step + 1} / {n}</span>
        <span style={{ fontSize: 12, color: j.txt, fontWeight: 700, fontFamily: GROTESK }}>{s.title}</span>
        <span style={{ fontSize: 9, color: j.muted, marginLeft: "auto", whiteSpace: "nowrap" }}>{s.tab}</span>
      </div>
      <p style={{ fontSize: 10.5, color: j.txt, margin: "0 0 8px", lineHeight: 1.55 }}>{s.text}</p>
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <button onClick={() => go(step - 1)} disabled={step === 0} style={{ ...btn(false), opacity: step === 0 ? 0.45 : 1, cursor: step === 0 ? "default" : "pointer" }}>← Back</button>
        <button onClick={() => (last ? exit() : go(step + 1))} style={btn(true)}>{last ? "Finish" : "Next →"}</button>
        <span aria-hidden="true" style={{ display: "flex", gap: 4, marginLeft: 6 }}>
          {TOUR_STOPS.map((_, i) => (
            <span key={i} style={{ width: i === step ? 14 : 6, height: 6, borderRadius: 3, background: i <= step ? j.txt : j.bdr }} />
          ))}
        </span>
        {!last && <button onClick={exit} style={{ ...btn(false), marginLeft: "auto" }}>Exit tour</button>}
      </div>
    </div>
  );
}
