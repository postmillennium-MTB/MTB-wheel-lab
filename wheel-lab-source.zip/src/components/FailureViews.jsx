import * as React from "react";
import FailureMap from "./FailureMap.jsx";
import SpokeRing from "./SpokeRing.jsx";
import { useHubFade } from "./HubFade.jsx";

/**
 * The COMPARE tab's failure views: the failure map and the spoke ring,
 * sharing one 148/157 hub choice and one Play crossfade, so either
 * section's controls move both. Props are FailureMap's.
 */
export default function FailureViews(props) {
  const fade = useHubFade();
  return (
    <>
      <FailureMap {...props} fade={fade} />
      <SpokeRing {...props} fade={fade} />
    </>
  );
}
