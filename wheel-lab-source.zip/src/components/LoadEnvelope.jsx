import * as React from "react";
import { theme as j } from "../theme-state.js";
import { spokeModel, firstSlackCombined } from "../physics.js";
import ToggleGroup from "./ToggleGroup.jsx";
import Section from "./Section.jsx";
import { HUB_LABELS, useNarrow } from "./HubFade.jsx";

// LOAD ENVELOPE: every combination of straight-down and sideways load at
// the tire that the wheel takes before its first spoke goes slack. Ford's
// discrete-spoke Mode Matrix is linear up to first slack, so the boundary
// is exact in his model: for each direction, wheel-physics-core's
// firstSlackCombined superposes the validated sideways and straight-down
// spoke responses and finds the first spoke to reach zero (checked against
// his bike-wheel-calc with both loads applied at once, validation/spokes/).
// The edge is first spoke slack, not a taco or permanent damage.

const WIDE = { l: 56, r: 18, t: 22, b: 54, w: 640, h: 420 };
const NARROW = { l: 46, r: 10, t: 18, b: 52, w: 420, h: 440 };
const N_DIR = 720;
const OPEN_KEY = "wsl-load-envelope-open";
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

// Load capacity of build m along (lat, rad) in chart terms: lat > 0 is
// toward the real non-drive side. Returns the multiple of the vector that
// first slackens a spoke (> 1 = inside the envelope).
const capacity = (m, lat, rad) => firstSlackCombined(m.res, { lat: lat * m.toNDS, rad }).scale;

function envelope(m) {
  const pts = [];
  for (let n = 0; n <= N_DIR; n++) {
    const ph = n / N_DIR * Math.PI, dl = Math.cos(ph), dr = Math.sin(ph), k = capacity(m, dl, dr);
    pts.push([k * dl, k * dr]);
  }
  return pts;
}

function readOpen() {
  try { return localStorage.getItem(OPEN_KEY) !== "0"; } catch (err) { return true; }
}

function Chart({ envs, which, names, lat, rad, setPoint, narrow, xm, ym }) {
  const E = narrow ? NARROW : WIDE;
  const EX = (v) => E.l + (v + xm) / (2 * xm) * (E.w - E.l - E.r);
  const EY = (v) => E.h - E.b - v / ym * (E.h - E.t - E.b);
  const txt = { fill: j.muted, fontFamily: "Space Mono, monospace", fontSize: narrow ? 12.5 : 11 };
  const lbl = { fill: j.txt, fontFamily: "Space Grotesk, system-ui", fontSize: narrow ? 13.5 : 12.5, fontWeight: 500 };
  const svg = React.useRef(null), drag = React.useRef(false);
  const colors = [j.h148, j.h157];
  const ystep = ym > 300 ? 100 : 50, xstep = xm > 30 ? 10 : 5;
  const yTicks = [], xTicks = [];
  for (let v = 0; v <= ym; v += ystep) yTicks.push(v);
  for (let v = -Math.floor(xm / xstep) * xstep; v <= xm; v += xstep) xTicks.push(v);
  const pts = (e) => e.map(([x, y]) => `${EX(x)},${EY(y)}`).join(" ");
  const e = envs[which];
  const inside = envs[which].cap > 1;

  const move = (ev) => {
    const el = svg.current, pt = el.createSVGPoint();
    pt.x = ev.clientX; pt.y = ev.clientY;
    const p = pt.matrixTransform(el.getScreenCTM().inverse());
    const l = Math.max(-xm, Math.min(xm, (p.x - E.l) / (E.w - E.l - E.r) * 2 * xm - xm));
    const r = Math.max(0, Math.min(ym, (E.h - E.b - p.y) / (E.h - E.t - E.b) * ym));
    setPoint(Math.round(l * 2) / 2, Math.round(r));
  };
  // A mouse can grab anywhere on the chart; a finger only on the dot, so
  // the page still scrolls when a thumb lands on the chart.
  const down = (ev, onDot) => {
    if (!onDot && ev.pointerType !== "mouse") return;
    drag.current = true;
    svg.current.setPointerCapture(ev.pointerId);
    move(ev);
    ev.stopPropagation();
  };
  const ym2 = (E.t + E.h - E.b) / 2, yl = narrow ? 12 : 14;

  return (
    <svg ref={svg} viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label={`Load envelope for ${names[which]}: straight-down against sideways load`}
      style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}
      onPointerDown={(ev) => down(ev, false)}
      onPointerMove={(ev) => { if (drag.current) move(ev); }}
      onPointerUp={() => { drag.current = false; }} onPointerCancel={() => { drag.current = false; }}>
      {yTicks.map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={EY(v)} y2={EY(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 8} y={EY(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      {xTicks.map((v) => (
        <g key={v}>
          <line x1={EX(v)} x2={EX(v)} y1={E.t} y2={E.h - E.b} stroke={j.bdr} strokeWidth={v ? 0.6 : 1.5} />
          {(!narrow || v % (2 * xstep) === 0) && <text {...txt} x={EX(v)} y={E.h - E.b + 16} textAnchor="middle">{Math.abs(v)}</text>}
        </g>
      ))}
      <text {...txt} x={E.l} y={E.h - 10}>{narrow ? "← toward drive side" : "← sideways toward drive side (kgf)"}</text>
      <text {...txt} x={E.w - E.r} y={E.h - 10} textAnchor="end">{narrow ? "non-drive side →" : "toward non-drive side →"}</text>
      <text {...txt} x={yl} y={ym2} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym2})`}>straight-down load (kgf)</text>
      <polygon points={pts(envs[1 - which].pts)} fill="none" stroke={j.muted} strokeWidth={1.4} strokeDasharray="3 4" />
      <polygon points={pts(e.pts)} fill={`color-mix(in srgb, ${colors[which]} 14%, transparent)`} stroke={colors[which]} strokeWidth={2.4} />
      <text {...lbl} x={EX(0) + 8} y={EY(e.F_rad) - 8}>{`${fmt(e.F_rad)} straight down`}</text>
      <text {...lbl} x={EX(e.pts[0][0]) + 6} y={EY(0) - 8}>{fmt(e.pts[0][0], 1)}</text>
      <text {...lbl} x={EX(e.pts[N_DIR][0]) - 6} y={EY(0) - 8} textAnchor="end">{fmt(-e.pts[N_DIR][0], 1)}</text>
      <line x1={EX(0)} y1={EY(0)} x2={EX(lat)} y2={EY(rad)} stroke={j.txt} strokeWidth={1} strokeDasharray="3 3" />
      <circle cx={EX(lat)} cy={EY(rad)} r={8} fill={inside ? j.txt : j.slack} stroke={j.surf} strokeWidth={2} pointerEvents="none" />
      {/* larger invisible handle so a finger can catch the dot */}
      <circle cx={EX(lat)} cy={EY(rad)} r={20} fill="transparent" style={{ cursor: "grab", touchAction: "none" }}
        onPointerDown={(ev) => down(ev, true)} />
    </svg>
  );
}

/**
 * hubs = [hub148, hub157]; names = their display names; erd, spokes,
 * offset, tension as for FailureMap. Lives on DEEP DIVE with its own hub
 * picker, separate from the COMPARE tab's failure views.
 */
export default function LoadEnvelope({ hubs, names, erd, spokes, offset, tension, openSignal }) {
  const [open, setOpen] = React.useState(readOpen);
  // The Start here tour opens the chart when its stop arrives, without
  // changing the reader's saved show/hide choice.
  React.useEffect(() => { if (openSignal) setOpen(true); }, [openSignal]);
  const toggle = () => setOpen((o) => {
    try { localStorage.setItem(OPEN_KEY, o ? "0" : "1"); } catch (err) {}
    return !o;
  });
  const [which, setWhich] = React.useState(0);
  const [point, setPointState] = React.useState(null);   // null = default
  const [envs, setEnvs] = React.useState(null);
  React.useEffect(() => {
    if (!open) return;
    const id = setTimeout(() => setEnvs(hubs.map((h) => {
      const m = spokeModel(h, erd, spokes, offset, tension);
      return m.pastBuckling ? { m } : { m, pts: envelope(m), F_rad: m.res.F_rad };
    })), 20);
    return () => clearTimeout(id);
  }, [open, hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, open);

  const body = () => {
    if (!envs) return <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the envelope…</p>;
    if (envs.some((e) => !e.pts)) {
      return (
        <p style={{ fontSize: 11, color: j.warn, margin: "8px 0 0", lineHeight: 1.6 }}>
          At this rim size and tension {envs.every((e) => !e.pts) ? "both builds are" : !envs[0].pts ? "the 148 build is" : "the 157 build is"} at or past the rim's buckling tension, so there is no load envelope to draw. Lower the tension or pick a smaller rim.
        </p>
      );
    }
    // Axes fit both hubs, so switching hub shows the shape change, not the scale.
    const xm = Math.ceil(Math.max(...envs.flatMap((e) => e.pts.map((p) => Math.abs(p[0])))) * 1.12 / 5) * 5;
    const ym = Math.ceil(Math.max(...envs.map((e) => e.F_rad)) * 1.12 / 50) * 50;
    const lat = point ? Math.max(-xm, Math.min(xm, point[0])) : Math.round(envs[0].pts[0][0] * 0.4 * 2) / 2;
    const rad = point ? Math.max(0, Math.min(ym, point[1])) : Math.round(envs[0].F_rad * 0.4);
    const caps = envs.map((e) => (lat || rad ? capacity(e.m, lat, rad) : Infinity));
    const withCap = envs.map((e, i) => ({ ...e, cap: caps[i] }));
    const used = (i) => 100 / caps[i];
    const short = (i) => (i === 0 ? "148" : "157");
    const o = 1 - which, inside = caps[which] > 1;
    const verdict = !lat && !rad ? "No load." :
      `${fmt(rad)} kgf down with ${fmt(Math.abs(lat), 1)} kgf sideways${lat ? (lat > 0 ? " toward the non-drive side" : " toward the drive side") : ""} uses ${fmt(used(which))}% of the ${short(which)}'s margin and ${fmt(used(o))}% of the ${short(o)}'s. ` +
      (inside ? "Every spoke still has tension." : `A spoke has gone slack on the ${short(which)}` + (caps[o] > 1 ? `, but the ${short(o)} would still hold.` : ", and on the other hub too."));
    const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };
    const colors = [j.h148, j.h157];
    const slider = (label, val, min, max, step, set, fmtd) => (
      <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 10, color: j.muted, fontFamily: "Space Mono, monospace", flex: "1 1 240px", minWidth: 0 }}>
        {label}
        <input type="range" min={min} max={max} step={step} value={val} onChange={(ev) => set(Number(ev.target.value))}
          aria-label={label} style={{ flex: 1, minWidth: 0, accentColor: j.slack }} />
        <span style={{ color: j.txt, fontWeight: 700, minWidth: 70, textAlign: "right" }}>{fmtd}</span>
      </label>
    );
    const setPoint = (l, r) => setPointState([l, r]);

    return (
      <>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 12px", lineHeight: 1.6 }}>
          Real hits are rarely straight down: landing while leaning into a berm pushes the wheel down and sideways at once. The shape is every combination the wheel takes before its first spoke goes slack. Drag the dot or use the sliders.
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 14px", marginBottom: 10 }}>
          <ToggleGroup label="HUB" opts={HUB_LABELS} val={HUB_LABELS[which]} set={(v) => setWhich(HUB_LABELS.indexOf(v))} activeColor={colors[which]} />
        </div>
        <div style={{ fontFamily: "Space Grotesk, system-ui", fontWeight: 700, fontSize: narrow ? 17 : 20, lineHeight: 1.2, color: colors[which], margin: "2px 0 4px" }}>
          {names[which]}
        </div>
        <Chart envs={withCap} which={which} names={names} lat={lat} rad={rad} setPoint={setPoint} narrow={narrow} xm={xm} ym={ym} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 10px", fontFamily: "Space Mono, monospace" }}>
          <span style={keyRow}><i style={{ display: "inline-block", width: 18, height: 3, background: colors[which] }} />{`${short(which)}: no spoke slack inside`}</span>
          <span style={keyRow}><i style={{ display: "inline-block", width: 18, height: 3, background: `repeating-linear-gradient(90deg, ${j.muted} 0 3px, transparent 3px 7px)` }} />{short(o)}</span>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "8px 18px" }}>
          {slider("SIDEWAYS", lat, -xm, xm, 0.5, (v) => setPoint(v, rad), `${lat < 0 ? "← " : lat > 0 ? "→ " : ""}${fmt(Math.abs(lat), 1)} kgf`)}
          {slider("DOWN", rad, 0, ym, 1, (v) => setPoint(lat, v), `${fmt(rad)} kgf`)}
        </div>
        <p style={{ fontSize: 11, color: inside ? j.txt : j.warn, margin: "12px 0 0", lineHeight: 1.6 }}>{verdict}</p>
        <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
          From Matthew Ford's discrete-spoke Mode Matrix, which is linear up to first slack, so the edge is exact in his model for a point load on the rim. The shape leans because the non-drive spokes start looser. Its edge marks the first spoke going slack, not where the rim tacos or bends for good.
        </p>
      </>
    );
  };

  return (
    <Section title="LOAD ENVELOPE" subtitle={open ? "down + sideways · tap to hide" : "down + sideways · tap to show"} openState={open} onToggle={toggle}>
      <div ref={wrap}>{open && body()}</div>
    </Section>
  );
}
