import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

/** Collapsible bordered panel with a title, optional subtitle, and a chevron toggle. */
function Section({title:e,subtitle:t,children:r,defaultOpen:n=!0,openState:i,onToggle:o}){let[a,l]=(0,se.useState)(n),u=i!==void 0?i:a,s=o||(()=>l(f=>!f));return(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,marginBottom:12,overflow:"hidden"},children:[(0,_.jsxs)("button",{onClick:s,style:{width:"100%",display:"flex",alignItems:"center",gap:10,padding:"11px 16px",background:"transparent",border:"none",cursor:"pointer",textAlign:"left"},children:[(0,_.jsx)("span",{style:{color:j.muted,fontSize:12,transition:"transform 0.18s",transform:u?"rotate(90deg)":"rotate(0deg)",display:"inline-block"},children:"\u25B6"}),(0,_.jsx)("span",{style:{fontFamily:"Space Grotesk, system-ui",fontWeight:600,fontSize:12,color:j.txt,letterSpacing:"0.04em"},children:e}),t&&(0,_.jsx)("span",{style:{fontSize:10,color:j.muted,marginLeft:"auto"},children:t})]}),u&&(0,_.jsx)("div",{style:{padding:"0 16px 16px"},children:r})]})}

export default Section;
