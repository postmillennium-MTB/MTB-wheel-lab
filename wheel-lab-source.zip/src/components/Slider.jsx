import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

/** Labeled range slider with a live numeric readout. */
function Slider({label:e,value:t,min:r,max:n,step:i,unit:o,onChange:a,color:l}){return(0,_.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:2,minWidth:140,flex:1},children:[(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between"},children:[(0,_.jsx)("span",{style:{fontSize:10,color:j.muted},children:e}),(0,_.jsxs)("span",{style:{fontSize:10,color:l||j.txt,fontFamily:"Space Mono, monospace",fontWeight:700},children:[t,o]})]}),(0,_.jsx)("input",{type:"range",min:r,max:n,step:i,value:t,onChange:u=>a(Number(u.target.value)),style:{width:"100%",accentColor:l||j.acc,height:4}})]})}

export default Slider;
