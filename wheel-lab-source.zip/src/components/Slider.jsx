import * as React from "react";
import { theme as j } from "../theme-state.js";

// Half the width of the browser's range thumb. The thumb's centre travels
// from THUMB_HALF to (width - THUMB_HALF), not from 0 to width, so a mark
// placed at a plain percentage would sit off the value it names.
const THUMB_HALF = 8;

/**
 * Labeled range slider with a live numeric readout.
 *
 * Optional `marks` ([{ value, color, name }]) draws a small tick under the
 * track for each mark that falls inside the slider's range, and a caption
 * (`marksLabel` + every mark's value and name) under it. The caption carries
 * every value in words, including marks outside the range, so the ticks'
 * colors are never the only cue.
 */
function Slider({ label, value, min, max, step, unit, onChange, color, marks, marksLabel }) {
  const shown = (marks || []).filter((m) => m.value >= min && m.value <= max);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 140, flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: 10, color: j.muted }}>{label}</span>
        <span style={{ fontSize: 10, color: color || j.txt, fontFamily: "Space Mono, monospace", fontWeight: 700 }}>{value}{unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(u) => onChange(Number(u.target.value))} style={{ width: "100%", accentColor: color || j.acc, height: 4 }} />
      {marks && marks.length > 0 && (
        <>
          <div aria-hidden="true" style={{ position: "relative", height: 6, marginTop: 1 }}>
            {shown.map((m, i) => (
              <span key={m.name} style={{
                position: "absolute", top: 0, width: 3, height: i === 0 ? 6 : 4, borderRadius: 1, background: m.color,
                left: `calc(${THUMB_HALF}px + (100% - ${2 * THUMB_HALF}px) * ${((m.value - min) / (max - min)).toFixed(4)} - 1.5px)`,
              }} />
            ))}
          </div>
          <div style={{ fontSize: 8.5, color: j.muted, lineHeight: 1.35 }}>
            {marksLabel} {marks.map((m, i) => (
              <React.Fragment key={m.name}>
                {i > 0 && " · "}
                <span style={{ fontFamily: "Space Mono, monospace", color: j.txt }}>{m.value}</span> ({m.name})
              </React.Fragment>
            ))} kgf
          </div>
        </>
      )}
    </div>
  );
}

export default Slider;
