import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";
import { bracingAngleDeg } from "../physics.js";

// Layout constants for the SVG (pixel-space, not physical units).
// Taller than the original (188 -> 224) so the NDS(L)/DS(R) footer
// labels have room below the hub illustration instead of clipping
// against the viewBox edge.
const DIAGRAM_WIDTH = 280;
const DIAGRAM_HEIGHT = 224;
const CENTER_X = DIAGRAM_WIDTH / 2; // 140
const HUB_Y = 128; // vertical center of the hub cross-section
const RIM_APEX_Y = 34; // where the two spoke lines converge below the rim
const RIM_TOP_Y = 10; // top edge of the rim channel
const RIM_WALL_W = 6; // thickness of each rim sidewall
const RIM_FLOOR_Y = RIM_APEX_Y - 4; // inner floor of the rim channel: where the spokes terminate
const SPOKE_FLANGE_Y = HUB_Y - 4; // where a spoke leaves its flange, just above the hub centerline
// short aliases matching the original code's local names, scoped to this file only
const gm = DIAGRAM_WIDTH, fte = DIAGRAM_HEIGHT, Le = CENTER_X, ke = HUB_Y, apexY = RIM_APEX_Y, rimTopY = RIM_TOP_Y;

// Shared layout, exported so AnnotationOverlay.jsx can anchor its callouts to
// the same coordinate space instead of keeping a second, drifting copy of
// these numbers. Anything the overlay needs to point AT lives here.
export const DIAGRAM_LAYOUT = {
  width: DIAGRAM_WIDTH, height: DIAGRAM_HEIGHT, centerX: CENTER_X, hubY: HUB_Y,
  rimTopY: RIM_TOP_Y, rimFloorY: RIM_FLOOR_Y, rimWallW: RIM_WALL_W,
  spokeFlangeY: SPOKE_FLANGE_Y,
  freehubW: 24, // drive-side freehub/cassette stub length, measured out from the DS flange
  rotorW: 20,   // non-drive-side disc-rotor-mount stub length, measured in from the NDS flange
};

/**
 * The [x, y] point where a spoke crosses a given height in the diagram.
 * Spokes run from their flange up to the rim channel floor, so a callout
 * that wants to sit ON a spoke has to follow the flange as the slider
 * moves it. side is "DS" (right, solid) or "NDS" (left, dashed).
 */
export function spokePointAtY(flangeX, side, y) {
  const rimX = CENTER_X + (side === "DS" ? RIM_WALL_W * 0.6 : -RIM_WALL_W * 0.6);
  const span = SPOKE_FLANGE_Y - RIM_FLOOR_Y;
  const frac = Math.min(1, Math.max(0, (SPOKE_FLANGE_Y - y) / span));
  return [flangeX + (rimX - flangeX) * frac, y];
}

// Diagram scale: viewBox px drawn per mm of flange-to-centre distance. The
// original hand-tuned HUB_GEOMETRY entries were all plotted at this scale
// (39px/20mm, 72px/37mm, 49px/24.5mm, 81px/41.5mm all land on ~1.95), so
// deriving positions from real hub numbers draws them at the size they have
// always been. Widen it and the widest hub in the database (43mm NDS) starts
// pushing its rotor stub off the left edge of the viewBox.
export const MM_TO_PX = 1.95;

/**
 * Drawing geometry for one real hub: flange positions, the dimension labels,
 * and the bracing-angle callouts.
 *
 * Spread this over a HUB_GEOMETRY entry — the entry keeps supplying label,
 * tag and the standard-level comparison metrics, while everything the diagram
 * actually draws follows the hub the user picked. Before this existed the
 * COMPARE tab drew the same fixed 37mm/20mm hub no matter which one was
 * selected, even though the strength figures beside it were responding to the
 * dropdown correctly.
 *
 * @param hub   a HUBS_148 / HUBS_157 record ({ nds, ds, pds, pnds } in mm)
 * @param erd   rim diameter (mm) — the bracing angle depends on wheel size
 * @param spokes spoke count — 3-cross chord length depends on it
 */
export function hubDiagramGeometry(hub, erd, spokes) {
  return {
    DS_px: hub.ds * MM_TO_PX,
    NDS_px: hub.nds * MM_TO_PX,
    // Rounded for the dimension labels: real hubs carry figures like 22.92mm
    // and two decimals do not fit the callout or mean anything at this scale.
    flangeR: +hub.ds.toFixed(1),
    flangeL: +hub.nds.toFixed(1),
    DS_angle: bracingAngleDeg(erd, hub.ds, hub.pds, spokes).toFixed(1) + "\u00B0",
    NDS_angle: bracingAngleDeg(erd, hub.nds, hub.pnds, spokes).toFixed(1) + "\u00B0",
  };
}

/**
 * Renders the hub-and-spoke SVG diagram: an MTB hub cross-section at the
 * bottom, two spoke lines rising to a single apex, and a rim channel
 * cross-section (a "U" in profile) at the top where those spokes actually
 * terminate. Earlier versions ringed the whole thing with a full circle
 * standing in for the wheel — misleading here, since this is a cross
 * section, not a plan view of the wheel — so that circle is gone; the rim
 * cross-section replaces it as the thing the spokes are actually shown
 * meeting.
 * @param geo   { DS_px, NDS_px, DS_angle, NDS_angle, flangeR, flangeL }
 * @param capKgf  lateral strength value to display (already formatted)
 * @param color   accent color for this hub's diagram
 */
function WheelDiagram({geo:e,capKgf:t,color:r}){
  let n=Le+e.DS_px,        // DS (right) flange anchor x
      i=Le-e.NDS_px;       // NDS (left) flange anchor x

  // Hub cross-section geometry (bottom of the diagram).
  const barrelHalfH=8,     // hub shell (barrel) half-height
        flangeHalfH=19,    // flange disc half-height
        flangeHalfW=4.5,   // flange disc half-width
        freehubW=DIAGRAM_LAYOUT.freehubW,  // freehub-body / cassette-spline stub length (DS)
        freehubHalfH=6.5,
        rotorW=DIAGRAM_LAYOUT.rotorW,      // disc-rotor-mount stub length (NDS)
        rotorHalfH=7,
        axleHalfH=2.2;     // exposed axle end half-height

  // Spoke lines run from each flange's outer edge up to a single apex
  // point, where they actually terminate into the rim channel below.
  let dsSpokeX=n, ndsSpokeX=i;

  // Rim cross-section ("U" channel) centered above the apex.
  const rimHalfW=34, rimWallW=RIM_WALL_W, rimBedY=rimTopY+9, rimFloorY=RIM_FLOOR_Y;

  let m=ke+38,h=4; // dimension-line y and tick half-height (below the hub)
  let plk={color:j.acc};

  return(0,_.jsxs)("svg",{viewBox:`0 0 ${gm} ${fte}`,style:{width:"100%",display:"block"},children:[

    // ---- Rim cross-section ("U" channel), where the spokes actually meet the rim ----
    (0,_.jsx)("path",{d:`M ${Le-rimHalfW} ${rimBedY} L ${Le-rimHalfW} ${rimTopY} L ${Le-rimHalfW+rimWallW} ${rimTopY} L ${Le-rimHalfW+rimWallW} ${rimBedY-6} L ${Le+rimHalfW-rimWallW} ${rimBedY-6} L ${Le+rimHalfW-rimWallW} ${rimTopY} L ${Le+rimHalfW} ${rimTopY} L ${Le+rimHalfW} ${rimBedY} L ${Le+rimHalfW-rimWallW} ${rimBedY} L ${Le+rimHalfW-rimWallW} ${rimFloorY} L ${Le-rimHalfW+rimWallW} ${rimFloorY} L ${Le-rimHalfW+rimWallW} ${rimBedY} Z`,fill:j.surfl,stroke:j.bdr,strokeWidth:"1.4",strokeLinejoin:"round"}),
    // spoke nipple holes in the rim bed
    (0,_.jsx)("circle",{cx:Le-rimHalfW+rimWallW/2,cy:rimBedY-1,r:1.6,fill:j.dim}),
    (0,_.jsx)("circle",{cx:Le+rimHalfW-rimWallW/2,cy:rimBedY-1,r:1.6,fill:j.dim}),
    (0,_.jsx)("text",{x:Le,y:rimTopY-3,textAnchor:"middle",fill:j.muted,fontSize:"7",fontFamily:"Space Mono, monospace",letterSpacing:"0.05em",opacity:"0.7",children:"RIM"}),

    // ---- Spokes: two lines from the flanges up to the rim floor ----
    (0,_.jsx)("line",{x1:dsSpokeX,y1:SPOKE_FLANGE_Y,x2:Le+rimWallW*0.6,y2:rimFloorY,stroke:r,strokeWidth:"2.4"}),
    (0,_.jsx)("line",{x1:ndsSpokeX,y1:SPOKE_FLANGE_Y,x2:Le-rimWallW*0.6,y2:rimFloorY,stroke:r,strokeWidth:"2",strokeDasharray:"5,3.5",opacity:"0.7"}),

    // ---- LATERAL STRENGTH readout, in the open space between rim and hub ----
    (0,_.jsx)("text",{x:Le,y:70,textAnchor:"middle",fill:r,fontSize:"7.5",fontFamily:"Space Grotesk, system-ui",fontWeight:"600",opacity:"0.85",letterSpacing:"0.05em",children:"LATERAL STRENGTH"}),
    (0,_.jsx)("text",{x:Le,y:93,textAnchor:"middle",fill:r,fontSize:"22",fontFamily:"Space Mono, monospace",fontWeight:"700",children:t}),
    (0,_.jsx)("text",{x:Le,y:106,textAnchor:"middle",fill:r,fontSize:"8",fontFamily:"Space Mono, monospace",opacity:"0.55",children:"kgf"}),

    // ---- Flange bracing-angle callouts ----
    (0,_.jsx)("text",{x:n,y:ke-flangeHalfH-8,textAnchor:"middle",fill:r,fontSize:"10",fontFamily:"Space Mono, monospace",fontWeight:"700",children:e.DS_angle}),
    (0,_.jsx)("text",{x:i,y:ke-flangeHalfH-8,textAnchor:"middle",fill:r,fontSize:"10",fontFamily:"Space Mono, monospace",fontWeight:"700",opacity:"0.65",children:e.NDS_angle}),

    // ==== MTB HUB CROSS-SECTION ====
    // Axle stubs, exposed both ends (thru-axle interface)
    (0,_.jsx)("line",{x1:8,y1:ke,x2:i-rotorW-4,y2:ke,stroke:j.dim,strokeWidth:(axleHalfH*2).toString(),strokeLinecap:"round"}),
    (0,_.jsx)("line",{x1:n+freehubW+4,y1:ke,x2:gm-8,y2:ke,stroke:j.dim,strokeWidth:(axleHalfH*2).toString(),strokeLinecap:"round"}),

    // Disc-rotor-mount stub, non-drive side (left) — six bolt/spline ticks
    (0,_.jsx)("rect",{x:i-rotorW,y:ke-rotorHalfH,width:rotorW,height:rotorHalfH*2,rx:1.5,fill:j.surfl,stroke:j.bdr,strokeWidth:"1.2"}),
    ...[0,1,2,3,4,5].map(k=>(0,_.jsx)("line",{x1:i-rotorW+3+k*((rotorW-6)/5),y1:ke-rotorHalfH+1.5,x2:i-rotorW+3+k*((rotorW-6)/5),y2:ke+rotorHalfH-1.5,stroke:j.dim,strokeWidth:"1",opacity:"0.55"},"rotor"+k)),

    // Freehub body / cassette-spline stub, drive side (right) — ridged splines
    (0,_.jsx)("rect",{x:n,y:ke-freehubHalfH,width:freehubW,height:freehubHalfH*2,rx:1.5,fill:j.surfl,stroke:j.bdr,strokeWidth:"1.2"}),
    ...[0,1,2,3,4,5,6].map(k=>(0,_.jsx)("line",{x1:n+3+k*((freehubW-6)/6),y1:ke-freehubHalfH+1.2,x2:n+3+k*((freehubW-6)/6),y2:ke+freehubHalfH-1.2,stroke:j.dim,strokeWidth:"1",opacity:"0.6"},"fh"+k)),

    // Hub shell / barrel spanning between the flanges
    (0,_.jsx)("path",{d:`M ${i} ${ke-barrelHalfH} L ${n} ${ke-barrelHalfH*0.55} L ${n} ${ke+barrelHalfH*0.55} L ${i} ${ke+barrelHalfH} Z`,fill:j.surfl,stroke:j.bdr,strokeWidth:"1.2"}),

    // NDS flange disc (left)
    (0,_.jsx)("path",{d:`M ${i-flangeHalfW} ${ke-flangeHalfH} Q ${i} ${ke-flangeHalfH-4} ${i+flangeHalfW} ${ke-flangeHalfH} L ${i+flangeHalfW} ${ke+flangeHalfH} Q ${i} ${ke+flangeHalfH+4} ${i-flangeHalfW} ${ke+flangeHalfH} Z`,fill:r,opacity:"0.6",stroke:r,strokeWidth:"1"}),
    // DS flange disc (right)
    (0,_.jsx)("path",{d:`M ${n-flangeHalfW} ${ke-flangeHalfH} Q ${n} ${ke-flangeHalfH-4} ${n+flangeHalfW} ${ke-flangeHalfH} L ${n+flangeHalfW} ${ke+flangeHalfH} Q ${n} ${ke+flangeHalfH+4} ${n-flangeHalfW} ${ke+flangeHalfH} Z`,fill:r,stroke:r,strokeWidth:"1"}),

    // Flange spoke-hole ticks (one visible pair per flange, cross-section view)
    (0,_.jsx)("circle",{cx:n-1,cy:ke-flangeHalfH+6,r:1.6,fill:j.bg}),
    (0,_.jsx)("circle",{cx:n-1,cy:ke+flangeHalfH-6,r:1.6,fill:j.bg}),
    (0,_.jsx)("circle",{cx:i+1,cy:ke-flangeHalfH+6,r:1.6,fill:j.bg}),
    (0,_.jsx)("circle",{cx:i+1,cy:ke+flangeHalfH-6,r:1.6,fill:j.bg}),

    // Hub bore centerline
    (0,_.jsx)("line",{x1:i-rotorW,y1:ke,x2:n+freehubW,y2:ke,stroke:j.dim,strokeWidth:"0.6",strokeDasharray:"1,3",opacity:"0.5"}),

    // ---- Flange width dimension lines ----
    (0,_.jsx)("line",{x1:Le,y1:m,x2:i,y2:m,stroke:r,strokeWidth:"1",opacity:"0.55"}),
    (0,_.jsx)("line",{x1:Le,y1:m-h,x2:Le,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.55"}),
    (0,_.jsx)("line",{x1:i,y1:m-h,x2:i,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.55"}),
    (0,_.jsxs)("text",{x:(Le+i)/2,y:m-5,textAnchor:"middle",fill:r,fontSize:"8.5",fontFamily:"Space Mono, monospace",opacity:"0.85",children:[e.flangeL,"mm"]}),
    (0,_.jsx)("line",{x1:Le,y1:m,x2:n,y2:m,stroke:r,strokeWidth:"1",opacity:"0.85"}),
    (0,_.jsx)("line",{x1:n,y1:m-h,x2:n,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.85"}),
    (0,_.jsxs)("text",{x:(Le+n)/2,y:m-5,textAnchor:"middle",fill:r,fontSize:"8.5",fontFamily:"Space Mono, monospace",children:[e.flangeR,"mm"]}),

    // ---- Side labels, with headroom below the dimension line now that the viewBox is taller ----
    (0,_.jsx)("text",{x:i,y:m+16,textAnchor:"middle",fill:j.muted,fontSize:"8",children:"NDS (L)"}),
    (0,_.jsx)("text",{x:n,y:m+16,textAnchor:"middle",fill:j.muted,fontSize:"8",children:"DS (R)"}),

    // Caption sits below everything else, clear of the side labels above it.
    (0,_.jsx)("text",{x:Le,y:m+31,textAnchor:"middle",fill:j.muted,fontSize:"7.5",fontFamily:"Space Grotesk, system-ui",fontWeight:"600",letterSpacing:"0.06em",opacity:"0.7",children:"MTB HUB CROSS-SECTION"}),
  ]});
}

export default WheelDiagram;
