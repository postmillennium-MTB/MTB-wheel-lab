import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

// Layout constants for the SVG (pixel-space, not physical units).
const DIAGRAM_WIDTH = 280;
const DIAGRAM_HEIGHT = 188;
const CENTER_X = DIAGRAM_WIDTH / 2; // 140
const HUB_Y = 150;
const HUB_RADIUS_PX = 16;
const RIM_RADIUS_PX = HUB_Y - HUB_RADIUS_PX; // 134
// short aliases matching the original code's local names, scoped to this file only
const gm = DIAGRAM_WIDTH, fte = DIAGRAM_HEIGHT, Le = CENTER_X, ke = HUB_Y, Yt = HUB_RADIUS_PX, cc = RIM_RADIUS_PX;

/**
 * Renders the hub-and-spoke SVG diagram with the lateral-strength readout,
 * flange angle callouts, and flange-width dimension lines.
 * @param geo   { DS_px, NDS_px, DS_angle, NDS_angle, flangeR, flangeL }
 * @param capKgf  lateral strength value to display (already formatted)
 * @param color   accent color for this hub's diagram
 */
function WheelDiagram({geo:e,capKgf:t,color:r}){let n=Le+e.DS_px,i=Le-e.NDS_px,o=(n+Le+i)/3,a=(ke+Yt+ke)/3,l=18,u=Math.atan2(e.DS_px,cc),s=Math.atan2(e.NDS_px,cc),f=n-l*Math.sin(u),c=ke-l*Math.cos(u),p=i+l*Math.sin(s),d=ke-l*Math.cos(s),x=55*Math.PI/180,y=Le+cc*Math.sin(x),w=ke-cc*Math.cos(x),m=ke+26,h=4;return(0,_.jsxs)("svg",{viewBox:`0 0 ${gm} ${fte}`,style:{width:"100%",display:"block"},children:[(0,_.jsx)("circle",{cx:Le,cy:ke,r:cc,fill:"none",stroke:j.bdr,strokeWidth:"2.5"}),(0,_.jsx)("line",{x1:8,y1:ke,x2:gm-8,y2:ke,stroke:j.dim,strokeWidth:"2.5",strokeLinecap:"round"}),(0,_.jsx)("line",{x1:n,y1:ke,x2:y,y2:w,stroke:r,strokeWidth:"1.2",opacity:"0.16"}),(0,_.jsx)("line",{x1:i,y1:ke,x2:gm-y,y2:w,stroke:r,strokeWidth:"1.2",strokeDasharray:"4,3",opacity:"0.12"}),(0,_.jsx)("path",{d:`M ${n} ${ke} L ${Le} ${Yt} L ${i} ${ke} Z`,fill:r,opacity:"0.13"}),(0,_.jsx)("path",{d:`M ${n} ${ke} L ${Le} ${Yt} L ${i} ${ke} Z`,fill:"none",stroke:r,strokeWidth:"0.6",opacity:"0.25"}),(0,_.jsx)("text",{x:o,y:a-8,textAnchor:"middle",fill:r,fontSize:"7.5",fontFamily:"Space Grotesk, system-ui",fontWeight:"600",opacity:"0.85",letterSpacing:"0.05em",children:"LATERAL STRENGTH"}),(0,_.jsx)("text",{x:o,y:a+15,textAnchor:"middle",fill:r,fontSize:"22",fontFamily:"Space Mono, monospace",fontWeight:"700",children:t}),(0,_.jsx)("text",{x:o,y:a+28,textAnchor:"middle",fill:r,fontSize:"8",fontFamily:"Space Mono, monospace",opacity:"0.55",children:"kgf"}),(0,_.jsx)("line",{x1:Le-16,y1:Yt,x2:Le+16,y2:Yt,stroke:j.muted,strokeWidth:"1",opacity:"0.4"}),(0,_.jsx)("polyline",{points:`${Le+11},${Yt-3} ${Le+16},${Yt} ${Le+11},${Yt+3}`,fill:"none",stroke:j.muted,strokeWidth:"1",opacity:"0.4"}),(0,_.jsx)("polyline",{points:`${Le-11},${Yt-3} ${Le-16},${Yt} ${Le-11},${Yt+3}`,fill:"none",stroke:j.muted,strokeWidth:"1",opacity:"0.4"}),(0,_.jsx)("line",{x1:i,y1:ke,x2:Le,y2:Yt,stroke:r,strokeWidth:"2",strokeDasharray:"5,3.5",opacity:"0.6"}),(0,_.jsx)("line",{x1:n,y1:ke,x2:Le,y2:Yt,stroke:r,strokeWidth:"2.4"}),(0,_.jsx)("path",{d:`M ${n}  ${ke-l} A ${l} ${l} 0 0 0 ${f}  ${c}`,fill:"none",stroke:r,strokeWidth:"1.5"}),(0,_.jsx)("path",{d:`M ${i} ${ke-l} A ${l} ${l} 0 0 1 ${p} ${d}`,fill:"none",stroke:r,strokeWidth:"1.5",opacity:"0.6"}),(0,_.jsx)("text",{x:n-1,y:ke-l-6,textAnchor:"middle",fill:r,fontSize:"10",fontFamily:"Space Mono, monospace",fontWeight:"700",children:e.DS_angle}),(0,_.jsx)("text",{x:i,y:ke-l-6,textAnchor:"middle",fill:r,fontSize:"10",fontFamily:"Space Mono, monospace",fontWeight:"700",opacity:"0.65",children:e.NDS_angle}),(0,_.jsx)("circle",{cx:Le,cy:ke,r:6,fill:j.surf,stroke:r,strokeWidth:"1.5"}),(0,_.jsx)("circle",{cx:Le,cy:ke,r:2,fill:r,opacity:"0.6"}),(0,_.jsx)("circle",{cx:n,cy:ke,r:5,fill:r}),(0,_.jsx)("circle",{cx:n,cy:ke,r:2,fill:j.bg}),(0,_.jsx)("circle",{cx:i,cy:ke,r:5,fill:r,opacity:"0.6"}),(0,_.jsx)("circle",{cx:i,cy:ke,r:2,fill:j.bg}),(0,_.jsx)("circle",{cx:Le,cy:Yt,r:3.5,fill:j.dim}),(0,_.jsx)("line",{x1:Le,y1:m,x2:i,y2:m,stroke:r,strokeWidth:"1",opacity:"0.55"}),(0,_.jsx)("line",{x1:Le,y1:m-h,x2:Le,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.55"}),(0,_.jsx)("line",{x1:i,y1:m-h,x2:i,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.55"}),(0,_.jsxs)("text",{x:(Le+i)/2,y:m-5,textAnchor:"middle",fill:r,fontSize:"8.5",fontFamily:"Space Mono, monospace",opacity:"0.85",children:[e.flangeL,"mm"]}),(0,_.jsx)("line",{x1:Le,y1:m,x2:n,y2:m,stroke:r,strokeWidth:"1",opacity:"0.85"}),(0,_.jsx)("line",{x1:n,y1:m-h,x2:n,y2:m+h,stroke:r,strokeWidth:"1",opacity:"0.85"}),(0,_.jsxs)("text",{x:(Le+n)/2,y:m-5,textAnchor:"middle",fill:r,fontSize:"8.5",fontFamily:"Space Mono, monospace",children:[e.flangeR,"mm"]}),(0,_.jsx)("text",{x:i,y:m+14,textAnchor:"middle",fill:j.muted,fontSize:"8",children:"NDS (L)"}),(0,_.jsx)("text",{x:n,y:m+14,textAnchor:"middle",fill:j.muted,fontSize:"8",children:"DS (R)"})]})}

export default WheelDiagram;
