import * as se from "react";
import * as _ from "react/jsx-runtime";
import { THEMES } from "../themes.js";

// This is new code, not extracted from the original bundle. It closes the
// "no error boundary" gap: previously, an unexpected input to the physics
// calculation (e.g. a hub geometry combination that divides by zero
// somewhere in computeWheelStrength) would crash the whole app to a blank
// white page with no way to recover except reloading and losing any
// non-default settings. This catches that, shows a plain-language message,
// and offers a one-click reset.
//
// Deliberately a class component: React's error boundary mechanism
// (getDerivedStateFromError / componentDidCatch) is only available to
// class components as of React 18/19 -- there is no hook equivalent.
class ErrorBoundary extends se.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error("Wheel Strength Lab crashed:", error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (!this.state.hasError) {
      return this.props.children;
    }
    const theme = THEMES.c3;
    return (0, _.jsxs)("div", {
      style: {
        background: theme.bg,
        color: theme.txt,
        fontFamily: "system-ui, sans-serif",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        textAlign: "center",
      },
      children: [
        (0, _.jsxs)("div", {
          style: { maxWidth: 420 },
          children: [
            (0, _.jsx)("div", {
              style: { fontSize: 32, marginBottom: 12 },
              children: "\u26A0\uFE0F",
            }),
            (0, _.jsx)("h1", {
              style: { fontFamily: "Space Grotesk, system-ui", fontSize: 18, marginBottom: 8 },
              children: "Something went wrong",
            }),
            (0, _.jsx)("p", {
              style: { fontSize: 13, color: theme.muted, lineHeight: 1.6, marginBottom: 16 },
              children:
                "The Wheel Strength Lab hit an unexpected calculation error \u2014 likely from an extreme combination of settings. Your data wasn't lost anywhere else; resetting just clears this tool's current inputs.",
            }),
            (0, _.jsx)("button", {
              onClick: this.handleReset,
              style: {
                padding: "8px 18px",
                borderRadius: 7,
                border: `1px solid ${theme.bdr}`,
                background: theme.acc,
                color: theme.bg,
                fontWeight: 700,
                fontSize: 13,
                cursor: "pointer",
              },
              children: "Reset and try again",
            }),
          ],
        }),
      ],
    });
  }
}

export default ErrorBoundary;
