import * as React from "react";
import { theme as j } from "../theme-state.js";
import WheelMyWheel from "wheel-physics-core/js/my-wheel.js";
import WheelBuildLink from "wheel-physics-core/js/build-link.js";
import { HUBS_148, HUBS_157 } from "../data.js";

// MY WHEEL: one build a reader saves (a listed hub, wheel size, tension and
// spoke count), kept in their own browser only and opened again on the next
// visit. The record is wheel-physics-core's js/my-wheel.js, which the 148 vs
// 157 widget reads too (through the PMR page, which shares this page's
// origin), so a wheel saved in either tool shows in both. No account, no
// server, nothing sent anywhere. Only hubs in the list can be saved.
//
// A shared link always wins: the saved wheel is applied at load only when
// the address the Lab was opened with carries no build (checked here, at
// import time, before App.jsx starts rewriting the hash). Otherwise the bar
// offers "Show my wheel". "Forget" clears it.
//
// Icon: Lucide "bookmark" (https://lucide.dev), path data unchanged.
const SHARED_LINK = (() => { try { return WheelMyWheel.linkHasBuild(location.hash); } catch (e) { return false; } })();
const GROTESK = "Space Grotesk, system-ui";
const SVG = { xmlns: "http://www.w3.org/2000/svg", width: 13, height: 13, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", focusable: "false" };
const btn = () => ({ padding: "4px 10px", borderRadius: 7, cursor: "pointer", fontSize: 10.5, fontFamily: GROTESK, fontWeight: 700, background: j.surfl, color: j.txt, border: `1.5px solid ${j.bdr}` });
const hubOf = id => HUBS_148.find(h => h.id === id) || HUBS_157.find(h => h.id === id) || null;
const stdOfHub = id => (HUBS_148.some(h => h.id === id) ? "148" : HUBS_157.some(h => h.id === id) ? "157" : null);
const labTension = t => WheelBuildLink.snapTension(t, WheelBuildLink.TENSION.lab);

function loadSaved() {
  const b = WheelMyWheel.load();
  return b && stdOfHub(b.hub) === b.std ? b : null;
}

export default function MyWheelBar({ hub148, hub157, wheel, tension, spokes, apply }) {
  const [saved, setSaved] = React.useState(loadSaved);
  // Apply once at load, unless the Lab was opened from a link with a build.
  React.useEffect(() => { if (saved && !SHARED_LINK) apply(saved, labTension(saved.tension)); }, []);
  const onScreen = saved && spokes === saved.spokes && wheel === saved.wheel &&
    tension === labTension(saved.tension) && (hub148 === saved.hub || hub157 === saved.hub);
  const save = hub => {
    const b = WheelMyWheel.clean({ hub, std: stdOfHub(hub), wheel, tension, spokes });
    if (b && WheelMyWheel.save(b)) setSaved(b);
  };
  const forget = () => { WheelMyWheel.clear(); setSaved(null); };
  const icon = <svg {...SVG} className="lucide lucide-bookmark"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z" /></svg>;
  return (
    <div aria-live="polite" style={{ background: j.surf, border: `1px solid ${j.bdr}`, borderRadius: 8, padding: "8px 12px", marginBottom: 12, display: "flex", alignItems: "center", gap: "6px 8px", flexWrap: "wrap" }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 11, color: j.txt, fontWeight: 700, fontFamily: GROTESK, letterSpacing: "0.04em" }}>{icon}MY WHEEL</span>
      {saved ? (
        <>
          <span style={{ fontSize: 10.5, color: j.txt }}>{WheelMyWheel.describe(saved, (hubOf(saved.hub) || {}).name)}</span>
          {!onScreen && <button onClick={() => apply(saved, labTension(saved.tension))} style={btn()}>Show my wheel</button>}
          <button onClick={forget} aria-label="Forget my wheel in this browser" style={btn()}>Forget</button>
        </>
      ) : (
        <>
          <span style={{ fontSize: 10.5, color: j.muted }}>Is one of these your hub? Save it, kept in this browser only:</span>
          <button onClick={() => save(hub148)} style={btn()}>{(hubOf(hub148) || {}).name}</button>
          <button onClick={() => save(hub157)} style={btn()}>{(hubOf(hub157) || {}).name}</button>
        </>
      )}
    </div>
  );
}
