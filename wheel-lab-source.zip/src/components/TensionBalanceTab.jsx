import * as se from "react";
import * as _ from "react/jsx-runtime";
import { HUBS_148, HUBS_157, PHYS_CONSTANTS } from "../data.js";
import { computeWheelStrength, applyRimOffset, tightSideFirst } from "../physics.js";
import Section from "./Section.jsx";

// This tab is new code (not extracted from the original bundle), so it's
// written in the app's more readable idiom rather than the dense style
// documented in README.md for physics.js/App.jsx.

const SVGNS = "http://www.w3.org/2000/svg";

function median(nums) {
  const s = [...nums].sort((a, b) => a - b);
  const n = s.length, mid = Math.floor(n / 2);
  return n % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}
function fmt1(n) { return (Math.round(n * 10) / 10).toFixed(1); }
function el(tag, attrs) {
  const e = document.createElementNS(SVGNS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  return e;
}

/**
 * NDS/DS tension-balance ratio (%) for one hub at the app's current
 * spoke count / rim size / tension / rim-offset settings -- the same
 * computeWheelStrength() call the COMPARE tab uses for its two selected
 * hubs, just run once per hub in the catalogue. Because it reads straight
 * from HUBS_148/HUBS_157 (data.js) instead of a saved snapshot, adding a
 * hub there shows up here automatically.
 */
function ratioFor(hub, erd, spokes, tension, offset) {
  const geo = tightSideFirst(applyRimOffset(hub, offset), erd, spokes);
  return computeWheelStrength(
    erd, geo, 2, 2, tension,
    PHYS_CONSTANTS.EIL, PHYS_CONSTANTS.EIR, PHYS_CONSTANTS.GJ, PHYS_CONSTANTS.EA_rim,
    spokes, PHYS_CONSTANTS.modes
  ).ratio;
}

function showTooltip(wrap, tooltip, target, build) {
  tooltip.innerHTML = "";
  build(tooltip);
  tooltip.hidden = false;
  const wrapRect = wrap.getBoundingClientRect();
  const tRect = target.getBoundingClientRect();
  let x = tRect.left + tRect.width / 2 - wrapRect.left;
  const y = tRect.top - wrapRect.top;
  x = Math.max(70, Math.min(wrapRect.width - 70, x));
  tooltip.style.left = x + "px";
  tooltip.style.top = Math.max(4, y) + "px";
}
function hideTooltip(tooltip) { tooltip.hidden = true; }

function ttRow(container, label, value) {
  const row = document.createElement("div");
  row.style.cssText = "display:flex;justify-content:space-between;gap:10px;opacity:.92";
  const l = document.createElement("span");
  l.textContent = label;
  const v = document.createElement("span");
  v.style.cssText = "font-family:'Space Mono',monospace;font-weight:700";
  v.textContent = value;
  row.appendChild(l);
  row.appendChild(v);
  container.appendChild(row);
}
function ttHead(container, color, label) {
  const head = document.createElement("div");
  head.style.cssText = "display:flex;align-items:center;gap:6px;font-weight:700;margin-bottom:3px;font-family:'Space Grotesk',system-ui";
  const dot = document.createElement("span");
  dot.style.cssText = `width:8px;height:8px;border-radius:2px;flex-shrink:0;background:${color}`;
  const l = document.createElement("span");
  l.textContent = label;
  head.appendChild(dot);
  head.appendChild(l);
  container.appendChild(head);
}

// ---------------- Histogram: hub count by 5%-wide tension-balance band ----------------
function renderHistogram(svg, wrap, tooltip, rows148, rows157, S) {
  const VB_W = 640, VB_H = 300;
  const M = { l: 34, r: 12, t: 12, b: 44 };
  const PW = VB_W - M.l - M.r, PH = VB_H - M.t - M.b;

  const allVals = rows148.concat(rows157).map(r => r.ratio);
  const binW = 5;
  const binStart = Math.max(0, Math.floor(Math.min(...allVals) / binW) * binW - binW);
  const binEnd = Math.ceil(Math.max(...allVals) / binW) * binW + binW;
  const bins = [];
  for (let b = binStart; b < binEnd; b += binW) bins.push({ lo: b, hi: b + binW, h148: [], h157: [] });
  function place(rows, key) {
    rows.forEach(r => {
      const idx = Math.min(bins.length - 1, Math.max(0, Math.floor((r.ratio - binStart) / binW)));
      bins[idx][key].push(r);
    });
  }
  place(rows148, "h148");
  place(rows157, "h157");

  let maxCount = 1;
  bins.forEach(b => { maxCount = Math.max(maxCount, b.h148.length, b.h157.length); });
  const yMax = Math.max(2, Math.ceil(maxCount / 2) * 2);
  const slotW = PW / bins.length;
  const barW = Math.min(22, slotW * 0.32);
  const gap = 3;
  const yFor = count => M.t + PH - (count / yMax) * PH;

  const ySteps = yMax <= 4 ? 1 : 2;
  for (let g = 0; g <= yMax; g += ySteps) {
    const gy = yFor(g);
    svg.appendChild(el("line", { x1: M.l, x2: M.l + PW, y1: gy, y2: gy, stroke: g === 0 ? S.bdr : S.bdr, "stroke-opacity": g === 0 ? 0.7 : 0.35 }));
    const lbl = el("text", { x: M.l - 8, y: gy + 3, fill: S.muted, "font-size": 9, "font-family": "Space Mono, monospace", "text-anchor": "end" });
    lbl.textContent = g;
    svg.appendChild(lbl);
  }

  bins.forEach((bin, i) => {
    const cx = M.l + slotW * i + slotW / 2;
    [
      { x: cx - gap / 2 - barW, rows: bin.h148, color: S.h148, label: "148mm Boost" },
      { x: cx + gap / 2, rows: bin.h157, color: S.h157, label: "157mm Super Boost" },
    ].forEach(group => {
      const count = group.rows.length;
      if (count === 0) return;
      const y = yFor(count);
      const h = M.t + PH - y;
      const rect = el("rect", {
        x: group.x, y, width: barW, height: h, rx: 3, ry: 3, fill: group.color,
        style: "cursor:pointer", tabindex: 0, role: "img",
        "aria-label": `${group.label}: ${count} hub${count > 1 ? "s" : ""} in ${bin.lo}-${bin.hi}% band`,
      });
      svg.appendChild(rect);
      const show = () => {
        showTooltip(wrap, tooltip, rect, tt => {
          ttHead(tt, group.color, group.label);
          ttRow(tt, `${bin.lo}–${bin.hi}% band`, `${count} hub${count > 1 ? "s" : ""}`);
          const list = document.createElement("div");
          list.style.cssText = "margin-top:4px;padding-top:4px;border-top:1px solid rgba(255,255,255,.15)";
          group.rows.forEach(r => {
            const row = document.createElement("div");
            row.style.cssText = "display:flex;justify-content:space-between;gap:10px;opacity:.85;font-size:10px";
            const l = document.createElement("span");
            l.textContent = r.name;
            const v = document.createElement("span");
            v.style.cssText = "font-family:'Space Mono',monospace";
            v.textContent = fmt1(r.ratio) + "%";
            row.appendChild(l);
            row.appendChild(v);
            list.appendChild(row);
          });
          tt.appendChild(list);
        });
      };
      rect.addEventListener("pointerenter", show);
      rect.addEventListener("focus", show);
      rect.addEventListener("pointerleave", () => hideTooltip(tooltip));
      rect.addEventListener("blur", () => hideTooltip(tooltip));
    });
    if (i % Math.max(1, Math.round(bins.length / 10)) === 0 || i === bins.length - 1) {
      const tick = el("text", { x: cx, y: M.t + PH + 15, fill: S.muted, "font-size": 9, "font-family": "Space Mono, monospace", "text-anchor": "middle" });
      tick.textContent = bin.lo;
      svg.appendChild(tick);
    }
  });
  const lastTick = el("text", { x: M.l + PW, y: M.t + PH + 15, fill: S.muted, "font-size": 9, "font-family": "Space Mono, monospace", "text-anchor": "middle" });
  lastTick.textContent = binEnd;
  svg.appendChild(lastTick);
  const xTitle = el("text", { x: M.l + PW / 2, y: VB_H - 8, fill: S.muted, "font-size": 10, "font-family": "Space Grotesk, system-ui", "font-weight": 600, "text-anchor": "middle" });
  xTitle.textContent = "NDS / DS tension balance (%)";
  svg.appendChild(xTitle);
}

// ---------------- Dot / beeswarm view: one point per hub ----------------
function renderDots(svg, wrap, tooltip, rows148, rows157, S) {
  const VB_W = 640, VB_H = 300;
  const DM = { l: 128, r: 12, t: 12, b: 44 };
  const DPW = VB_W - DM.l - DM.r, PH = VB_H - DM.t - DM.b;

  const allVals = rows148.concat(rows157).map(r => r.ratio);
  const xMin = Math.max(0, Math.floor(Math.min(...allVals) / 10) * 10 - 5);
  const xMax = Math.ceil(Math.max(...allVals) / 10) * 10 + 5;
  const xFor = v => DM.l + ((v - xMin) / (xMax - xMin)) * DPW;

  const lane148Y = DM.t + PH * 0.32;
  const lane157Y = DM.t + PH * 0.72;

  for (let gv = Math.ceil(xMin / 10) * 10; gv <= xMax; gv += 10) {
    const gx = xFor(gv);
    svg.appendChild(el("line", { x1: gx, x2: gx, y1: DM.t, y2: DM.t + PH, stroke: S.bdr, "stroke-opacity": 0.35 }));
    const lbl = el("text", { x: gx, y: DM.t + PH + 15, fill: S.muted, "font-size": 9, "font-family": "Space Mono, monospace", "text-anchor": "middle" });
    lbl.textContent = gv + "%";
    svg.appendChild(lbl);
  }
  svg.appendChild(el("line", { x1: DM.l, x2: DM.l + DPW, y1: DM.t + PH, y2: DM.t + PH, stroke: S.bdr }));

  const laneLabel148 = el("text", { x: 0, y: lane148Y - 14, fill: S.txt, "font-size": 10.5, "font-weight": 600, "font-family": "Space Grotesk, system-ui" });
  laneLabel148.textContent = "148mm Boost";
  svg.appendChild(laneLabel148);
  const laneLabel157 = el("text", { x: 0, y: lane157Y - 14, fill: S.txt, "font-size": 10.5, "font-weight": 600, "font-family": "Space Grotesk, system-ui" });
  laneLabel157.textContent = "157mm Super Boost";
  svg.appendChild(laneLabel157);

  function stack(rows, laneY, color) {
    const sorted = rows.map(r => ({ ...r, x: xFor(r.ratio) })).sort((a, b) => a.x - b.x);
    const lastXPerRow = [];
    const minSep = 14;
    sorted.forEach(pt => {
      let row = 0;
      while (lastXPerRow[row] !== undefined && pt.x - lastXPerRow[row] < minSep) row++;
      lastXPerRow[row] = pt.x;
      pt.row = row;
    });
    const maxRow = lastXPerRow.length - 1;
    sorted.forEach(pt => {
      const cy = laneY + (pt.row - maxRow / 2) * 12;
      const g = el("g", { style: "cursor:pointer", tabindex: 0, role: "img", "aria-label": `${pt.name}: ${fmt1(pt.ratio)}%` });
      g.appendChild(el("circle", { cx: pt.x, cy, r: 12, fill: "transparent" }));
      g.appendChild(el("circle", { cx: pt.x, cy, r: 7, fill: "none", stroke: S.surf, "stroke-width": 2 }));
      g.appendChild(el("circle", { cx: pt.x, cy, r: 5.5, fill: color }));
      const show = () => {
        showTooltip(wrap, tooltip, g, tt => {
          ttHead(tt, color, pt.name);
          ttRow(tt, "NDS/DS ratio", fmt1(pt.ratio) + "%");
        });
      };
      g.addEventListener("pointerenter", show);
      g.addEventListener("focus", show);
      g.addEventListener("pointerleave", () => hideTooltip(tooltip));
      g.addEventListener("blur", () => hideTooltip(tooltip));
      svg.appendChild(g);
    });
  }
  stack(rows148, lane148Y, S.h148);
  stack(rows157, lane157Y, S.h157);

  const xTitle = el("text", { x: DM.l + DPW / 2, y: VB_H - 8, fill: S.muted, "font-size": 10, "font-family": "Space Grotesk, system-ui", "font-weight": 600, "text-anchor": "middle" });
  xTitle.textContent = "NDS / DS tension balance (%) — each point is one hub";
  svg.appendChild(xTitle);
}

function statTile(S, color, label, vals) {
  return (0, _.jsxs)("div", { style: { flex: 1, minWidth: 150, background: S.surf, border: `1px solid ${S.bdr}`, borderRadius: 8, padding: "10px 12px" }, children: [
    (0, _.jsxs)("div", { style: { display: "flex", alignItems: "center", gap: 6, fontSize: 10, color: S.muted, fontWeight: 600, marginBottom: 6 }, children: [
      (0, _.jsx)("span", { style: { width: 8, height: 8, borderRadius: "50%", background: color, flexShrink: 0 } }),
      `${label} · n=${vals.length}`,
    ] }),
    (0, _.jsxs)("div", { style: { fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 22, color }, children: [fmt1(median(vals)), "%"] }),
    (0, _.jsxs)("div", { style: { fontSize: 9.5, color: S.muted, marginTop: 4 }, children: [
      "median · range ", fmt1(Math.min(...vals)), "–", fmt1(Math.max(...vals)), "%",
    ] }),
  ] });
}
function legendItem(color, label) {
  return (0, _.jsxs)("div", { style: { display: "flex", alignItems: "center", gap: 6, fontSize: 10.5, color: color, fontWeight: 600 }, children: [
    (0, _.jsx)("span", { style: { width: 10, height: 10, borderRadius: 3, background: color } }),
    label,
  ] });
}
function viewButton(S, active, onClick, label) {
  return (0, _.jsx)("button", {
    type: "button", onClick,
    style: {
      fontFamily: "Space Grotesk, system-ui", fontSize: 10.5, fontWeight: 600, padding: "5px 11px",
      borderRadius: 6, border: "none", cursor: "pointer",
      background: active ? S.surf : "transparent", color: active ? S.txt : S.muted,
    },
    children: label,
  });
}
function tooltipStyle(S) {
  return {
    position: "absolute", pointerEvents: "none", zIndex: 5,
    background: S.surfl, color: S.txt, border: `1px solid ${S.bdr}`,
    borderRadius: 7, padding: "7px 10px", fontSize: 10.5, lineHeight: 1.5,
    maxWidth: 240, boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
    transform: "translate(-50%, -100%)", marginTop: -10,
  };
}
function tdStyle(S) {
  return { padding: "6px 10px", borderBottom: `1px solid ${S.bdr}`, whiteSpace: "nowrap", color: S.txt };
}
function sortIndicator(sort, key) {
  if (sort.key !== key) return "";
  return sort.dir === "asc" ? " ↑" : " ↓";
}
function sortableHeader(S, label, key, sort, onSort, align) {
  return (0, _.jsx)("th", {
    onClick: () => onSort(key),
    style: {
      padding: "7px 10px", textAlign: align, cursor: "pointer", userSelect: "none",
      color: S.muted, fontSize: 9.5, fontWeight: 600, letterSpacing: "0.04em",
      borderBottom: `1px solid ${S.bdr}`, whiteSpace: "nowrap",
    },
    children: label + sortIndicator(sort, key),
  });
}

/**
 * TENSION BALANCE tab: NDS/DS tension-balance ratio for every hub in the
 * catalogue, 148mm Boost vs 157mm Super Boost, at the app's current
 * global settings (spokes / rim / tension / rim offset) -- a grouped
 * histogram, an individual-hubs dot view, and a full sortable table.
 */
function TensionBalanceTab({ spokes, erd, tension, offset, S }) {
  const rows148 = se.useMemo(
    () => HUBS_148.map(h => ({ id: h.id, name: h.name, std: "148", flangeWidth: h.nds + h.ds, ratio: ratioFor(h, erd, spokes, tension, offset) })),
    [erd, spokes, tension, offset]
  );
  const rows157 = se.useMemo(
    () => HUBS_157.map(h => ({ id: h.id, name: h.name, std: "157", flangeWidth: h.nds + h.ds, ratio: ratioFor(h, erd, spokes, tension, offset) })),
    [erd, spokes, tension, offset]
  );
  const allRows = se.useMemo(() => rows148.concat(rows157), [rows148, rows157]);
  const vals148 = rows148.map(r => r.ratio);
  const vals157 = rows157.map(r => r.ratio);

  const [view, setView] = se.useState("hist");
  const [sort, setSort] = se.useState({ key: "ratio", dir: "desc" });
  const svgRef = se.useRef(null);
  const wrapRef = se.useRef(null);
  const tooltipRef = se.useRef(null);

  se.useEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    tooltipRef.current.hidden = true;
    if (view === "hist") renderHistogram(svg, wrapRef.current, tooltipRef.current, rows148, rows157, S);
    else renderDots(svg, wrapRef.current, tooltipRef.current, rows148, rows157, S);
  }, [view, rows148, rows157, S]);

  const sortedRows = se.useMemo(() => {
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...allRows].sort((a, b) => {
      if (sort.key === "name") return a.name.localeCompare(b.name) * dir;
      if (sort.key === "std") return (a.std === b.std ? 0 : a.std < b.std ? -1 : 1) * dir;
      if (sort.key === "flangeWidth") return (a.flangeWidth - b.flangeWidth) * dir;
      return (a.ratio - b.ratio) * dir;
    });
  }, [allRows, sort]);
  const toggleSort = key => setSort(s => ({ key, dir: s.key === key && s.dir === "desc" ? "asc" : "desc" }));

  return (0, _.jsxs)(_.Fragment, { children: [
    (0, _.jsxs)("p", { style: { fontSize: 10.5, color: S.muted, margin: "0 0 12px", lineHeight: 1.6 }, children: [
      "NDS/DS spoke-tension ratio for every hub in the catalogue, recomputed live at the Spokes / Rim / Tension / Rim offset settings above — the same Mode Matrix call the COMPARE tab uses for its two selected hubs. Higher is more balanced; 100% would be a perfectly undished wheel.",
    ] }),
    (0, _.jsxs)("div", { style: { display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }, children: [
      statTile(S, S.h148, "148mm Boost", vals148),
      statTile(S, S.h157, "157mm Super Boost", vals157),
    ] }),
    (0, _.jsxs)("div", { style: { background: S.surf, border: `1px solid ${S.bdr}`, borderRadius: 10, padding: "14px 14px 10px", marginBottom: 14 }, children: [
      (0, _.jsxs)("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, marginBottom: 8 }, children: [
        (0, _.jsxs)("div", { style: { display: "flex", gap: 14 }, children: [legendItem(S.h148, "148mm Boost"), legendItem(S.h157, "157mm Super Boost")] }),
        (0, _.jsxs)("div", { style: { display: "inline-flex", background: S.bg, border: `1px solid ${S.bdr}`, borderRadius: 8, padding: 2 }, children: [
          viewButton(S, view === "hist", () => setView("hist"), "Histogram"),
          viewButton(S, view === "dots", () => setView("dots"), "Individual hubs"),
        ] }),
      ] }),
      (0, _.jsxs)("div", { ref: wrapRef, style: { position: "relative" }, children: [
        (0, _.jsx)("svg", { ref: svgRef, viewBox: "0 0 640 300", style: { width: "100%", height: "auto", display: "block", overflow: "visible" } }),
        (0, _.jsx)("div", { ref: tooltipRef, hidden: true, style: tooltipStyle(S) }),
      ] }),
    ] }),
    (0, _.jsx)(Section, { title: "All hubs", subtitle: `${allRows.length} hubs`, children: (0, _.jsx)("div", { style: { overflowX: "auto", marginTop: 4 }, children: (0, _.jsxs)("table", { style: { width: "100%", borderCollapse: "collapse", fontSize: 11 }, children: [
      (0, _.jsx)("thead", { children: (0, _.jsxs)("tr", { children: [
        sortableHeader(S, "Hub", "name", sort, toggleSort, "left"),
        sortableHeader(S, "Standard", "std", sort, toggleSort, "left"),
        sortableHeader(S, "Total flange width (mm)", "flangeWidth", sort, toggleSort, "right"),
        sortableHeader(S, "NDS/DS ratio", "ratio", sort, toggleSort, "right"),
      ] }) }),
      (0, _.jsx)("tbody", { children: sortedRows.map(r => (0, _.jsxs)("tr", { children: [
        (0, _.jsx)("td", { style: tdStyle(S), children: r.name }),
        (0, _.jsx)("td", { style: tdStyle(S), children: (0, _.jsxs)("div", { style: { display: "flex", alignItems: "center", gap: 6 }, children: [
          (0, _.jsx)("span", { style: { width: 8, height: 8, borderRadius: "50%", flexShrink: 0, background: r.std === "148" ? S.h148 : S.h157 } }),
          r.std === "148" ? "148mm" : "157mm",
        ] }) }),
        (0, _.jsxs)("td", { style: { ...tdStyle(S), textAlign: "right", fontFamily: "Space Mono, monospace" }, children: [fmt1(r.flangeWidth), " mm"] }),
        (0, _.jsxs)("td", { style: { ...tdStyle(S), textAlign: "right", fontFamily: "Space Mono, monospace" }, children: [fmt1(r.ratio), "%"] }),
      ] }, r.id)) }),
    ] }) }) }),
    (0, _.jsx)(Section, { title: "Symmetry drives strength", children: (0, _.jsxs)(_.Fragment, { children: [
      (0, _.jsx)("p", { style: { fontSize: 10.5, color: S.muted, margin: 0, lineHeight: 1.6 }, children: "These numbers come from the full Mode Matrix model (Ford 2018) using each hub's real flange geometry. NDS/DS symmetry and lateral strength move together — a more balanced wheel is a stronger one. The MTB industry routinely overlooks this link; the physics doesn't." }),
      (0, _.jsxs)("blockquote", { style: { margin: "10px 0 2px", padding: "8px 14px", borderLeft: `3px solid ${S.acc}`, background: S.surfl, borderRadius: "0 6px 6px 0" }, children: [
        (0, _.jsx)("span", { style: { fontSize: 12, color: S.txt, fontStyle: "italic", lineHeight: 1.5, fontFamily: "Space Grotesk, system-ui" }, children: '"The holy grail of wheel building has always been evenly tensioned spokes."' }),
        (0, _.jsx)("span", { style: { display: "block", fontSize: 10, color: S.muted, marginTop: 4, fontFamily: "Space Mono, monospace" }, children: "— Bill Shook" }),
      ] }),
    ] }) }),
  ] });
}

export default TensionBalanceTab;
