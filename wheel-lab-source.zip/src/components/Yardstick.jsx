import * as React from "react";
import { theme as j } from "../theme-state.js";

// YARDSTICK (COMPARE). The Lab's strengths are in kgf, which means little
// on its own to a rider. This card restates the two builds' lateral and
// radial strength (both first-spoke-slack loads from wheel-physics-core,
// Matthew Ford's Mode Matrix) as multiples of the Rider+bike slider's
// weight, and says in one sentence how far apart the two directions are.
// It adds no physics: every figure is an engine output divided by a weight.
//
// Deliberately absent: any statement of how big real trail loads are. The
// Lab has no sourced, measured MTB load data, so the card compares the
// wheel to the rider's weight and stops there.

const MONO = "Space Mono, monospace";
const times = (kgf, kg) => (kgf / kg >= 10 ? (kgf / kg).toFixed(0) : kgf / kg >= 1 ? (kgf / kg).toFixed(1) : (kgf / kg).toFixed(2)) + "×";
// Rider presets: rough rider + bike weights, so a reader can see the
// yardstick for someone other than themselves (a youth racer, an e-bike).
// They only move the Rider+bike slider; no strength figure depends on it.
// Estimates, not survey data: rider plus bike, e.g. a ~32 kg youth racer on a
// ~13 kg bike, an ~85 kg rider on a ~25 kg e-bike.
export const RIDER_PRESETS = [["Youth racer", 45], ["Trail", 82], ["DH", 100], ["E-bike", 110]];

const pct = (b, a) => { const p = Math.round((b / a - 1) * 100); return (p >= 0 ? "+" : "−") + Math.abs(p) + "%"; };

/**
 * @param riderKg rider + bike weight (kg), from the Rider+bike slider
 * @param a, b    engine results for the 148x12 and 157x12 builds
 * @param S       active theme (for the two hub colors)
 */
export default function Yardstick({ riderKg, a, b, S, setRiderKg }) {
  const lb = Math.round(riderKg * 2.205);
  const ratio = Math.round(((a.F_rad / a.F_lat) + (b.F_rad / b.F_lat)) / 2);
  const cell = (label, v, color) => (
    <div style={{ flex: 1, minWidth: 0, textAlign: "center" }}>
      <div style={{ fontFamily: MONO, fontWeight: 700, fontSize: 19, color, lineHeight: 1.1 }}>{times(v, riderKg)}</div>
      <div style={{ fontSize: 8.5, color: j.muted, marginTop: 2 }}>{label} · {v >= 100 ? v.toFixed(0) : v.toFixed(1)} kgf</div>
    </div>
  );
  const row = (title, note, va, vb) => (
    <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderTop: `1px solid ${j.bdr}` }}>
      <div style={{ flex: "0 0 34%", minWidth: 0 }}>
        <div style={{ fontSize: 10.5, color: j.txt, fontWeight: 600, fontFamily: "Space Grotesk, system-ui" }}>{title}</div>
        <div style={{ fontSize: 8.5, color: j.muted, lineHeight: 1.35 }}>{note}</div>
      </div>
      {cell("148", va, S.h148)}
      {cell("157", vb, S.h157)}
    </div>
  );
  return (
    <div style={{ background: j.surfl, border: `1px solid ${j.bdr}`, borderLeft: `3px solid ${j.muted}`, borderRadius: 8, padding: "11px 14px", marginBottom: 12 }}>
      <div style={{ fontSize: 11, color: j.txt, fontWeight: 600, fontFamily: "Space Grotesk, system-ui", marginBottom: 3 }}>How big is that? Measured against you</div>
      <p style={{ fontSize: 10.5, color: j.muted, margin: "0 0 8px", lineHeight: 1.6 }}>
        Each strength as a multiple of rider + bike weight ({riderKg} kg · {lb} lb, the Rider+bike slider above). Strength here is the load at which the first spoke goes slack.
      </p>
      {setRiderKg && (
        <div role="group" aria-label="Rider presets" style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 5, margin: "0 0 8px" }}>
          <span style={{ fontSize: 9.5, color: j.txt, marginRight: 2 }}>Try:</span>
          {RIDER_PRESETS.map(([name, kg]) => {
            const on = riderKg === kg;
            return (
              <button key={name} type="button" aria-pressed={on} onClick={() => setRiderKg(kg)}
                style={{ padding: "3px 9px", borderRadius: 999, cursor: "pointer", fontSize: 10, fontFamily: "Space Grotesk, system-ui",
                  background: "transparent", color: j.txt, fontWeight: on ? 700 : 500, border: on ? `1.5px solid ${j.txt}` : `1px solid ${j.bdr}` }}>
                {on ? "\u2713 " : ""}{name} <span style={{ fontFamily: MONO, fontSize: 9.5 }}>{kg} kg</span>
              </button>
            );
          })}
          <span style={{ fontSize: 9.5, color: j.txt, opacity: 0.85 }}>rough rider + bike weights</span>
        </div>
      )}
      {row("Sideways", "lateral strength", a.F_lat, b.F_lat)}
      {row("Straight down", "radial strength", a.F_rad, b.F_rad)}
      <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6, borderTop: `1px solid ${j.bdr}`, paddingTop: 8 }}>
        The same wheel takes about <strong style={{ color: j.txt }}>{ratio}× more load straight down than sideways</strong> before a spoke goes slack. Hub choice moves the sideways figure by {pct(b.F_lat, a.F_lat)} and the straight-down figure by {pct(b.F_rad, a.F_rad)}, which is why this tool compares hubs on lateral strength.
      </p>
    </div>
  );
}
