import * as _ from "react/jsx-runtime";

/** Inline percent-sign icon (lucide "percent"), used everywhere a computed
 * value is displayed with a % suffix instead of the literal character.
 * Sized in em so it scales with whatever text it sits inline with. */
function PercentIcon() {
  return (0, _.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg", width: "0.85em", height: "0.85em",
    viewBox: "0 0 24 24", fill: "none", stroke: "currentColor",
    strokeWidth: 2.5, strokeLinecap: "round", strokeLinejoin: "round",
    style: { display: "inline", verticalAlign: "-0.05em" },
    children: [
      (0, _.jsx)("line", { x1: 19, x2: 5, y1: 5, y2: 19 }),
      (0, _.jsx)("circle", { cx: 6.5, cy: 6.5, r: 2.5 }),
      (0, _.jsx)("circle", { cx: 17.5, cy: 17.5, r: 2.5 }),
    ],
  });
}

export default PercentIcon;
