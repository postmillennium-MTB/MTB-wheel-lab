import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";
import { DIAGRAM_LAYOUT as DL, spokePointAtY } from "./WheelDiagram.jsx";

// Must match WheelDiagram.jsx's viewBox exactly — this overlay is drawn in
// the same coordinate space, stacked on top of that SVG. Both numbers come
// from DIAGRAM_LAYOUT so there is only one copy of them.
const VB_W = DL.width, VB_H = DL.height;

// Each step is one callout: where it points, where its label box sits, and
// what it says.
//
//   target   (anchors) => [x, y]. Anchors carry the LIVE flange positions,
//            so a callout that names a part which travels with its flange
//            (the freehub stub, the rotor mount, either spoke) keeps
//            pointing at that part across the whole slider range. An
//            earlier version used fixed points and drifted badly at high
//            dish — by 15mm of offset the "disc brake rotor mount" arrow
//            was sitting on the hub barrel instead. Don't pin these back
//            to constants.
//   labelX/Y/W  label box position and width, in viewBox units.
//   elbowY   optional: the height the leader line turns at. Without it the
//            elbow lands halfway between target and label, which for the
//            two top-anchored steps runs the line straight through the big
//            LATERAL STRENGTH readout at y≈70–106. Set it below the
//            readout for those.
//
// Layout constraints for label boxes, learned the hard way:
//   - a box at labelY 10 must not span x 106–174, or it covers the rim
//     cross-section (step 6 used to sit right on top of it);
//   - keep the text short enough that the box stays clear of the strength
//     readout at y≈70 once it wraps — it wraps narrower on a phone;
//   - the readout's big number occupies roughly y 76–100 across the middle
//     of the diagram, so anchor spoke callouts above it (y≈52–58), not
//     through it.
export const ANNOTATION_STEPS = [
  { target: a => spokePointAtY(a.dsX, "DS", 52),
    labelX: 186, labelY: 10, labelW: 90,
    text: "Drive side holds the tension you set — it's the non-drive side that falls away" },
  { target: () => [DL.centerX, DL.hubY],
    labelX: 186, labelY: 10, labelW: 90, elbowY: 112,
    text: "Total hub flange width stays fixed — 60mm" },
  { target: a => [a.dsX + DL.freehubW / 2, DL.hubY],
    labelX: 190, labelY: 145, labelW: 86,
    text: "Making room for the cassette and drivetrain means asymmetry" },
  { target: a => [a.ndsX - DL.rotorW / 2, DL.hubY],
    labelX: 4, labelY: 145, labelW: 86,
    text: "Non-drive side: disc brake rotor mount" },
  { target: a => spokePointAtY(a.ndsX, "NDS", 58),
    labelX: 4, labelY: 45, labelW: 88,
    text: "The bigger the wheel, the more compromised the spoke bracing angle" },
  { target: a => [a.ndsX, DL.hubY],
    labelX: 4, labelY: 10, labelW: 92, elbowY: 112,
    text: "The hub sets the geometry — how evenly the two sides can ever be tensioned" },
];

export const ANNOTATION_STEP_MS = 3000;

/**
 * Draws one animated callout (leader line + label box) over the
 * WheelDiagram SVG, plus the countdown bar for the active step.
 * @param step      index into ANNOTATION_STEPS
 * @param progress  0-100, how much of this step's 3s window has elapsed
 * @param color     accent color to draw with
 * @param anchors   { dsX, ndsX } live flange x positions in viewBox units
 */
function AnnotationOverlay({step:n,progress:p,color:r,anchors:an}){
  let s=ANNOTATION_STEPS[n],[tx,ty]=s.target(an),
      boxCx=s.labelX+s.labelW/2,
      elbowY=s.elbowY!=null?s.elbowY:(ty+s.labelY+10)/2;
  return(0,_.jsxs)(_.Fragment,{children:[
    (0,_.jsx)("svg",{viewBox:`0 0 ${VB_W} ${VB_H}`,style:{position:"absolute",inset:0,width:"100%",height:"100%",pointerEvents:"none"},children:(0,_.jsxs)("g",{key:n,children:[
      (0,_.jsx)("circle",{cx:tx,cy:ty,r:4.5,fill:"none",stroke:r,strokeWidth:1.5,children:(0,_.jsx)("animate",{attributeName:"r",values:"3;7;3",dur:"1.4s",repeatCount:"indefinite"})}),
      (0,_.jsx)("circle",{cx:tx,cy:ty,r:2.5,fill:r}),
      (0,_.jsx)("polyline",{points:`${tx},${ty} ${tx},${elbowY} ${boxCx},${elbowY} ${boxCx},${s.labelY+10}`,fill:"none",stroke:r,strokeWidth:1.5,strokeLinecap:"round",strokeLinejoin:"round",pathLength:"1",style:{strokeDasharray:1,strokeDashoffset:1,animation:"pmrAnnDraw 0.5s ease-out forwards"}}),
    ]})}),
    (0,_.jsxs)("div",{key:"lbl"+n,style:{position:"absolute",left:`${s.labelX/VB_W*100}%`,top:`${s.labelY/VB_H*100}%`,width:`${s.labelW/VB_W*100}%`,background:j.surf,border:`1px solid ${r}`,borderRadius:6,padding:"6px 8px",fontSize:9,lineHeight:1.4,color:j.txt,fontFamily:"Space Grotesk, system-ui",boxShadow:`0 2px 10px ${j.bg}88`,animation:"pmrAnnFade 0.25s ease-out"},children:[
      s.text,
      (0,_.jsx)("div",{style:{marginTop:5,height:2,background:j.bdr,borderRadius:2,overflow:"hidden"},children:(0,_.jsx)("div",{style:{height:"100%",width:`${100-p}%`,background:r,transition:"width 60ms linear"}})}),
    ]}),
  ]});
}

export default AnnotationOverlay;
