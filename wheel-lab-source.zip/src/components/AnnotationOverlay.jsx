import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

// Must match WheelDiagram.jsx's viewBox exactly — this overlay is drawn in
// the same coordinate space, stacked on top of that SVG.
const VB_W = 280, VB_H = 224;

// Each step's target point is a nominal spot on the hub cross-section
// (not recomputed from the live flange offset — it's a guided tour of
// what's THERE, not a live pointer, so an approximate anchor reads fine
// across the whole drag range). labelX/Y/w position the callout box;
// side controls which edge the connecting line's elbow bends toward.
export const ANNOTATION_STEPS = [
  { target: [184, 84], labelX: 186, labelY: 10, labelW: 90,
    text: "DS spoke carries higher tension as asymmetry increases" },
  { target: [140, 128], labelX: 186, labelY: 10, labelW: 90,
    text: "Total hub flange width stays fixed — 60mm" },
  { target: [200, 128], labelX: 190, labelY: 145, labelW: 86,
    text: "Making room for the cassette and drivetrain means asymmetry" },
  { target: [75, 128], labelX: 4, labelY: 145, labelW: 86,
    text: "Non-drive side: disc brake rotor mount" },
  { target: [108, 58], labelX: 4, labelY: 45, labelW: 88,
    text: "The bigger the wheel, the more compromised the spoke bracing angle" },
  { target: [140, 120], labelX: 95, labelY: 10, labelW: 90,
    text: "The hub determines the wheel geometry: how symmetrical the drive side vs. non-drive side spoke tension is" },
];

export const ANNOTATION_STEP_MS = 3000;

/**
 * Draws one animated callout (leader line + label box) over the
 * WheelDiagram SVG, plus the countdown bar for the active step.
 * @param step      index into ANNOTATION_STEPS
 * @param progress  0-100, how much of this step's 3s window has elapsed
 * @param color     accent color to draw with
 */
function AnnotationOverlay({step:n,progress:p,color:r}){
  let s=ANNOTATION_STEPS[n],[tx,ty]=s.target,
      boxCx=s.labelX+s.labelW/2,
      elbowY=(ty+s.labelY+10)/2;
  return(0,_.jsxs)(_.Fragment,{children:[
    (0,_.jsx)("svg",{viewBox:`0 0 ${VB_W} ${VB_H}`,style:{position:"absolute",inset:0,width:"100%",height:"100%",pointerEvents:"none"},children:(0,_.jsxs)("g",{key:n,children:[
      (0,_.jsx)("circle",{cx:tx,cy:ty,r:4.5,fill:"none",stroke:r,strokeWidth:1.5,children:(0,_.jsx)("animate",{attributeName:"r",values:"3;7;3",dur:"1.4s",repeatCount:"indefinite"})}),
      (0,_.jsx)("circle",{cx:tx,cy:ty,r:2.5,fill:r}),
      (0,_.jsx)("polyline",{points:`${tx},${ty} ${tx},${elbowY} ${boxCx},${elbowY} ${boxCx},${s.labelY+10}`,fill:"none",stroke:r,strokeWidth:1.5,strokeLinecap:"round",strokeLinejoin:"round",pathLength:"1",style:{strokeDasharray:1,strokeDashoffset:1,animation:"pmrAnnDraw 0.5s ease-out forwards"}}),
    ]})}),
    (0,_.jsxs)("div",{key:"lbl"+n,style:{position:"absolute",left:`${s.labelX/VB_W*100}%`,top:`${s.labelY/VB_H*100}%`,width:`${s.labelW/VB_W*100}%`,background:j.surf,border:`1px solid ${r}`,borderRadius:6,padding:"6px 8px",fontSize:9,lineHeight:1.4,color:j.txt,fontFamily:"Space Grotesk, system-ui",boxShadow:`0 2px 10px ${j.bg}88`,animation:"pmrAnnFade 0.25s ease-out"},children:[
      s.text,
      (0,_.jsx)("div",{style:{marginTop:5,height:2,background:j.bdr,borderRadius:2,overflow:"hidden"},children:(0,_.jsx)("div",{style:{height:"100%",width:`${100-p}%`,background:r,transition:"width 60ms linear"}})}),
    ]}),
  ]});
}

export default AnnotationOverlay;
