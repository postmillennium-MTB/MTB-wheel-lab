import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

/** Custom Recharts tooltip: shows the load value and which build(s) it pushes past first-spoke-slack, if any. */
function RideTooltipContent({active:e,payload:t,cap148:r,cap157:n,S:i}){if(!e||!(t!=null&&t.length)||t[0].value==null)return null;let o=t[0].value,h=Math.max(r,n),w=Math.min(r,n),x=r<=n?"148mm":"157mm",a=o>h?{text:`\u26A0 Spokes slack on both builds (>${h} kgf)`,c:j.txt}:o>w?{text:`\u26A0 Spokes slack on ${x} (>${w} kgf)`,c:j.txt}:{text:"\u2713 Every spoke stays tight",c:j.txt};return(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:6,padding:"8px 12px"},children:[(0,_.jsxs)("div",{style:{fontSize:16,fontWeight:700,color:j.txt,fontFamily:"Space Mono, monospace"},children:[o," ",(0,_.jsx)("span",{style:{fontSize:10,color:j.muted},children:"kgf"})]}),(0,_.jsx)("div",{style:{fontSize:10,color:a.c,marginTop:3},children:a.text})]})}

export default RideTooltipContent;
