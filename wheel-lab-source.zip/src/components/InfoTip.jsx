import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";

/**
 * Inline text with an explanatory popover.
 *
 * Desktop: shows on mouse hover and stays open while the pointer is over the
 * label or the popover itself, so the text can be read and selected.
 * Touch: tap the label to open, tap it again (or anywhere else) to close.
 * Keyboard: the label is a real <button>; Tab focus opens it, Enter/Space
 * toggles it, Escape closes it.
 *
 * The popover is linked with aria-describedby (screen readers announce it on
 * focus) and aria-expanded/aria-controls (state of the tap toggle).
 */
function InfoTip({label, tip, color, id}) {
  const [pinned, setPinned] = se.useState(false);
  const [hover, setHover] = se.useState(false);
  const [focusOpen, setFocusOpen] = se.useState(false);
  const wrapRef = se.useRef(null);
  const pointerDownRef = se.useRef(false);
  const open = pinned || hover || focusOpen;
  const tipId = id + "-tip";

  const closeAll = () => { setPinned(false); setHover(false); setFocusOpen(false); };

  se.useEffect(() => {
    if (!open) return;
    const onKey = e => { if (e.key === "Escape") closeAll(); };
    const onDown = e => { if (wrapRef.current && !wrapRef.current.contains(e.target)) closeAll(); };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onDown);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onDown);
    };
  }, [open]);

  return _.jsxs("span", {
    ref: wrapRef,
    style: {position: "relative", display: "inline-block"},
    onPointerEnter: e => { if (e.pointerType === "mouse") setHover(true); },
    onPointerLeave: e => { if (e.pointerType === "mouse") setHover(false); },
    children: [
      _.jsxs("button", {
        type: "button",
        "aria-expanded": open,
        "aria-controls": tipId,
        "aria-describedby": tipId,
        onPointerDown: () => { pointerDownRef.current = true; },
        // Focus from Tab opens it; focus that comes from a click or tap is
        // left to onClick so a tap toggles cleanly instead of open-then-close.
        onFocus: () => { if (!pointerDownRef.current) setFocusOpen(true); pointerDownRef.current = false; },
        onBlur: () => setFocusOpen(false),
        // Click / tap / Enter / Space: open if closed, close if open.
        onClick: () => { if (open) closeAll(); else setPinned(true); },
        style: {
          background: "none", border: "none", padding: "4px 0", margin: "-4px 0", cursor: "help",
          font: "inherit", fontSize: 10.5, fontWeight: 600, color: color,
          fontFamily: "Space Grotesk, system-ui", textAlign: "left", lineHeight: 1.55,
          textDecoration: "underline dotted", textUnderlineOffset: 3,
        },
        children: [
          label,
          _.jsx("span", {
            "aria-hidden": "true",
            style: {
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              width: 13, height: 13, marginLeft: 6, borderRadius: "50%",
              border: `1.3px solid ${color}`, fontSize: 9, fontWeight: 700,
              fontFamily: "Georgia, serif", fontStyle: "italic", lineHeight: 1,
              verticalAlign: "-2px", textDecoration: "none",
            },
            children: "i",
          }),
        ],
      }),
      _.jsx("span", {
        id: tipId,
        role: "tooltip",
        hidden: !open,
        style: {
          position: "absolute", top: "calc(100% + 6px)", left: 0, zIndex: 60,
          width: "max-content", maxWidth: "min(380px, calc(100vw - 56px))",
          background: j.surf, color: j.txt, border: `1px solid ${j.bdr}`,
          borderRadius: 8, padding: "9px 11px", fontSize: 11.5, lineHeight: 1.55,
          fontWeight: 400, fontFamily: "system-ui, sans-serif",
          boxShadow: "0 6px 20px rgba(0,0,0,0.28)",
        },
        children: tip,
      }),
    ],
  });
}

export default InfoTip;
