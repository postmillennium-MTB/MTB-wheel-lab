import * as React from "react";
import { theme as j } from "../theme-state.js";
import WheelShareText from "wheel-physics-core/js/share-text.js";
import WheelBuildLink from "wheel-physics-core/js/build-link.js";

// COPY RESULT: an icon-only header button beside SHARE LINK. It copies the
// build on screen as a few plain-text lines for places that show no link
// preview, such as a Pinkbike comment: lateral strength and lateral
// stiffness on separate labelled lines, the build, a credit to Ford's Mode
// Matrix method, and the link. The wording is wheel-physics-core's
// js/share-text.js, shared with the 148 vs 157 widget, so a pasted result
// reads the same from either tool. No new numbers: it prints the same engine
// outputs the COMPARE tab shows. Past buckling there is no strength figure,
// and the text says so instead of giving a percentage.
//
// Icons are Lucide "clipboard-copy" and "check" (https://lucide.dev), pasted
// inline with their path data unchanged. The button carries the accessible
// name; the SVG is decorative.
const SVG = { xmlns: "http://www.w3.org/2000/svg", width: 14, height: 14, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", focusable: "false" };
const NAME = "Copy result as text, for a comment or post";

export function resultText({ m148, m157, hub148, hub157, wheel, tension, spokes, offset, pastBuckling }) {
  const side = (m, hub) => ({ label: hub.name, F_lat: pastBuckling(m) ? NaN : m.F_lat, K_lat: m.K_lat, wheel, tension });
  return WheelShareText.resultText({
    a: side(m148, hub148), b: side(m157, hub157), spokes: String(spokes),
    note: offset ? `rim offset ${offset} mm` : null,
    // The PMR-hosted page, whatever copy of the Lab this is, with the build
    // in the hash (App.jsx keeps the hash in step with the settings).
    url: WheelBuildLink.PAGES.lab + window.location.hash,
  });
}

export default function CopyResultButton(props) {
  const [done, setDone] = React.useState(false);
  const timer = React.useRef(null);
  React.useEffect(() => () => clearTimeout(timer.current), []);
  const confirm = () => { setDone(true); clearTimeout(timer.current); timer.current = setTimeout(() => setDone(false), 1800); };
  const copy = async () => {
    const text = resultText(props);
    try { await navigator.clipboard.writeText(text); confirm(); return; } catch (err) {}
    // No clipboard access (old browser, blocked permission): copy through a
    // temporary field instead.
    try {
      const ta = document.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      if (ok) confirm();
    } catch (err2) {}
  };
  return (
    <button onClick={copy} aria-label={done ? "Result copied" : NAME} title={done ? "Result copied" : NAME}
      style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "5px 9px", background: j.surfl, border: `1px solid ${j.bdr}`, borderRadius: 6, cursor: "pointer", color: done ? j.txt : j.muted, flexShrink: 0 }}>
      {done ? (
        <svg {...SVG} className="lucide lucide-check"><path d="M20 6 9 17l-5-5" /></svg>
      ) : (
        <svg {...SVG} className="lucide lucide-clipboard-copy"><rect width="8" height="4" x="8" y="2" rx="1" ry="1" /><path d="M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" /><path d="M16 4h2a2 2 0 0 1 2 2v4" /><path d="M21 14H11" /><path d="m15 10-4 4 4 4" /></svg>
      )}
      <span role="status" style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>{done ? "Result copied" : ""}</span>
    </button>
  );
}
