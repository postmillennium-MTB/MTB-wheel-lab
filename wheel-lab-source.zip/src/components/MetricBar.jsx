import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";
import Pct from "./PercentIcon.jsx";

/**
 * Side-by-side bar pair comparing one metric between the two selected builds.
 * v148/v157 are real values in `unit`; bars are scaled to the larger of the
 * two, and the badge is the 157 build's difference from the 148 build.
 */
function MetricBar({label:e,note:t,v148:r,v157:n,unit:y,digits:g=1,S:i}){let o=Math.round((n-r)/r*100),a=e==="Lateral Strength",l=a?10:7,u=a?11:9,m=Math.max(r,n)||1,f=v=>v.toFixed(g);return(0,_.jsxs)("div",{style:{marginBottom:13},children:[(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",gap:8,marginBottom:5},children:[(0,_.jsxs)("div",{children:[(0,_.jsxs)("span",{style:{fontSize:a?12:11,color:j.txt,fontWeight:a?600:400},children:[e," "]}),(0,_.jsxs)("span",{style:{fontSize:9,color:j.muted},children:["(",t,")"]})]}),(0,_.jsxs)("span",{style:{fontSize:10,color:o<0?j.warn:j.acc,fontFamily:"Space Mono, monospace",fontWeight:a?700:400,whiteSpace:"nowrap"},children:[o>0?"+":"",o,(0,_.jsx)(Pct,{})]})]}),(0,_.jsxs)("div",{style:{display:"flex",gap:6,alignItems:"center"},children:[(0,_.jsxs)("div",{style:{flex:1},children:[(0,_.jsx)("div",{style:{height:l,background:j.bdr,borderRadius:3,overflow:"hidden"},children:(0,_.jsx)("div",{style:{width:`${r/m*100}%`,height:"100%",background:i.h148}})}),(0,_.jsxs)("div",{style:{textAlign:"center",marginTop:3,fontSize:u,color:i.h148,fontFamily:"Space Mono, monospace",fontWeight:a?700:400},children:[f(r)," ",(0,_.jsx)("span",{style:{fontSize:8,color:j.muted},children:y})]})]}),(0,_.jsx)("span",{style:{width:14,textAlign:"center",fontSize:9,color:j.muted},children:"vs"}),(0,_.jsxs)("div",{style:{flex:1},children:[(0,_.jsx)("div",{style:{height:l,background:j.bdr,borderRadius:3,overflow:"hidden"},children:(0,_.jsx)("div",{style:{width:`${n/m*100}%`,height:"100%",background:i.h157}})}),(0,_.jsxs)("div",{style:{textAlign:"center",marginTop:3,fontSize:u,color:i.h157,fontFamily:"Space Mono, monospace",fontWeight:a?700:400},children:[f(n)," ",(0,_.jsx)("span",{style:{fontSize:8,color:j.muted},children:y})]})]})]})]})}

export default MetricBar;
