import * as React from "react";
import { LineChart, XAxis, YAxis, CartesianGrid, Tooltip, Line, ReferenceArea, ReferenceDot, ResponsiveContainer } from "recharts";
import { theme as j } from "../theme-state.js";
import { spokeModel, spokeTensions, firstSlackCombined, gavinCycles, GAVIN_SN } from "../physics.js";
import Section from "./Section.jsx";
import { Study, Lead, Foot, Readout, MONO } from "./InsightsTab.jsx";

// S-N FATIGUE CURVE (DEEP DIVE). Replaces an earlier illustrative sketch
// (N = 1500·(F_lat/load)^5.5, no source) with a measured spoke fatigue fit:
//
//   Gavin, H. P. (1996), "Bicycle-Wheel Spoke Patterns and Spoke Fatigue",
//   ASCE J. Eng. Mech. 122(8), Eq. 10: log S = a·log N + b, S = spoke
//   stress range [MPa], a = −0.30, b̄ = 4.12, V_b = 0.017; 76 stainless
//   spokes tested at Stanford for Wheelsmith (1984–85), 174 MPa and up.
//
// Each hub's point is the biggest spoke stress swing under one sideways hit
// of the weaker build's first-slack load, from wheel-physics-core's
// per-spoke output (Matthew Ford's discrete-spoke Mode Matrix), divided by
// the 2.0 mm spoke's area.

const AREA_MM2 = Math.PI;          // 2.0 mm plain-gauge spoke, π·(2.0/2)² mm²
const KGF_TO_MPA = 9.81 / AREA_MM2;
const fmtN = (n) => (n >= 1e9 ? `${(n / 1e9).toFixed(1)} billion` : n >= 1e6 ? `${(n / 1e6).toFixed(1)} million` : n >= 1e3 ? `${Math.round(n / 1e3).toLocaleString("en-US")},000` : `${Math.round(n)}`);
const tickN = (n) => (n >= 1e9 ? `${n / 1e9}B` : n >= 1e6 ? `${n / 1e6}M` : n >= 1e3 ? `${n / 1e3}k` : `${n}`);

const EQ = {
  lines: [
    <>log S = a · log N + b,   a = −0.30,   b̄ = 4.12</>,
    <>N = 10<sup>(log S − b) / a</sup> ≈ 5.4 × 10<sup>13</sup> · S<sup>−3.33</sup></>,
    <>S = ΔT<sub>max</sub> / A,   A = π · (2.0 mm)² / 4 = 3.14 mm²</>,
    <>mixed hits (Miner’s rule): D = Σ n<sub>i</sub> / N(S<sub>i</sub>), failure near D = 1</>,
  ],
  where: <>S the stress range in one spoke for one hit, in MPa; N the cycles to failure at that range; a, b Gavin’s least-squares fit to 76 stainless spokes; b scatters with coefficient of variation V<sub>b</sub> = 0.017, which makes N vary by about ±74% at any given S (the dashed band is ±1 standard deviation). ΔT<sub>max</sub> the biggest change in any spoke’s tension under the hit, from Ford’s discrete-spoke Mode Matrix.</>,
  note: <>Gavin (1996), Eq. 10 and Fig. 13. His tests ran from 174 MPa upward; below that the line is extrapolated (dashed), and it assumes no endurance limit, which he calls conservative. Miner’s linear damage rule is the one he uses for road loading.</>,
};

export default function FatigueSN({ hubs, erd, spokes, offset, tension }) {
  const colors = [j.h148, j.h157], names = hubs.map((h) => h.name);
  const data = React.useMemo(() => {
    const models = hubs.map((h) => spokeModel(h, erd, spokes, offset, tension));
    if (models.some((m) => m.pastBuckling)) return null;
    const firsts = models.map((m) => firstSlackCombined(m.res, { lat: m.toNDS, rad: 0 }));
    const P = Math.min(...firsts.map((f) => f.scale));                // kgf, the weaker build's first slack
    const pts = models.map((m, k) => {
      const T0 = m.res.spokes.T;
      const T = spokeTensions(m.res, { lat: m.toNDS * P, pos: firsts[k].pos });
      const dT = Math.max(...T.map((t, i) => Math.abs(t - T0[i])));
      const S = dT * KGF_TO_MPA;
      return { dT, S, N: gavinCycles(S), T0max: Math.max(...T0) };
    });
    return { P, pts, weak: firsts[0].scale <= firsts[1].scale ? 0 : 1 };
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);

  // Gavin's line and ±1σ band, sampled in log space.
  const curve = React.useMemo(() => {
    const out = [];
    for (let lg = 1.0; lg <= 2.8001; lg += 0.05) {
      const S = Math.pow(10, lg);
      out.push({ S: +S.toFixed(1), N: gavinCycles(S), lo: gavinCycles(S, -1), hi: gavinCycles(S, 1), tested: S >= GAVIN_SN.minTested });
    }
    return out;
  }, []);
  const tested = curve.filter((p) => p.tested), extrap = curve.filter((p) => p.S <= GAVIN_SN.minTested + 1);
  const txt = { fill: j.muted, fontSize: 9 };

  return (
    <Section title="S-N FATIGUE CURVE" subtitle="how many hits a spoke survives">
      <Study eq={EQ} part="Eq. 10, the fit to spoke fatigue tests (Fig. 13)" cites={[<>Gavin, Henri P. “Bicycle-Wheel Spoke Patterns and Spoke Fatigue.” <i>Journal of Engineering Mechanics</i>, vol. 122, no. 8, 1996, pp. 736–42.</>]} />
      <Lead>Spokes rarely snap from one big hit. They crack, usually at the elbow, after many smaller ones. This line is Gavin's fit to fatigue tests on 76 stainless spokes: how many load cycles a spoke survives at a given stress swing. Each dot is the biggest spoke swing in your two builds under the same sideways hit.</Lead>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart margin={{ top: 6, right: 16, left: 4, bottom: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke={j.bdr} opacity={0.4} />
          <ReferenceArea x1={1e4} x2={1e10} y1={20} y2={150} fill={j.muted} fillOpacity={0.12} stroke="none" ifOverflow="hidden" />
          <XAxis dataKey="N" type="number" scale="log" domain={[1e4, 1e10]} allowDataOverflow ticks={[1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10]}
            tickFormatter={tickN} tick={txt} axisLine={{ stroke: j.bdr }} tickLine={false}
            label={{ value: "cycles to failure (log)", position: "insideBottom", offset: -8, fill: j.muted, fontSize: 9 }} />
          <YAxis dataKey="S" type="number" scale="log" domain={[10, 600]} allowDataOverflow ticks={[10, 20, 50, 100, 200, 500]}
            tick={txt} axisLine={{ stroke: j.bdr }} tickLine={false} width={46}
            label={{ value: "spoke stress swing (MPa, log)", angle: -90, position: "insideLeft", offset: 2, fill: j.muted, fontSize: 9, dy: 60 }} />
          <Tooltip contentStyle={{ background: j.surf, border: `1px solid ${j.bdr}`, borderRadius: 6, fontSize: 11 }}
            formatter={(v, k) => [`${v} MPa`, k]} labelFormatter={(n) => `${fmtN(n)} cycles`} />
          <Line data={curve.map((p) => ({ N: p.lo, S: p.S }))} dataKey="S" stroke={j.muted} strokeWidth={1} strokeDasharray="2 3" dot={false} isAnimationActive={false} name="−1σ" />
          <Line data={curve.map((p) => ({ N: p.hi, S: p.S }))} dataKey="S" stroke={j.muted} strokeWidth={1} strokeDasharray="2 3" dot={false} isAnimationActive={false} name="+1σ" />
          <Line data={extrap} dataKey="S" stroke={j.txt} strokeWidth={2} strokeDasharray="6 4" dot={false} isAnimationActive={false} name="Gavin fit (extrapolated)" />
          <Line data={tested} dataKey="S" stroke={j.txt} strokeWidth={2.4} dot={false} isAnimationActive={false} name="Gavin fit (tested)" />
          {data && data.pts.map((p, k) => (
            <ReferenceDot key={k} x={p.N} y={p.S} r={k ? 0 : 5.5} ifOverflow="extendDomain"
              shape={(props) => (k
                ? <rect x={props.cx - 5} y={props.cy - 5} width={10} height={10} fill={colors[k]} stroke={j.surf} strokeWidth={1.5} />
                : <circle cx={props.cx} cy={props.cy} r={5.5} fill={colors[k]} stroke={j.surf} strokeWidth={1.5} />)}
              label={{ value: k ? "157" : "148", position: k ? "right" : "left", fill: j.txt, fontSize: 10, fontWeight: 700, stroke: j.surf, strokeWidth: 3, paintOrder: "stroke" }} />
          ))}
        </LineChart>
      </ResponsiveContainer>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "6px 0 0", fontFamily: MONO }}>
        <span><svg width={22} height={6} aria-hidden="true"><line x1={1} x2={21} y1={3} y2={3} stroke={j.txt} strokeWidth={2.4} /></svg> tested range</span>
        <span><svg width={22} height={6} aria-hidden="true"><line x1={1} x2={21} y1={3} y2={3} stroke={j.txt} strokeWidth={2} strokeDasharray="6 4" /></svg> extrapolated</span>
        <span><svg width={22} height={6} aria-hidden="true"><line x1={1} x2={21} y1={3} y2={3} stroke={j.muted} strokeWidth={1} strokeDasharray="2 3" /></svg> ±1σ scatter</span>
        <span><i style={{ display: "inline-block", width: 14, height: 9, background: j.muted, opacity: 0.25, verticalAlign: -1 }} /> Gavin's road riding, 20–150 MPa</span>
        <span><svg width={10} height={10} aria-hidden="true"><circle cx={5} cy={5} r={4} fill={colors[0]} /></svg> {names[0]}</span>
        <span><svg width={10} height={10} aria-hidden="true"><rect x={1} y={1} width={8} height={8} fill={colors[1]} /></svg> {names[1]}</span>
      </div>
      {data ? (
        <Readout>
          {`One sideways hit of ${data.P.toFixed(1)} kgf (where the ${data.weak ? "157" : "148"} build's first spoke goes slack) swings the busiest spoke by ${data.pts[0].dT.toFixed(0)} kgf (${data.pts[0].S.toFixed(0)} MPa) on the 148 and ${data.pts[1].dT.toFixed(0)} kgf (${data.pts[1].S.toFixed(0)} MPa) on the 157. On Gavin's fit a spoke takes about ${fmtN(data.pts[0].N)} and ${fmtN(data.pts[1].N)} such hits before it cracks (median; any one spoke can be 74% either side).`}
        </Readout>
      ) : (
        <Readout color={j.warn}>At these settings a build is at or past the rim's buckling tension, so there is no meaningful spoke swing to plot.</Readout>
      )}
      <p style={{ fontSize: 10.5, color: j.warn, margin: "10px 0 0", lineHeight: 1.6 }}>
        Assumes the wheel is built and kept at proper spoke tension. Gavin's spokes stayed under tension through every cycle. On real bikes tension is often wrong or drifts as nipples back off; a spoke that goes slack and snaps tight again sees a bigger swing than shown here, and it loosens its nipple too, so a poorly tensioned wheel can fail far sooner.
      </p>
      <Foot>A fatigue estimate, not a strength figure: it counts repeated hits, while the strength numbers elsewhere in the Lab are about one hit. Gavin's spokes were stainless (1984–85, made for Wheelsmith); 68 of 76 broke at the elbow. The fit is only measured from 174 MPa upward, and Gavin notes that very small cycles likely do no damage, so the extrapolated end is conservative. In his road tests the biggest swings, about 150 MPa, came from potholes. Spoke swings come from Matthew Ford's discrete-spoke Mode Matrix via wheel-physics-core, for a 2.0 mm plain spoke.</Foot>
    </Section>
  );
}
