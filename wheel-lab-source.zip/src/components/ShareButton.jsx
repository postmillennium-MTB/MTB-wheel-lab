import * as React from "react";
import { theme as j } from "../theme-state.js";

// SHARE: an icon-only button in the header, to the right of the color-scheme
// button. The address bar always holds a link to the build and tab on
// screen (see readLink / labHash in App.jsx), so sharing is just handing
// that URL on: through the device's share sheet where the browser has one
// (phones, mostly), otherwise by copying it to the clipboard. The icon turns
// into a check for a moment so the copy is confirmed without any text.
//
// Icons are Lucide "send" and "check" (https://lucide.dev), pasted inline
// with their path data unchanged. The button carries the accessible name;
// the SVG is decorative.
const SVG = { xmlns: "http://www.w3.org/2000/svg", width: 14, height: 14, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", focusable: "false" };

export default function ShareButton() {
  const [done, setDone] = React.useState(false);
  const timer = React.useRef(null);
  React.useEffect(() => () => clearTimeout(timer.current), []);
  const confirm = () => { setDone(true); clearTimeout(timer.current); timer.current = setTimeout(() => setDone(false), 1800); };
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) { await navigator.share({ title: document.title, url }); return; }
    } catch (err) {
      // The reader closed the share sheet: nothing to do, and no copy behind their back.
      if (err && err.name === "AbortError") return;
    }
    try {
      await navigator.clipboard.writeText(url);
      confirm();
    } catch (err) {
      // No clipboard access (old browser, blocked permission): fall back to a
      // prompt-free copy through a temporary field.
      try {
        const ta = document.createElement("textarea");
        ta.value = url; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
        document.body.appendChild(ta); ta.select();
        const ok = document.execCommand("copy");
        document.body.removeChild(ta);
        if (ok) confirm();
      } catch (err2) {}
    }
  };
  return (
    <button onClick={share} aria-label={done ? "Link copied" : "Share this build"} title={done ? "Link copied" : "Share this build"}
      style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", padding: "5px 9px", background: j.surfl, border: `1px solid ${j.bdr}`, borderRadius: 6, cursor: "pointer", color: done ? j.txt : j.muted, flexShrink: 0 }}>
      {done ? (
        <svg {...SVG} className="lucide lucide-check"><path d="M20 6 9 17l-5-5" /></svg>
      ) : (
        <svg {...SVG} className="lucide lucide-send"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z" /><path d="m21.854 2.147-10.94 10.939" /></svg>
      )}
      <span role="status" style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>{done ? "Link copied" : ""}</span>
    </button>
  );
}
