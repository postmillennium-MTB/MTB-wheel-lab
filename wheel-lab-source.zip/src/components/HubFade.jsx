import * as React from "react";
import { theme as j } from "../theme-state.js";
import ToggleGroup from "./ToggleGroup.jsx";

// Shared 148/157 hub choice and Play crossfade for the failure views (the
// failure map and the spoke ring on COMPARE). One state drives both, so
// switching hub or pressing Play in either section moves both charts.
//
// `which` is the chosen hub (0 = 148, 1 = 157). `shown` is the layer at
// full opacity; it trails `which` by one fade so the old hub fades fully
// out before the new one fades in (null = both faded out, mid-crossfade).
// `lastShown` is the hub to name in a title while both layers are out.

export const FADE_MS = 1100, PLAY_MS = 4000;
export const HUB_LABELS = ["148x12", "157x12"];

export const reducedMotion = () => typeof window !== "undefined" && window.matchMedia
  && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export const fadeStyle = () => (reducedMotion() ? "none" : `opacity ${FADE_MS}ms ease-in-out`);

export function useHubFade() {
  const [which, setWhich] = React.useState(0);
  const [shown, setShown] = React.useState(0);
  const lastShown = React.useRef(0);
  if (shown != null) lastShown.current = shown;
  const [playing, setPlaying] = React.useState(false);
  React.useEffect(() => {
    if (shown === which) return;
    setShown(null);
    const id = setTimeout(() => setShown(which), reducedMotion() ? 0 : FADE_MS);
    return () => clearTimeout(id);
  }, [which]);
  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setWhich((w) => 1 - w), PLAY_MS);
    const hide = () => { if (document.hidden) setPlaying(false); };
    document.addEventListener("visibilitychange", hide);
    return () => { clearInterval(id); document.removeEventListener("visibilitychange", hide); };
  }, [playing]);
  const togglePlay = () => {
    if (!playing) setWhich((w) => 1 - w);
    setPlaying(!playing);
  };
  const pickHub = (o) => { setPlaying(false); setWhich(HUB_LABELS.indexOf(o)); };
  return { which, shown, lastShown: lastShown.current, playing, togglePlay, pickHub };
}

/** Play/Pause button + HUB toggle, as the failure map has always drawn them. */
export function HubFadeControls({ fade }) {
  const colors = [j.h148, j.h157];
  const { playing, togglePlay, which, pickHub } = fade;
  return (
    <>
      <button onClick={togglePlay} aria-pressed={playing}
        style={{ display: "inline-flex", alignItems: "center", gap: 7, padding: "5px 11px", borderRadius: 5, cursor: "pointer",
          border: `1.5px solid ${j.slack}`, background: playing ? j.slack : "transparent", color: playing ? j.surf : j.slack,
          fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 10, letterSpacing: "0.06em" }}>
        <svg viewBox="0 0 12 12" width={10} height={10} aria-hidden="true">
          <path d={playing ? "M2 1h3v10H2zM7 1h3v10H7z" : "M2 1l9 5-9 5z"} fill="currentColor" />
        </svg>
        {playing ? "PAUSE" : "PLAY"}
      </button>
      <ToggleGroup label="HUB" opts={HUB_LABELS} val={HUB_LABELS[which]} set={pickHub} activeColor={colors[which]} />
    </>
  );
}

/** The fading hub-name title above a chart. */
export function HubFadeTitle({ fade, names, narrow }) {
  const colors = [j.h148, j.h157];
  return (
    <div style={{ fontFamily: "Space Grotesk, system-ui", fontWeight: 700, fontSize: narrow ? 17 : 20, lineHeight: 1.2, color: colors[fade.lastShown],
      opacity: fade.shown == null ? 0 : 1, transition: fadeStyle(), margin: "2px 0 4px", minHeight: "1.2em" }}>
      {names[fade.lastShown]}
    </div>
  );
}

/** Width-based narrow layout switch (same 560 px break the failure map uses). */
export function useNarrow(ref, ready) {
  const [narrow, setNarrow] = React.useState(false);
  React.useEffect(() => {
    const f = () => setNarrow((ref.current ? ref.current.clientWidth : 720) < 560);
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, [ready]);
  return narrow;
}
