import * as _ from "react/jsx-runtime";

const PIXEL_SIZE = 5;
const FOX_FRAMES = [
  ["..............", "...O......O...", "..OO......OO..", "..OOOOOOOOOOO.", ".OOOOOOOOOOOOW", "WOOODOOOOOOOOO", "WOOOOOOOOOOOO.", "..OO..OO..OO..", "..KK..KK..KK..", ".............."],
  ["..............", "...O......O...", "..OO......OO..", "..OOOOOOOOOOO.", ".OOOOOOOOOOOOW", "WOOODOOOOOOOOO", "WOOOOOOOOOOOO.", ".OO...OO...OO.", ".K.....KK....K", ".K...........K"],
];
const FOX_PALETTE = { O: "#E8893A", D: "#1A1205", W: "#F5E6D0", K: "#2A1B08" };

/** Tiny pixel-art fox sprite, alternates between two frames while animating. */
function PixelFox({frame:e}){let t=FOX_FRAMES[e];return(0,_.jsx)("svg",{width:14*PIXEL_SIZE,height:10*PIXEL_SIZE,style:{display:"block",imageRendering:"pixelated"},children:t.map((r,n)=>r.split("").map((i,o)=>i!=="."?(0,_.jsx)("rect",{x:o*PIXEL_SIZE,y:n*PIXEL_SIZE,width:PIXEL_SIZE,height:PIXEL_SIZE,fill:FOX_PALETTE[i]},`${o}-${n}`):null))})}

export default PixelFox;
