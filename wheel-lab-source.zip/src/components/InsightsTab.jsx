import * as React from "react";
import { theme as j } from "../theme-state.js";
import { computeWheelStrength, applyRimOffset, tightSideFirst } from "../physics.js";
import { HUBS_148, HUBS_157, PHYS_CONSTANTS } from "../data.js";
import Section from "./Section.jsx";
import ToggleGroup from "./ToggleGroup.jsx";
import { useNarrow } from "./HubFade.jsx";

// INSIGHTS: four extra outputs from Matthew Ford's work that the other tabs
// don't show. Each section names the study it comes from. All numbers come
// from wheel-physics-core (K_tor, nSP_rad, nSP_lat, K_lat at each tension,
// T_c_modes), which is checked against Ford's bike-wheel-calc to
// floating-point precision in its validation/insights/ folder.
//
//   1. Wind-up stiffness   Ford (2018) thesis, "Loading case II: tangential
//                          point load"; bike-wheel-calc calc_tor_stiff.
//   2. Spokes sharing a hit Ford (2018) thesis, Smith-Pippard number n_SP,
//                          after Hetenyi (1946), Smith (1901), Pippard (1931).
//   3. Tension softening   Ford (2018) thesis, "Lateral stiffness vs. spoke
//                          tension" (compared with Rinard's measurements).
//   4. Taco shape          Ford, Papadopoulos & Balogun (2016), "Buckling of
//                          the bicycle wheel": critical tension per mode n.

const MONO = "Space Mono, monospace", GROT = "Space Grotesk, system-ui";
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const HUB_SHORT = ["148", "157"];

/** Engine result for one hub at this build (rim offset applied, tighter side first, as everywhere in the Lab). */
function build(hub, erd, Ns, offset, tension) {
  const { EIL, EIR, GJ, EA_rim, modes } = PHYS_CONSTANTS;
  const g = tightSideFirst(applyRimOffset(hub, offset), erd, Ns);
  return computeWheelStrength(erd, g, 2, 2, Math.max(tension, 1e-9), EIL, EIR, GJ, EA_rim, Ns, modes);
}

/**
 * The STUDY line, with an EQUATION button that opens the formula behind the
 * chart. `eq` = { lines: [JSX...], where: JSX, note?: JSX }.
 */
function Study({ children, eq }) {
  const [open, setOpen] = React.useState(false);
  const id = React.useId();
  return (
    <div style={{ margin: "4px 0 10px" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10, borderLeft: `3px solid ${j.bdr}`, paddingLeft: 10 }}>
        <p style={{ fontSize: 10, color: j.txt, fontFamily: MONO, margin: 0, lineHeight: 1.6, flex: 1, minWidth: 0 }}>
          <b style={{ letterSpacing: "0.06em" }}>STUDY</b> · {children}
        </p>
        {eq && (
          <button onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls={id}
            style={{ flex: "0 0 auto", padding: "3px 8px", borderRadius: 4, cursor: "pointer", border: `1px solid ${j.txt}`,
              background: open ? j.txt : "transparent", color: open ? j.surf : j.txt, fontFamily: MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: "0.06em" }}>
            {open ? "EQUATION ▾" : "EQUATION ▸"}
          </button>
        )}
      </div>
      {eq && open && (
        <div id={id} style={{ margin: "8px 0 0", padding: "10px 12px", background: j.surfl, border: `1px solid ${j.bdr}`, borderRadius: 6 }}>
          {eq.lines.map((l, i) => (
            <div key={i} style={{ fontFamily: MONO, fontSize: 12, color: j.txt, lineHeight: 1.9, paddingLeft: 16, textIndent: -16, overflowWrap: "anywhere" }}>{l}</div>
          ))}
          <p style={{ fontSize: 10, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>{eq.where}</p>
          {eq.note && <p style={{ fontSize: 10, color: j.muted, margin: "6px 0 0", lineHeight: 1.6 }}>{eq.note}</p>}
        </div>
      )}
    </div>
  );
}

// The formula behind each chart, as wheel-physics-core's js/engine.js
// computes it, traced to Ford's thesis, his 2016 paper or bike-wheel-calc.
const Sb = ({ children }) => <sub>{children}</sub>, Sp = ({ children }) => <sup>{children}</sup>;
const EQ = {
  windup: {
    lines: [
      <>K<Sb>tor</Sb> = R² / C</>,
      <>C = 1 / (2πR·k̄<Sb>ww</Sb>) + Σ<Sb>n=1…24</Sb> K<Sb>vv</Sb> / (K<Sb>vv</Sb>K<Sb>ww</Sb> − K<Sb>vw</Sb>²)</>,
      <>K<Sb>vv</Sb> = πEI<Sb>rad</Sb>n⁴/R³ + πEA/R + πR·k̄<Sb>vv</Sb></>,
      <>K<Sb>ww</Sb> = πEI<Sb>rad</Sb>n²/R³ + πEA·n²/R + πR·k̄<Sb>ww</Sb></>,
      <>K<Sb>vw</Sb> = −(πEI<Sb>rad</Sb>n³/R³ + πEA·n/R)</>,
    ],
    where: <>R rim radius; EI<Sb>rad</Sb> rim in-plane bending stiffness; EA rim stretching stiffness; k̄<Sb>vv</Sb>, k̄<Sb>ww</Sb> smeared spoke stiffness per metre of rim, radial and tangential (tension included); n number of waves around the rim. Each wave shape acts as a spring and their give adds up (C). Shown per degree: K<Sb>tor</Sb>·π/180.</>,
    note: <>Ford's one-line shortcut (thesis Eq. Ktan), treating the rim as a rigid ring: K ≈ 2πR·k̄<Sb>ww</Sb>, tangential spoke stiffness alone.</>,
  },
  spread: {
    lines: [
      <>n<Sb>SP</Sb> = N<Sb>s</Sb> / (πR) · (4EI / k)<Sp>1/4</Sp></>,
      <>straight down: EI = EI<Sb>rad</Sb>, k = k̄<Sb>vv</Sb></>,
      <>sideways: EI = EI<Sb>lat</Sb>·μ/(μ+1), μ = GJ/EI<Sb>lat</Sb>, k = k̄<Sb>uu</Sb></>,
      <>curve: w(x) / w(0) = e<Sp>−βx</Sp>(cos βx + sin βx), β = (k / 4EI)<Sp>1/4</Sp></>,
    ],
    where: <>N<Sb>s</Sb> spoke count; R rim radius; EI<Sb>rad</Sb>, EI<Sb>lat</Sb> rim bending stiffness in-plane and sideways; GJ rim twisting stiffness; k̄<Sb>vv</Sb>, k̄<Sb>uu</Sb> smeared spoke stiffness per metre of rim, radial and sideways. The affected length is 2/β, and n<Sb>SP</Sb> counts the spokes inside it.</>,
    note: <>n<Sb>SP</Sb>: Ford's thesis, smeared spokes approximation. Curve: Hetényi (1946), beam on an elastic foundation. The sideways form follows bike-wheel-calc's calc_Pn_lat.</>,
  },
  soften: {
    lines: [
      <>1 / K<Sb>lat</Sb> = 1/K<Sb>0</Sb> + 1/K<Sb>1</Sb> + 1/K<Sb>2</Sb> + …</>,
      <>K<Sb>n</Sb> = rim bending &amp; twist + spoke stiffness + spoke tension-stiffness − πn²T̄</>,
    ],
    where: <>K<Sb>n</Sb> stiffness of the rim bent into n side-to-side waves, added like springs in series; T̄ spoke tension per metre of rim; T<Sb>c</Sb> buckling tension. The −πn²T̄ term is the rim being squeezed by the spokes: as tension rises it eats into every K<Sb>n</Sb>, and K<Sb>lat</Sb> reaches zero at T<Sb>c</Sb>.</>,
    note: <>Series rule: Ford's thesis, Eq. Klat_series, with 24 modes as in bike-wheel-calc's calc_lat_stiff. The tension terms are the two effects Ford describes in "Lateral stiffness vs. spoke tension": spoke tension-stiffness (like a guitar string) and the rim's tendency to buckle.</>,
  },
  taco: {
    lines: [
      <>T<Sb>c,n</Sb> = (2πEI / (N<Sb>s</Sb>R²)) · t<Sb>c</Sb> / (n² − R·k<Sb>T</Sb>)</>,
      <>t<Sb>c</Sb> = λ<Sb>uu</Sb> + [μn²(n²−1)² + (n⁴+μn²)λ<Sb>φφ</Sb> + 2n²(μ+1)λ<Sb>uφ</Sb> − λ<Sb>uφ</Sb>²] / (1 + μn² + λ<Sb>φφ</Sb>)</>,
      <>μ = (GJ + EI<Sb>w</Sb>n²/R²) / EI,   λ<Sb>ij</Sb> = R⁴·k̄<Sb>ij</Sb> / EI</>,
    ],
    where: <>n number of waves; EI rim sideways bending stiffness; GJ rim twisting stiffness; EI<Sb>w</Sb> rim warping stiffness (0 here); k̄<Sb>uu</Sb>, k̄<Sb>uφ</Sb>, k̄<Sb>φφ</Sb> smeared spoke stiffness against sideways movement and rim twist; k<Sb>T</Sb> spoke tension-stiffness. The lowest T<Sb>c,n</Sb> sets the shape. Shown as the equivalent drive-side tension.</>,
    note: <>Ford, Papadopoulos &amp; Balogun (2016), linear approximation, as in bike-wheel-calc's calc_buckling_tension(approx='linear').</>,
  },
};

const Lead = ({ children }) => <p style={{ fontSize: 10.5, color: j.muted, margin: "0 0 12px", lineHeight: 1.6 }}>{children}</p>;
const Foot = ({ children }) => <p style={{ fontSize: 9.5, color: j.muted, margin: "10px 0 0", lineHeight: 1.6 }}>{children}</p>;
const Readout = ({ children, color }) => (
  <p style={{ fontSize: 11, color: color || j.txt, margin: "10px 0 0", lineHeight: 1.6 }}>{children}</p>
);
const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };
function Key({ items }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 0", fontFamily: MONO }}>
      {items.map(([sw, label]) => <span key={label} style={keyRow}>{sw}{label}</span>)}
    </div>
  );
}
const lineSwatch = (color, dash) => (
  <svg width={22} height={6} aria-hidden="true"><line x1={1} x2={21} y1={3} y2={3} stroke={color} strokeWidth={2.4} strokeDasharray={dash || "none"} /></svg>
);
// Text over lines gets a halo in the panel color.
const halo = () => ({ stroke: j.surf, strokeWidth: 4, paintOrder: "stroke", strokeLinejoin: "round" });

// ---------------------------------------------------------------- 1. wind-up
function WindUp({ all, sel, narrow }) {
  const rows = [...all].sort((a, b) => b.K_tor - a.K_tor);
  const max = Math.max(...rows.map((r) => r.K_tor));
  const W = narrow ? 420 : 680, L = narrow ? 8 : 230, Rm = 52, rowH = narrow ? 30 : 17, top = 8;
  const H = top + rows.length * rowH + 8;
  const X = (v) => L + v / max * (W - L - Rm);
  const colors = [j.h148, j.h157];
  const txt = { fontFamily: MONO, fontSize: narrow ? 11 : 10 };
  const mark = (r, cx, cy, fill) => (r.std === 0
    ? <circle cx={cx} cy={cy} r={4} fill={fill} />
    : <rect x={cx - 4} y={cy - 4} width={8} height={8} fill={fill} />);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Wind-up stiffness of every hub in the catalogue, ranked"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {rows.map((r, i) => {
        const s = sel.indexOf(r.id), on = s >= 0;
        const y = top + i * rowH, barY = narrow ? y + 15 : y + 4, bh = on ? 10 : 6;
        const fill = on ? colors[s] : j.muted;
        const nameX = narrow ? L + 14 : L - 10, nameY = narrow ? y + 11 : y + 12;
        return (
          <g key={r.id}>
            {mark(r, narrow ? L + 4 : L - 222 + 4, narrow ? nameY - 4 : nameY - 4, fill)}
            <text {...txt} x={narrow ? nameX : L - 208} y={nameY} fill={on ? j.txt : j.muted} fontWeight={on ? 700 : 400}>
              {r.name}
            </text>
            {/* Other hubs: thin outlined bars. Your two hubs: thick solid bars, so they
                stand out by shape as well as color in every theme. */}
            <rect x={L + (on ? 0 : 0.5)} y={barY + (on ? 0 : 2)} width={X(r.K_tor) - L - (on ? 0 : 1)} height={bh}
              fill={on ? fill : "none"} stroke={on ? "none" : j.muted} strokeWidth={1} />
            <text {...txt} x={X(r.K_tor) + 6} y={barY + 8} fill={on ? j.txt : j.muted} fontWeight={on ? 700 : 400}>{fmt(r.K_tor)}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 2. affected length
function AffectedLength({ nsp, narrow, dir }) {
  const E = narrow ? { l: 40, r: 10, t: 16, b: 74, w: 420, h: 300 } : { l: 48, r: 18, t: 18, b: 70, w: 680, h: 300 };
  const span = Math.max(6, Math.ceil(Math.max(...nsp) * 1.4));
  const X = (u) => E.l + (u + span) / (2 * span) * (E.w - E.l - E.r);
  const ymin = -0.15, Y = (v) => E.t + (1 - v) / (1 - ymin) * (E.h - E.t - E.b);
  const colors = [j.h148, j.h157], dash = ["none", "7 5"];
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 12 : 11 };
  // Hetenyi's infinite beam on an elastic foundation under a point load:
  // w(x) / w(0) = e^(-bx)(cos bx + sin bx). In spoke spacings the affected
  // length 2/b holds n_SP spokes, so b*x = 2|u| / n_SP.
  const curve = (n) => {
    const p = [];
    for (let k = 0; k <= 240; k++) {
      const u = -span + 2 * span * k / 240, a = 2 * Math.abs(u) / n;
      p.push(`${X(u)},${Y(Math.exp(-a) * (Math.cos(a) + Math.sin(a)))}`);
    }
    return p.join(" ");
  };
  const ticks = [];
  for (let u = -span; u <= span; u++) ticks.push(u);
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label={`How far a ${dir} hit spreads along the rim, in spoke spacings`}
      style={{ display: "block", width: "100%", height: "auto" }}>
      {[0, 0.5, 1].map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 6} y={Y(v) + 4} textAnchor="end">{v === 0 ? "0" : v === 1 ? "max" : "½"}</text>
        </g>
      ))}
      {ticks.map((u) => (
        <g key={u}>
          {/* one short stroke per spoke along the rim */}
          <line x1={X(u)} x2={X(u)} y1={Y(ymin)} y2={Y(ymin) + 7} stroke={j.muted} strokeWidth={1.4} />
          {(u % 2 === 0) && <text {...txt} x={X(u)} y={Y(ymin) + 20} textAnchor="middle">{Math.abs(u)}</text>}
        </g>
      ))}
      <text {...txt} x={(E.l + E.w - E.r) / 2} y={Y(ymin) + 36} textAnchor="middle">spokes from the hit</text>
      <text {...txt} x={X(0)} y={E.t - 4} textAnchor="middle" fontWeight={700} fill={j.txt}>▼ hit</text>
      {nsp.map((n, i) => (
        <polyline key={i} points={curve(n)} fill="none" stroke={colors[i]} strokeWidth={2.4} strokeDasharray={dash[i]} />
      ))}
      {nsp.map((n, i) => {
        const y = E.h - 22 + i * 12;
        return (
          <g key={"b" + i}>
            <line x1={X(-n / 2)} x2={X(n / 2)} y1={y} y2={y} stroke={colors[i]} strokeWidth={3} strokeDasharray={dash[i] === "none" ? "none" : "5 3"} />
            <line x1={X(-n / 2)} x2={X(-n / 2)} y1={y - 4} y2={y + 4} stroke={colors[i]} strokeWidth={2} />
            <line x1={X(n / 2)} x2={X(n / 2)} y1={y - 4} y2={y + 4} stroke={colors[i]} strokeWidth={2} />
            <text {...txt} x={X(n / 2) + 8} y={y + 4} fill={j.txt} style={halo()}>{`${HUB_SHORT[i]}: ${fmt(n, 1)} spokes`}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 3. tension softening
function Softening({ sweeps, tension, narrow }) {
  const E = narrow ? { l: 46, r: 12, t: 18, b: 48, w: 420, h: 340 } : { l: 56, r: 24, t: 20, b: 48, w: 680, h: 340 };
  const xm = Math.ceil(Math.max(...sweeps.map((s) => s.T_c), tension) * 1.08 / 25) * 25;
  const ym = Math.ceil(Math.max(...sweeps.flatMap((s) => s.pts.map((p) => p[1]))) * 1.12 / 20) * 20;
  const X = (v) => E.l + v / xm * (E.w - E.l - E.r), Y = (v) => E.h - E.b - v / ym * (E.h - E.t - E.b);
  const colors = [j.h148, j.h157], dash = ["none", "7 5"];
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 12 : 11 };
  const xs = [], ys = [];
  const xstep = xm > 200 ? 50 : 25;
  for (let v = 0; v <= xm; v += xstep) xs.push(v);
  for (let v = 0; v <= ym; v += 20) ys.push(v);
  const yl = narrow ? 12 : 14, ym2 = (E.t + E.h - E.b) / 2;
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label="Lateral stiffness against drive-side spoke tension for both hubs"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {ys.map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 8} y={Y(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      {xs.map((v) => (
        <g key={v}>
          <line x1={X(v)} x2={X(v)} y1={E.t} y2={E.h - E.b} stroke={j.bdr} strokeWidth={v ? 0.6 : 1.5} />
          <text {...txt} x={X(v)} y={E.h - E.b + 16} textAnchor="middle">{v}</text>
        </g>
      ))}
      <text {...txt} x={E.w - E.r} y={E.h - 8} textAnchor="end">drive-side spoke tension (kgf)</text>
      <text {...txt} x={yl} y={ym2} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym2})`}>lateral stiffness (N/mm)</text>
      <line x1={X(tension)} x2={X(tension)} y1={E.t} y2={E.h - E.b} stroke={j.txt} strokeWidth={1} strokeDasharray="2 3" />
      <text {...txt} x={X(tension) + 5} y={E.t + 10} fill={j.txt} style={halo()}>{`your ${fmt(tension)} kgf`}</text>
      {sweeps.map((s, i) => (
        <polyline key={i} points={s.pts.map(([x, y]) => `${X(x)},${Y(y)}`).join(" ")} fill="none" stroke={colors[i]} strokeWidth={2.4} strokeDasharray={dash[i]} />
      ))}
      {sweeps.map((s, i) => {
        const [ex, ey] = s.pts[s.pts.length - 1];
        return (
          <g key={"e" + i}>
            <path d={`M${X(ex) - 5},${Y(ey) - 5}L${X(ex) + 5},${Y(ey) + 5}M${X(ex) - 5},${Y(ey) + 5}L${X(ex) + 5},${Y(ey) - 5}`} stroke={colors[i]} strokeWidth={2.4} />
            <text {...txt} x={X(ex) - 8} y={Y(ey) + (i ? -10 : 18)} textAnchor="end" fill={j.txt} style={halo()}>{`${HUB_SHORT[i]} buckles ${fmt(s.T_c)}`}</text>
            {s.here != null && tension < s.T_c && (
              <circle cx={X(tension)} cy={Y(s.here)} r={5.5} fill={colors[i]} stroke={j.surf} strokeWidth={2} />
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 4. taco shape
/** The rim seen at an angle, bent into n side-to-side waves. */
function TacoSketch({ n, size = 120, color }) {
  const c = size / 2, rx = size * 0.42, ry = size * 0.17, a = size * 0.1;
  const pts = (amp) => {
    const p = [];
    for (let k = 0; k <= 180; k++) {
      const th = k / 180 * 2 * Math.PI;
      p.push(`${c + rx * Math.cos(th)},${c + ry * Math.sin(th) - amp * Math.cos(n * th)}`);
    }
    return p.join(" ");
  };
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden="true" style={{ display: "block", flex: "0 0 auto" }}>
      <polyline points={pts(0)} fill="none" stroke={j.muted} strokeWidth={1} strokeDasharray="2 3" />
      <polyline points={pts(a)} fill="none" stroke={color} strokeWidth={2.4} />
    </svg>
  );
}

function TacoModes({ modes, tension, narrow }) {
  const E = narrow ? { l: 46, r: 10, t: 22, b: 92, w: 420, h: 340 } : { l: 56, r: 16, t: 24, b: 92, w: 680, h: 340 };
  const ns = modes[0].map((m) => m.n);
  const all = modes.flatMap((ms) => ms.map((m) => m.T_c_DS));
  const ym = Math.ceil(Math.max(...all, tension) * 1.1 / 100) * 100;
  const Y = (v) => E.h - E.b - v / ym * (E.h - E.t - E.b);
  const gw = (E.w - E.l - E.r) / ns.length, bw = Math.min(30, gw * 0.3);
  const colors = [j.h148, j.h157];
  const lows = modes.map((ms) => ms.reduce((a, b) => (b.T_c_DS < a.T_c_DS ? b : a)).n);
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 11.5 : 11 };
  const ys = [];
  for (let v = 0; v <= ym; v += 100) ys.push(v);
  const yl = narrow ? 12 : 14, ym2 = (E.t + E.h - E.b) / 2;
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label="Spoke tension that buckles the rim into each wave shape, both hubs"
      style={{ display: "block", width: "100%", height: "auto" }}>
      <defs>
        <pattern id="ins-hatch157" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="6" fill={j.surf} />
          <rect width="3.2" height="6" fill={j.h157} />
        </pattern>
      </defs>
      {ys.map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 8} y={Y(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      <text {...txt} x={yl} y={ym2} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym2})`}>drive-side tension (kgf)</text>
      {ns.map((n, k) => {
        const cx = E.l + gw * (k + 0.5);
        return (
          <g key={n}>
            {modes.map((ms, i) => {
              const v = ms[k].T_c_DS, x = cx + (i ? 2 : -bw - 2), low = lows[i] === n;
              return (
                <g key={i}>
                  <rect x={x} y={Y(v)} width={bw} height={Y(0) - Y(v)} fill={i ? "url(#ins-hatch157)" : colors[0]} stroke={colors[i]} strokeWidth={1.5} />
                  <text {...txt} x={x + bw / 2} y={Y(v) - 5} textAnchor="middle" fill={j.txt} fontWeight={low ? 700 : 400} fontSize={narrow ? 10 : 10.5} style={halo()}>
                    {fmt(v)}
                  </text>
                </g>
              );
            })}
            <g transform={`translate(${cx - 22},${Y(0) + 4})`}>
              <TacoSketchInline n={n} />
            </g>
            <text {...txt} x={cx} y={Y(0) + 62} textAnchor="middle" fill={lows.includes(n) ? j.txt : j.muted} fontWeight={lows.includes(n) ? 700 : 400}>
              {`${n} waves`}
            </text>
            {lows.includes(n) && <text {...txt} x={cx} y={Y(0) + 78} textAnchor="middle" fill={j.txt} fontWeight={700}>LOWEST</text>}
          </g>
        );
      })}
      <line x1={E.l} x2={E.w - E.r} y1={Y(tension)} y2={Y(tension)} stroke={j.txt} strokeWidth={1} strokeDasharray="2 3" />
      <text {...txt} x={E.w - E.r} y={Y(tension) - 5} textAnchor="end" fill={j.txt} style={halo()}>{`your ${fmt(tension)} kgf`}</text>
    </svg>
  );
}
// Small inline version of TacoSketch for the bar chart's x axis (44 px).
function TacoSketchInline({ n }) {
  const s = 44, c = s / 2, rx = 19, ry = 7, a = 4.5;
  const p = (amp) => {
    const q = [];
    for (let k = 0; k <= 120; k++) {
      const th = k / 120 * 2 * Math.PI;
      q.push(`${c + rx * Math.cos(th)},${c + ry * Math.sin(th) - amp * Math.cos(n * th)}`);
    }
    return q.join(" ");
  };
  return <polyline points={p(a)} fill="none" stroke={j.muted} strokeWidth={1.4} />;
}

// ---------------------------------------------------------------- tab
/** hubs = [hub148, hub157] from the main picker; erd, spokes, tension, offset as elsewhere. */
export default function InsightsTab({ hubs, erd, spokes, tension, offset }) {
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, true);
  const [dir, setDir] = React.useState("SIDEWAYS");
  const colors = [j.h148, j.h157];
  const sel = hubs.map((h) => h.id);

  const data = React.useMemo(() => {
    const res = hubs.map((h) => build(h, erd, spokes, offset, tension));
    const all = [...HUBS_148.map((h) => ({ ...h, std: 0 })), ...HUBS_157.map((h) => ({ ...h, std: 1 }))]
      .map((h) => ({ id: h.id, name: h.name, std: h.std, K_tor: build(h, erd, spokes, offset, tension).K_tor }));
    const sweeps = hubs.map((h, i) => {
      const T_c = res[i].T_c, pts = [], steps = 60;
      for (let k = 0; k <= steps; k++) {
        const T = T_c * k / steps, K = build(h, erd, spokes, offset, T).K_lat;
        if (!(K > 0)) break;
        pts.push([T, K]);
      }
      return { T_c, pts, here: tension < T_c ? res[i].K_lat : null, K0: pts.length ? pts[0][1] : NaN };
    });
    return { res, all, sweeps };
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);

  const { res, all, sweeps } = data;
  const allSorted = [...all].sort((a, b) => b.K_tor - a.K_tor);
  const rank = (id) => allSorted.findIndex((r) => r.id === id) + 1;
  const R = res[0].R_rim / 1000;   // m, same rim for both hubs
  const creep = (K) => 100 / K * Math.PI / 180 * R * 1000;   // mm of rim travel per 100 N·m
  const nsp = res.map((r) => (dir === "SIDEWAYS" ? r.nSP_lat : r.nSP_rad));
  const modes = res.map((r) => r.T_c_modes);
  const lowN = modes.map((ms) => ms.reduce((a, b) => (b.T_c_DS < a.T_c_DS ? b : a)));
  const past = res.map((r) => !(r.T_safety < 100));
  const drop = sweeps.map((s) => (s.here != null ? (1 - s.here / s.K0) * 100 : null));
  const names = hubs.map((h) => h.name);

  return (
    <div ref={wrap}>
      <p style={{ fontSize: 11, color: j.muted, margin: "0 0 12px", lineHeight: 1.6 }}>
        Four more results from Matthew Ford's work on bicycle wheels that the other tabs don't show, for your two hubs at the current rim, spoke count, tension and offset. Each one names the study it comes from. The numbers come from the same validated engine as the rest of the Lab, checked against Ford's own bike-wheel-calc code.
      </p>
      {(past[0] || past[1]) && (
        <p style={{ fontSize: 11.5, color: j.warn, margin: "0 0 12px", lineHeight: 1.6 }}>
          {past[0] && past[1] ? "Both builds are" : past[0] ? "The 148 build is" : "The 157 build is"} at or past the rim's buckling tension at these settings, so the stiffness numbers below describe a wheel that would not stay true.
        </p>
      )}

      <Section title="WIND-UP STIFFNESS" subtitle="pedaling + disc-brake torque">
        <Study eq={EQ.windup}>Ford (2018), PhD thesis, Northwestern University, ch. 2 "Loading case II: tangential point load"; bike-wheel-calc <code>calc_tor_stiff</code>.</Study>
        <Lead>Pedaling and disc braking twist the hub against the rim. Wind-up stiffness is how hard the spokes resist that twist: torque per degree of rim rotation relative to the hub. Higher means less wind-up. It depends mostly on flange diameter, so it ranks hubs differently from lateral stiffness.</Lead>
        <WindUp all={all} sel={sel} narrow={narrow} />
        <Key items={[
          [<svg width={10} height={10} aria-hidden="true"><circle cx={5} cy={5} r={4} fill={j.muted} /></svg>, "148x12"],
          [<svg width={10} height={10} aria-hidden="true"><rect x={1} y={1} width={8} height={8} fill={j.muted} /></svg>, "157x12"],
          [<i style={{ display: "inline-block", width: 18, height: 8, background: `linear-gradient(90deg, ${j.h148} 50%, ${j.h157} 50%)` }} />, "thick solid bars: your two hubs"],
        ]} />
        <Readout>
          {res.map((r, i) => `${names[i]}: ${fmt(r.K_tor)} N·m per degree, #${rank(sel[i])} of ${all.length}; 100 N·m of torque moves its rim ${fmt(creep(r.K_tor), 2)} mm relative to the hub.`).join(" ")}
        </Readout>
        <Foot>Smeared-spoke Mode Matrix, units N·m per degree of rim rotation. Spokes are modelled as 3-cross; radial spokes would have almost no wind-up stiffness. Hub-shell and freehub twist are not included.</Foot>
      </Section>

      <Section title="SPOKES SHARING A HIT" subtitle="how far a point load spreads">
        <Study eq={EQ.spread}>Ford (2018), PhD thesis, ch. 2 "Smeared spokes approximation", the Smith-Pippard number n<sub>SP</sub>, built on Hetényi (1946) <i>Beams on Elastic Foundation</i> and the smeared-spoke models of Smith (1901) and Pippard &amp; Francis (1931).</Study>
        <Lead>A bump or a sideways push at the tire does not load one spoke. The rim spreads it over a short stretch, like a rail on its sleepers. The bracket shows how many spokes sit inside that stretch. Fewer spokes means each one takes a bigger share of the hit.</Lead>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "10px 14px", marginBottom: 8 }}>
          <ToggleGroup label="HIT" opts={["SIDEWAYS", "STRAIGHT DOWN"]} val={dir} set={setDir} activeColor={j.acc} />
        </div>
        <AffectedLength nsp={nsp} narrow={narrow} dir={dir === "SIDEWAYS" ? "sideways" : "straight-down"} />
        <Key items={[[lineSwatch(colors[0]), names[0]], [lineSwatch(colors[1], "7 5"), names[1]]]} />
        <Readout>
          {dir === "SIDEWAYS"
            ? `A sideways hit spreads over ${fmt(nsp[0], 1)} spokes on the ${names[0]} and ${fmt(nsp[1], 1)} on the ${names[1]}.`
            : `A straight-down hit spreads over ${fmt(nsp[0], 2)} spokes on the ${names[0]} and ${fmt(nsp[1], 2)} on the ${names[1]}. The rim sets this, not the hub, so it barely changes from hub to hub.`}
        </Readout>
        <Foot>Curve: Hetényi's deflection shape for a straight beam on an elastic foundation under a point load, scaled to each hub's affected length. Ford uses n<sub>SP</sub> to check when smeared spokes are accurate (more than about one spoke in the affected length). The sideways version uses the combined bending and twisting rim stiffness from bike-wheel-calc's <code>calc_Pn_lat</code>.</Foot>
      </Section>

      <Section title="TENSION SOFTENING" subtitle="tighter is not always stiffer">
        <Study eq={EQ.soften}>Ford (2018), PhD thesis, ch. 2 "Lateral stiffness vs. spoke tension", which compares the theory with his own measurements and with Damon Rinard's.</Study>
        <Lead>Spoke tension squeezes the rim. Past a point that squeeze makes the wheel softer sideways, and at the buckling tension the stiffness runs out. This is each build's lateral stiffness from no tension up to where it buckles.</Lead>
        {sweeps.every((s) => s.pts.length > 1) ? (
          <>
            <Softening sweeps={sweeps} tension={tension} narrow={narrow} />
            <Key items={[[lineSwatch(colors[0]), names[0]], [lineSwatch(colors[1], "7 5"), names[1]], [<b style={{ color: j.txt }}>×</b>, "buckling tension"]]} />
            <Readout>
              {sweeps.map((s, i) => (drop[i] != null
                ? `At ${fmt(tension)} kgf the ${HUB_SHORT[i]} has ${fmt(drop[i])}% less lateral stiffness than it would at zero tension (${fmt(s.here)} vs ${fmt(s.K0)} N/mm).`
                : `The ${HUB_SHORT[i]} is past its buckling tension at ${fmt(tension)} kgf.`)).join(" ")}
            </Readout>
          </>
        ) : <Readout color={j.warn}>No stiffness curve to draw at these settings.</Readout>}
        <Foot>Smeared-spoke lateral stiffness, the same as the Lab's Lateral Stiffness figure, at each drive-side tension. The curves stop at the discrete-spoke buckling tension the rest of the Lab uses. Ford notes that real wheels are hard to tension past about half their buckling tension, which he gives as the likely reason wheelbuilders rarely see this effect.</Foot>
      </Section>

      <Section title="TACO SHAPE" subtitle="which wave the rim buckles into">
        <Study eq={EQ.taco}>Ford, Papadopoulos &amp; Balogun (2016), "Buckling of the bicycle wheel", Proceedings of the 2016 Bicycle and Motorcycle Dynamics Conference.</Study>
        <Lead>Too much spoke tension buckles the rim into side-to-side waves: two waves is the classic potato chip, three or more is a wavy taco. Each wave count has its own buckling tension. The lowest one is the shape this rim would fold into first.</Lead>
        <div style={{ display: "flex", flexWrap: narrow ? "nowrap" : "wrap", gap: narrow ? 10 : 16, alignItems: "center", margin: "0 0 6px" }}>
          {lowN.map((m, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: narrow ? 4 : 8 }}>
              <TacoSketch n={m.n} size={narrow ? 72 : 110} color={colors[i]} />
              <div style={{ fontSize: 10.5, color: j.txt, fontFamily: MONO, lineHeight: 1.5 }}>
                <b>{HUB_SHORT[i]}</b>{`: ${m.n} waves`}<br />
                <span style={{ color: j.muted }}>{`at ${fmt(m.T_c_DS)} kgf`}</span>
              </div>
            </div>
          ))}
        </div>
        <TacoModes modes={modes} tension={tension} narrow={narrow} />
        <Key items={[
          [<i style={{ display: "inline-block", width: 14, height: 10, background: colors[0] }} />, names[0]],
          [<i style={{ display: "inline-block", width: 14, height: 10, border: `1.5px solid ${colors[1]}`, background: `repeating-linear-gradient(45deg, ${colors[1]} 0 2px, transparent 2px 4.5px)` }} />, names[1]],
        ]} />
        <Readout>
          {`Headline buckling tension (each spoke modelled separately, as on the other tabs): ${fmt(res[0].T_c)} kgf for the 148 and ${fmt(res[1].T_c)} kgf for the 157. The per-shape bars come from the paper's quick formula, which reads ${fmt((lowN[0].T_c_DS / res[0].T_c - 1) * 100)}% and ${fmt((lowN[1].T_c_DS / res[1].T_c - 1) * 100)}% higher, so use them for which shape comes first, not for when.`}
        </Readout>
        <Foot>Per-mode critical tension from the smeared, linear approximation inside bike-wheel-calc's <code>calc_buckling_tension</code>, given as the equivalent drive-side tension. Sketches show the rim seen at an angle, with the waves exaggerated; the dotted ring is the true rim.</Foot>
      </Section>

      <p style={{ fontSize: 9.5, color: j.muted, margin: "4px 0 0", lineHeight: 1.6 }}>
        All four come from Matthew Ford's Mode Matrix method (PhD thesis, Northwestern University, 2018) and his MIT-licensed bike-wheel-calc library, ported in wheel-physics-core and checked against his code to floating-point precision. 2.0 mm spokes and the Lab's stock rim throughout.
      </p>
    </div>
  );
}
