import * as React from "react";
import { theme as j } from "../theme-state.js";
import { computeWheelStrength, applyRimOffset, tightSideFirst } from "../physics.js";
import { HUBS_148, HUBS_157, PHYS_CONSTANTS } from "../data.js";
import Section from "./Section.jsx";
import ToggleGroup from "./ToggleGroup.jsx";
import { useNarrow } from "./HubFade.jsx";

// INSIGHTS: four extra outputs from Matthew Ford's work that the other tabs
// don't show. Each section names the study it comes from. All numbers come
// from wheel-physics-core (K_tor, nSP_rad, nSP_lat, K_lat at each tension,
// T_c_modes), which is checked against Ford's bike-wheel-calc to
// floating-point precision in its validation/insights/ folder.
//
//   1. Wind-up stiffness   Ford (2018) thesis, "Loading case II: tangential
//                          point load"; bike-wheel-calc calc_tor_stiff.
//   2. Spokes sharing a hit Ford (2018) thesis, Smith-Pippard number n_SP,
//                          after Hetenyi (1946), Smith (1901), Pippard (1931).
//   3. Tension softening   Ford (2018) thesis, "Lateral stiffness vs. spoke
//                          tension" (compared with Rinard's measurements).
//   4. Taco shape          Ford, Papadopoulos & Balogun (2016), "Buckling of
//                          the bicycle wheel": critical tension per mode n.

const MONO = "Space Mono, monospace", GROT = "Space Grotesk, system-ui";
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const HUB_SHORT = ["148", "157"];

/** Engine result for one hub at this build (rim offset applied, tighter side first, as everywhere in the Lab). */
function build(hub, erd, Ns, offset, tension) {
  const { EIL, EIR, GJ, EA_rim, modes } = PHYS_CONSTANTS;
  const g = tightSideFirst(applyRimOffset(hub, offset), erd, Ns);
  return computeWheelStrength(erd, g, 2, 2, Math.max(tension, 1e-9), EIL, EIR, GJ, EA_rim, Ns, modes);
}

/**
 * The STUDY block (MLA 9 works-cited entries), with an EQUATION button that opens the formula behind the
 * chart. `eq` = { lines: [JSX...], where: JSX, note?: JSX }.
 */
function Study({ cites, part, eq }) {
  const [open, setOpen] = React.useState(false);
  const id = React.useId();
  return (
    <div style={{ margin: "4px 0 10px" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10, borderLeft: `3px solid ${j.bdr}`, paddingLeft: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 10, color: j.txt, fontFamily: MONO, margin: 0, lineHeight: 1.6 }}>
            <b style={{ letterSpacing: "0.06em" }}>{cites.length > 1 ? "STUDIES" : "STUDY"}</b>
            {part && <span style={{ color: j.muted }}>{` · used here: ${part}`}</span>}
          </p>
          {cites.map((c, i) => (
            // MLA 9 works-cited entries, hanging indent
            <p key={i} style={{ fontSize: 10, color: j.txt, margin: "3px 0 0", lineHeight: 1.55, paddingLeft: 18, textIndent: -18 }}>{c}</p>
          ))}
        </div>
        {eq && (
          <button onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls={id}
            style={{ flex: "0 0 auto", padding: "3px 8px", borderRadius: 4, cursor: "pointer", border: `1px solid ${j.txt}`,
              background: open ? j.txt : "transparent", color: open ? j.surf : j.txt, fontFamily: MONO, fontSize: 9.5, fontWeight: 700, letterSpacing: "0.06em" }}>
            {open ? "EQUATION ▾" : "EQUATION ▸"}
          </button>
        )}
      </div>
      {eq && open && (
        <div id={id} style={{ margin: "8px 0 0", padding: "10px 12px", background: j.surfl, border: `1px solid ${j.bdr}`, borderRadius: 6 }}>
          {eq.lines.map((l, i) => (
            <div key={i} style={{ fontFamily: MONO, fontSize: 12, color: j.txt, lineHeight: 1.9, paddingLeft: 16, textIndent: -16, overflowWrap: "anywhere" }}>{l}</div>
          ))}
          <p style={{ fontSize: 10, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>{eq.where}</p>
          {eq.note && <p style={{ fontSize: 10, color: j.muted, margin: "6px 0 0", lineHeight: 1.6 }}>{eq.note}</p>}
        </div>
      )}
    </div>
  );
}

// The formula behind each chart, as wheel-physics-core's js/engine.js
// computes it, traced to Ford's thesis, his 2016 paper or bike-wheel-calc.
const Sb = ({ children }) => <sub>{children}</sub>, Sp = ({ children }) => <sup>{children}</sup>;
const EQ = {
  windup: {
    lines: [
      <>K<Sb>tor</Sb> = R² / C</>,
      <>C = 1 / (2πR·k̄<Sb>ww</Sb>) + Σ<Sb>n=1…24</Sb> K<Sb>vv</Sb> / (K<Sb>vv</Sb>K<Sb>ww</Sb> − K<Sb>vw</Sb>²)</>,
      <>K<Sb>vv</Sb> = πEI<Sb>rad</Sb>n⁴/R³ + πEA/R + πR·k̄<Sb>vv</Sb></>,
      <>K<Sb>ww</Sb> = πEI<Sb>rad</Sb>n²/R³ + πEA·n²/R + πR·k̄<Sb>ww</Sb></>,
      <>K<Sb>vw</Sb> = −(πEI<Sb>rad</Sb>n³/R³ + πEA·n/R)</>,
    ],
    where: <>R rim radius; EI<Sb>rad</Sb> rim in-plane bending stiffness; EA rim stretching stiffness; k̄<Sb>vv</Sb>, k̄<Sb>ww</Sb> smeared spoke stiffness per metre of rim, radial and tangential (tension included); n number of waves around the rim. Each wave shape acts as a spring and their give adds up (C). Shown per degree: K<Sb>tor</Sb>·π/180.</>,
    note: <>Ford's one-line shortcut (thesis Eq. Ktan), treating the rim as a rigid ring: K ≈ 2πR·k̄<Sb>ww</Sb>, tangential spoke stiffness alone.</>,
  },
  spread: {
    lines: [
      <>n<Sb>SP</Sb> = N<Sb>s</Sb> / (πR) · (4EI / k)<Sp>1/4</Sp></>,
      <>straight down: EI = EI<Sb>rad</Sb>, k = k̄<Sb>vv</Sb></>,
      <>sideways: EI = EI<Sb>lat</Sb>·μ/(μ+1), μ = GJ/EI<Sb>lat</Sb>, k = k̄<Sb>uu</Sb></>,
      <>curve: w(x) / w(0) = e<Sp>−βx</Sp>(cos βx + sin βx), β = (k / 4EI)<Sp>1/4</Sp></>,
    ],
    where: <>N<Sb>s</Sb> spoke count; R rim radius; EI<Sb>rad</Sb>, EI<Sb>lat</Sb> rim bending stiffness in-plane and sideways; GJ rim twisting stiffness; k̄<Sb>vv</Sb>, k̄<Sb>uu</Sb> smeared spoke stiffness per metre of rim, radial and sideways. The affected length is 2/β, and n<Sb>SP</Sb> counts the spokes inside it.</>,
    note: <>n<Sb>SP</Sb>: Ford's thesis, smeared spokes approximation. Curve: Hetényi (1946), beam on an elastic foundation. The sideways form follows bike-wheel-calc's calc_Pn_lat.</>,
  },
  soften: {
    lines: [
      <>K<Sb>lat</Sb> = 1 / C,   C = 1 / (2πR·k̄<Sb>uu</Sb>) + Σ<Sb>n=1…24</Sb> K<Sb>φφ</Sb> / (K<Sb>uu</Sb>K<Sb>φφ</Sb> − K<Sb>uφ</Sb>²)</>,
      <>K<Sb>uu</Sb> = πEI<Sb>lat</Sb>n⁴/R³ + πGJ·n²/R³ + πR·k̄<Sb>uu</Sb> − πn²·N<Sb>s</Sb>T̄/(2πR)</>,
      <>K<Sb>uφ</Sb> = −(πEI<Sb>lat</Sb>n²/R² + πGJ·n²/R²),   K<Sb>φφ</Sb> = πEI<Sb>lat</Sb>/R + πGJ·n²/R</>,
      <>k̄<Sb>uu</Sb> = Σ<Sb>spokes</Sb> [(EA/L)·c² + (T/L)·(1 − c²)] / (2πR)</>,
    ],
    where: <>R rim radius; EI<Sb>lat</Sb> rim sideways bending stiffness; GJ rim twisting stiffness; n number of side-to-side waves; T̄ average spoke tension (radial part); N<Sb>s</Sb> spoke count; for each spoke EA its stretch stiffness, L its length, T its tension and c the sideways share of its direction. Tension enters twice: (T/L)(1 − c²) is the spokes’ guitar-string stiffness and −πn²N<Sb>s</Sb>T̄/(2πR) is the rim being squeezed. The chart repeats this at each tension; K<Sb>lat</Sb> falls to zero at the buckling tension.</>,
    note: <>Ford’s thesis, Eq. Klat_series (modes in series) and the mode-matrix terms behind it, as in bike-wheel-calc’s calc_lat_stiff (smeared spokes, tension and buckling on, 24 modes).</>,
  },
  taco: {
    lines: [
      <>T<Sb>c,n</Sb> = (2πEI / (N<Sb>s</Sb>R²)) · t<Sb>c</Sb> / (n² − R·k<Sb>T</Sb>)</>,
      <>t<Sb>c</Sb> = λ<Sb>uu</Sb> + [μn²(n²−1)² + (n⁴+μn²)λ<Sb>φφ</Sb> + 2n²(μ+1)λ<Sb>uφ</Sb> − λ<Sb>uφ</Sb>²] / (1 + μn² + λ<Sb>φφ</Sb>)</>,
      <>μ = (GJ + EI<Sb>w</Sb>n²/R²) / EI,   λ<Sb>ij</Sb> = R⁴·k̄<Sb>ij</Sb> / EI</>,
    ],
    where: <>n number of waves; EI rim sideways bending stiffness; GJ rim twisting stiffness; EI<Sb>w</Sb> rim warping stiffness (0 here); k̄<Sb>uu</Sb>, k̄<Sb>uφ</Sb>, k̄<Sb>φφ</Sb> smeared spoke stiffness against sideways movement and rim twist; k<Sb>T</Sb> spoke tension-stiffness. The lowest T<Sb>c,n</Sb> sets the shape. Shown as the equivalent drive-side tension.</>,
    note: <>Ford, Papadopoulos &amp; Balogun (2016), linear approximation, as in bike-wheel-calc's calc_buckling_tension(approx='linear').</>,
  },
  pitch: {
    lines: [
      <>f = (1 / 2L) · √(T / k)</>,
      <>= (1 / 2L) · √(σ / ρ),   σ = T / A</>,
      <>Allen's table: f(L) at σ = 350 MPa, measured; each semitone ≈ 12.25% more tension</>,
      <>here: f = f<Sb>table</Sb>(L) · √(σ / 350 MPa) · 2<Sp>−2/12</Sp></>,
    ],
    where: <>L spoke length; T tension; k mass per metre of spoke; A cross-section area; ρ steel density; σ stress in the spoke. Because k and T both scale with A, pitch depends only on stress, so any gauge at the right stress plays the same note. Allen's Table 1 gives the pitch he measured for each spoke length, which is a little higher than the plain formula because the spoke's ends are held stiff and it resists bending; the last factor drops two semitones for plain-gauge spokes, as he advises.</>,
    note: <>Allen (1984), Bike Tech 3(4), Table 1, interpolated between his rows. Spoke length: the standard 3-cross formula from ERD/2 to the flange hole, less half a 2.4 mm hole.</>,
  },
};

const Lead = ({ children }) => <p style={{ fontSize: 10.5, color: j.muted, margin: "0 0 12px", lineHeight: 1.6 }}>{children}</p>;
const Foot = ({ children }) => <p style={{ fontSize: 9.5, color: j.muted, margin: "10px 0 0", lineHeight: 1.6 }}>{children}</p>;
const Readout = ({ children, color }) => (
  <p style={{ fontSize: 11, color: color || j.txt, margin: "10px 0 0", lineHeight: 1.6 }}>{children}</p>
);
const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };
function Key({ items }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 0", fontFamily: MONO }}>
      {items.map(([sw, label]) => <span key={label} style={keyRow}>{sw}{label}</span>)}
    </div>
  );
}
const lineSwatch = (color, dash) => (
  <svg width={22} height={6} aria-hidden="true"><line x1={1} x2={21} y1={3} y2={3} stroke={color} strokeWidth={2.4} strokeDasharray={dash || "none"} /></svg>
);
// Text over lines gets a halo in the panel color.
const halo = () => ({ stroke: j.surf, strokeWidth: 4, paintOrder: "stroke", strokeLinejoin: "round" });

// ---------------------------------------------------------------- 1. wind-up
function WindUp({ all, sel, narrow }) {
  const rows = [...all].sort((a, b) => b.K_tor - a.K_tor);
  const max = Math.max(...rows.map((r) => r.K_tor));
  const W = narrow ? 420 : 680, L = narrow ? 8 : 230, Rm = 52, rowH = narrow ? 30 : 17, top = 8;
  const H = top + rows.length * rowH + 8;
  const X = (v) => L + v / max * (W - L - Rm);
  const colors = [j.h148, j.h157];
  const txt = { fontFamily: MONO, fontSize: narrow ? 11 : 10 };
  const mark = (r, cx, cy, fill) => (r.std === 0
    ? <circle cx={cx} cy={cy} r={4} fill={fill} />
    : <rect x={cx - 4} y={cy - 4} width={8} height={8} fill={fill} />);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Wind-up stiffness of every hub in the catalogue, ranked"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {rows.map((r, i) => {
        const s = sel.indexOf(r.id), on = s >= 0;
        const y = top + i * rowH, barY = narrow ? y + 15 : y + 4, bh = on ? 10 : 6;
        const fill = on ? colors[s] : j.muted;
        const nameX = narrow ? L + 14 : L - 10, nameY = narrow ? y + 11 : y + 12;
        return (
          <g key={r.id}>
            {mark(r, narrow ? L + 4 : L - 222 + 4, narrow ? nameY - 4 : nameY - 4, fill)}
            <text {...txt} x={narrow ? nameX : L - 208} y={nameY} fill={on ? j.txt : j.muted} fontWeight={on ? 700 : 400}>
              {r.name}
            </text>
            {/* Other hubs: thin outlined bars. Your two hubs: thick solid bars, so they
                stand out by shape as well as color in every theme. */}
            <rect x={L + (on ? 0 : 0.5)} y={barY + (on ? 0 : 2)} width={X(r.K_tor) - L - (on ? 0 : 1)} height={bh}
              fill={on ? fill : "none"} stroke={on ? "none" : j.muted} strokeWidth={1} />
            <text {...txt} x={X(r.K_tor) + 6} y={barY + 8} fill={on ? j.txt : j.muted} fontWeight={on ? 700 : 400}>{fmt(r.K_tor)}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 2. affected length
function AffectedLength({ nsp, narrow, dir }) {
  const E = narrow ? { l: 40, r: 10, t: 16, b: 74, w: 420, h: 300 } : { l: 48, r: 18, t: 18, b: 70, w: 680, h: 300 };
  const span = Math.max(6, Math.ceil(Math.max(...nsp) * 1.4));
  const X = (u) => E.l + (u + span) / (2 * span) * (E.w - E.l - E.r);
  const ymin = -0.15, Y = (v) => E.t + (1 - v) / (1 - ymin) * (E.h - E.t - E.b);
  const colors = [j.h148, j.h157], dash = ["none", "7 5"];
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 12 : 11 };
  // Hetenyi's infinite beam on an elastic foundation under a point load:
  // w(x) / w(0) = e^(-bx)(cos bx + sin bx). In spoke spacings the affected
  // length 2/b holds n_SP spokes, so b*x = 2|u| / n_SP.
  const curve = (n) => {
    const p = [];
    for (let k = 0; k <= 240; k++) {
      const u = -span + 2 * span * k / 240, a = 2 * Math.abs(u) / n;
      p.push(`${X(u)},${Y(Math.exp(-a) * (Math.cos(a) + Math.sin(a)))}`);
    }
    return p.join(" ");
  };
  const ticks = [];
  for (let u = -span; u <= span; u++) ticks.push(u);
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label={`How far a ${dir} hit spreads along the rim, in spoke spacings`}
      style={{ display: "block", width: "100%", height: "auto" }}>
      {[0, 0.5, 1].map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 6} y={Y(v) + 4} textAnchor="end">{v === 0 ? "0" : v === 1 ? "max" : "½"}</text>
        </g>
      ))}
      {ticks.map((u) => (
        <g key={u}>
          {/* one short stroke per spoke along the rim */}
          <line x1={X(u)} x2={X(u)} y1={Y(ymin)} y2={Y(ymin) + 7} stroke={j.muted} strokeWidth={1.4} />
          {(u % 2 === 0) && <text {...txt} x={X(u)} y={Y(ymin) + 20} textAnchor="middle">{Math.abs(u)}</text>}
        </g>
      ))}
      <text {...txt} x={(E.l + E.w - E.r) / 2} y={Y(ymin) + 36} textAnchor="middle">spokes from the hit</text>
      <text {...txt} x={X(0)} y={E.t - 4} textAnchor="middle" fontWeight={700} fill={j.txt}>▼ hit</text>
      {nsp.map((n, i) => (
        <polyline key={i} points={curve(n)} fill="none" stroke={colors[i]} strokeWidth={2.4} strokeDasharray={dash[i]} />
      ))}
      {nsp.map((n, i) => {
        const y = E.h - 22 + i * 12;
        return (
          <g key={"b" + i}>
            <line x1={X(-n / 2)} x2={X(n / 2)} y1={y} y2={y} stroke={colors[i]} strokeWidth={3} strokeDasharray={dash[i] === "none" ? "none" : "5 3"} />
            <line x1={X(-n / 2)} x2={X(-n / 2)} y1={y - 4} y2={y + 4} stroke={colors[i]} strokeWidth={2} />
            <line x1={X(n / 2)} x2={X(n / 2)} y1={y - 4} y2={y + 4} stroke={colors[i]} strokeWidth={2} />
            <text {...txt} x={X(n / 2) + 8} y={y + 4} fill={j.txt} style={halo()}>{`${HUB_SHORT[i]}: ${fmt(n, 1)} spokes`}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 3. tension softening
function Softening({ sweeps, tension, narrow }) {
  const E = narrow ? { l: 46, r: 12, t: 18, b: 48, w: 420, h: 340 } : { l: 56, r: 24, t: 20, b: 48, w: 680, h: 340 };
  const xm = Math.ceil(Math.max(...sweeps.map((s) => s.T_c), tension) * 1.08 / 25) * 25;
  const ym = Math.ceil(Math.max(...sweeps.flatMap((s) => s.pts.map((p) => p[1]))) * 1.12 / 20) * 20;
  const X = (v) => E.l + v / xm * (E.w - E.l - E.r), Y = (v) => E.h - E.b - v / ym * (E.h - E.t - E.b);
  const colors = [j.h148, j.h157], dash = ["none", "7 5"];
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 12 : 11 };
  const xs = [], ys = [];
  const xstep = xm > 200 ? 50 : 25;
  for (let v = 0; v <= xm; v += xstep) xs.push(v);
  for (let v = 0; v <= ym; v += 20) ys.push(v);
  const yl = narrow ? 12 : 14, ym2 = (E.t + E.h - E.b) / 2;
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label="Lateral stiffness against drive-side spoke tension for both hubs"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {ys.map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 8} y={Y(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      {xs.map((v) => (
        <g key={v}>
          <line x1={X(v)} x2={X(v)} y1={E.t} y2={E.h - E.b} stroke={j.bdr} strokeWidth={v ? 0.6 : 1.5} />
          <text {...txt} x={X(v)} y={E.h - E.b + 16} textAnchor="middle">{v}</text>
        </g>
      ))}
      <text {...txt} x={E.w - E.r} y={E.h - 8} textAnchor="end">drive-side spoke tension (kgf)</text>
      <text {...txt} x={yl} y={ym2} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym2})`}>lateral stiffness (N/mm)</text>
      <line x1={X(tension)} x2={X(tension)} y1={E.t} y2={E.h - E.b} stroke={j.txt} strokeWidth={1} strokeDasharray="2 3" />
      <text {...txt} x={X(tension) + 5} y={E.t + 10} fill={j.txt} style={halo()}>{`your ${fmt(tension)} kgf`}</text>
      {sweeps.map((s, i) => (
        <polyline key={i} points={s.pts.map(([x, y]) => `${X(x)},${Y(y)}`).join(" ")} fill="none" stroke={colors[i]} strokeWidth={2.4} strokeDasharray={dash[i]} />
      ))}
      {sweeps.map((s, i) => {
        const [ex, ey] = s.pts[s.pts.length - 1];
        return (
          <g key={"e" + i}>
            <path d={`M${X(ex) - 5},${Y(ey) - 5}L${X(ex) + 5},${Y(ey) + 5}M${X(ex) - 5},${Y(ey) + 5}L${X(ex) + 5},${Y(ey) - 5}`} stroke={colors[i]} strokeWidth={2.4} />
            <text {...txt} x={X(ex) - 8} y={Y(ey) + (i ? -10 : 18)} textAnchor="end" fill={j.txt} style={halo()}>{`${HUB_SHORT[i]} buckles ${fmt(s.T_c)}`}</text>
            {s.here != null && tension < s.T_c && (
              <circle cx={X(tension)} cy={Y(s.here)} r={5.5} fill={colors[i]} stroke={j.surf} strokeWidth={2} />
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ---------------------------------------------------------------- 4. taco shape
/** The rim seen at an angle, bent into n side-to-side waves. */
function TacoSketch({ n, size = 120, color }) {
  const c = size / 2, rx = size * 0.42, ry = size * 0.17, a = size * 0.1;
  const pts = (amp) => {
    const p = [];
    for (let k = 0; k <= 180; k++) {
      const th = k / 180 * 2 * Math.PI;
      p.push(`${c + rx * Math.cos(th)},${c + ry * Math.sin(th) - amp * Math.cos(n * th)}`);
    }
    return p.join(" ");
  };
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden="true" style={{ display: "block", flex: "0 0 auto" }}>
      <polyline points={pts(0)} fill="none" stroke={j.muted} strokeWidth={1} strokeDasharray="2 3" />
      <polyline points={pts(a)} fill="none" stroke={color} strokeWidth={2.4} />
    </svg>
  );
}

function TacoModes({ modes, tension, narrow }) {
  const E = narrow ? { l: 46, r: 10, t: 22, b: 92, w: 420, h: 340 } : { l: 56, r: 16, t: 24, b: 92, w: 680, h: 340 };
  const ns = modes[0].map((m) => m.n);
  const all = modes.flatMap((ms) => ms.map((m) => m.T_c_DS));
  const ym = Math.ceil(Math.max(...all, tension) * 1.1 / 100) * 100;
  const Y = (v) => E.h - E.b - v / ym * (E.h - E.t - E.b);
  const gw = (E.w - E.l - E.r) / ns.length, bw = Math.min(30, gw * 0.3);
  const colors = [j.h148, j.h157];
  const lows = modes.map((ms) => ms.reduce((a, b) => (b.T_c_DS < a.T_c_DS ? b : a)).n);
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 11.5 : 11 };
  const ys = [];
  for (let v = 0; v <= ym; v += 100) ys.push(v);
  const yl = narrow ? 12 : 14, ym2 = (E.t + E.h - E.b) / 2;
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label="Spoke tension that buckles the rim into each wave shape, both hubs"
      style={{ display: "block", width: "100%", height: "auto" }}>
      <defs>
        <pattern id="ins-hatch157" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="6" height="6" fill={j.surf} />
          <rect width="3.2" height="6" fill={j.h157} />
        </pattern>
      </defs>
      {ys.map((v) => (
        <g key={v}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(v)} y2={Y(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.5} />
          <text {...txt} x={E.l - 8} y={Y(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      <text {...txt} x={yl} y={ym2} textAnchor="middle" transform={`rotate(-90 ${yl} ${ym2})`}>drive-side tension (kgf)</text>
      {ns.map((n, k) => {
        const cx = E.l + gw * (k + 0.5);
        return (
          <g key={n}>
            {modes.map((ms, i) => {
              const v = ms[k].T_c_DS, x = cx + (i ? 2 : -bw - 2), low = lows[i] === n;
              return (
                <g key={i}>
                  <rect x={x} y={Y(v)} width={bw} height={Y(0) - Y(v)} fill={i ? "url(#ins-hatch157)" : colors[0]} stroke={colors[i]} strokeWidth={1.5} />
                  <text {...txt} x={x + bw / 2} y={Y(v) - 5} textAnchor="middle" fill={j.txt} fontWeight={low ? 700 : 400} fontSize={narrow ? 10 : 10.5} style={halo()}>
                    {fmt(v)}
                  </text>
                </g>
              );
            })}
            <g transform={`translate(${cx - 22},${Y(0) + 4})`}>
              <TacoSketchInline n={n} />
            </g>
            <text {...txt} x={cx} y={Y(0) + 62} textAnchor="middle" fill={lows.includes(n) ? j.txt : j.muted} fontWeight={lows.includes(n) ? 700 : 400}>
              {`${n} waves`}
            </text>
            {lows.includes(n) && <text {...txt} x={cx} y={Y(0) + 78} textAnchor="middle" fill={j.txt} fontWeight={700}>LOWEST</text>}
          </g>
        );
      })}
      <line x1={E.l} x2={E.w - E.r} y1={Y(tension)} y2={Y(tension)} stroke={j.txt} strokeWidth={1} strokeDasharray="2 3" />
      <text {...txt} x={E.w - E.r} y={Y(tension) - 5} textAnchor="end" fill={j.txt} style={halo()}>{`your ${fmt(tension)} kgf`}</text>
    </svg>
  );
}
// Small inline version of TacoSketch for the bar chart's x axis (44 px).
function TacoSketchInline({ n }) {
  const s = 44, c = s / 2, rx = 19, ry = 7, a = 4.5;
  const p = (amp) => {
    const q = [];
    for (let k = 0; k <= 120; k++) {
      const th = k / 120 * 2 * Math.PI;
      q.push(`${c + rx * Math.cos(th)},${c + ry * Math.sin(th) - amp * Math.cos(n * th)}`);
    }
    return q.join(" ");
  };
  return <polyline points={p(a)} fill="none" stroke={j.muted} strokeWidth={1.4} />;
}

// ---------------------------------------------------------------- 5. spoke pitch
// John S. Allen (1984), "A Musical Test for Correct Spoke Tension", Bike Tech
// 3(4). A plucked spoke is a string: f = (1/2L)·√(T/k). Pitch depends on
// stress (T per cross-section area), not on gauge. His Table 1 gives the
// measured pitch for each spoke length at 3.5e9 dyn/cm² (350 MPa), already
// corrected for the stiff ends and bending stiffness, for double-butted
// spokes; plain-gauge spokes sound two semitones lower. Pitch here = that
// table (interpolated on log length), moved by √(stress ratio) to the
// build's tension, minus two semitones for the Lab's 2.0 mm plain spokes.
const ALLEN_TABLE = [ // [spoke length mm, MIDI note]  (G4 = 67, A4 = 69)
  [326, 67], [308, 68], [292, 69], [276, 70], [262, 71], [248, 72], [236, 73], [224, 74],
  [212, 75], [201, 76], [191, 77], [181, 78], [172, 79], [163, 80], [156, 81], [147, 82],
];
const ALLEN_STRESS = 350;            // MPa, = 3.5e9 dyn/cm², about 50,000 psi
const SPOKE_AREA = Math.PI * 1 * 1;  // mm², 2.0 mm plain spoke
const NOTE = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"];
const noteName = (m) => { const r = Math.round(m); return NOTE[((r % 12) + 12) % 12] + (Math.floor(r / 12) - 1); };
const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
const cents = (m) => Math.round((m - Math.round(m)) * 100);
/** MIDI pitch of Allen's table at length L (mm), interpolated on log length; extrapolated past the ends. */
function tableMidi(L) {
  const t = ALLEN_TABLE, x = Math.log(L);
  let i = t.findIndex(([l]) => l <= L);
  if (i === -1) i = t.length - 1;   // shorter than 147 mm: last segment
  else if (i === 0) i = 1;          // 326 mm or longer: first segment
  const [l0, m0] = t[i - 1], [l1, m1] = t[i];
  return m0 + (x - Math.log(l0)) / (Math.log(l1) - Math.log(l0)) * (m1 - m0);
}
/** Allen-corrected pitch (MIDI, fractional) of a plain 2.0 mm spoke of length L (mm) at tension T (kgf). */
const pitchMidi = (L, T) => tableMidi(L) + 6 * Math.log2((T * 9.81 / SPOKE_AREA) / ALLEN_STRESS) - 2;
/** Standard 3-cross spoke length (mm): ERD/2 to the flange hole, less half a 2.4 mm hole. */
function spokeLength(erd, offset, pcd, Ns) {
  const R = erd / 2, r = pcd / 2, a = 4 * Math.PI * 3 / Ns;
  return Math.sqrt(offset * offset + r * r + R * R - 2 * r * R * Math.cos(a)) - 1.2;
}

function PitchChart({ sides, color, narrow }) {
  const E = narrow ? { l: 44, r: 12, t: 16, b: 46, w: 420, h: 340 } : { l: 52, r: 24, t: 18, b: 46, w: 680, h: 340 };
  const T0 = 20, T1 = 200;
  const mids = sides.flatMap((s) => [pitchMidi(s.L, T0), pitchMidi(s.L, T1)]);
  const m0 = Math.floor(Math.min(...mids)) - 1, m1 = Math.ceil(Math.max(...mids)) + 1;
  const X = (T) => E.l + (T - T0) / (T1 - T0) * (E.w - E.l - E.r);
  const Y = (m) => E.h - E.b - (m - m0) / (m1 - m0) * (E.h - E.t - E.b);
  const txt = { fill: j.muted, fontFamily: MONO, fontSize: narrow ? 11.5 : 11 };
  const naturals = [];
  for (let m = m0; m <= m1; m++) if (!NOTE[((m % 12) + 12) % 12].includes("♯")) naturals.push(m);
  const tOpt = ALLEN_STRESS * SPOKE_AREA / 9.81;
  const dash = ["none", "7 5"];
  return (
    <svg viewBox={`0 0 ${E.w} ${E.h}`} role="img" aria-label="Spoke pitch against spoke tension, drive and non-drive side"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {naturals.map((m) => (
        <g key={m}>
          <line x1={E.l} x2={E.w - E.r} y1={Y(m)} y2={Y(m)} stroke={j.bdr} strokeWidth={NOTE[((m % 12) + 12) % 12] === "C" ? 1.5 : 0.8} />
          <text {...txt} x={E.l - 6} y={Y(m) + 4} textAnchor="end">{noteName(m)}</text>
        </g>
      ))}
      {[25, 50, 75, 100, 125, 150, 175, 200].map((v) => (
        <g key={v}>
          <line x1={X(v)} x2={X(v)} y1={E.t} y2={E.h - E.b} stroke={j.bdr} strokeWidth={0.6} />
          <text {...txt} x={X(v)} y={E.h - E.b + 16} textAnchor="middle">{v}</text>
        </g>
      ))}
      <text {...txt} x={E.w - E.r} y={E.h - 8} textAnchor="end">spoke tension (kgf)</text>
      <line x1={X(tOpt)} x2={X(tOpt)} y1={E.t} y2={E.h - E.b} stroke={j.txt} strokeWidth={1} strokeDasharray="2 3" />
      <text {...txt} x={X(tOpt) + 5} y={E.t + 10} fill={j.txt} style={halo()}>{`Allen's optimum ≈ ${fmt(tOpt)} kgf`}</text>
      {sides.map((s, i) => {
        const pts = [];
        for (let T = T0; T <= T1; T += 2) pts.push(`${X(T)},${Y(pitchMidi(s.L, T))}`);
        return <polyline key={i} points={pts.join(" ")} fill="none" stroke={color} strokeWidth={2.4} strokeDasharray={dash[i]} />;
      })}
      {sides.map((s, i) => {
        const m = pitchMidi(s.L, s.T), x = X(Math.min(T1, Math.max(T0, s.T))), y = Y(m);
        return (
          <g key={"d" + i}>
            <circle cx={x} cy={y} r={6} fill={i ? j.surf : color} stroke={color} strokeWidth={2.4} />
            <text {...txt} x={x + 10} y={y + (i ? 16 : -8)} fill={j.txt} fontWeight={700} style={halo()}>{`${s.label} ${noteName(m)}`}</text>
          </g>
        );
      })}
    </svg>
  );
}

// Piano keys keep piano colors in every theme so the keyboard never reads inverted.
const KEY = { white: "#F6F4EF", black: "#24201D", edge: "#7A746E", label: "#4A4440" };

/** A keyboard covering the notes in play, with each hub/side marked at its exact pitch. */
function Keyboard({ marks, narrow }) {
  const ms = marks.map((k) => k.m);
  let lo = Math.floor(Math.min(...ms)) - 2, hi = Math.ceil(Math.max(...ms)) + 2;
  while (hi - lo < 17) { lo--; hi++; }
  const isBlack = (m) => NOTE[((m % 12) + 12) % 12].includes("♯");
  while (isBlack(lo)) lo--;
  while (isBlack(hi)) hi++;
  const whites = [];
  for (let m = lo; m <= hi; m++) if (!isBlack(m)) whites.push(m);
  const W = narrow ? 420 : 680, padL = 6, kw = (W - 2 * padL) / whites.length, top = 52, kh = narrow ? 64 : 70;
  const wx = (m) => padL + whites.indexOf(m) * kw;
  // centre x of any (fractional) MIDI pitch
  const px = (m) => {
    const r = Math.floor(m), f = m - r;
    const cx = (k) => (isBlack(k) ? wx(k - 1) + kw : wx(k) + kw / 2);
    return cx(r) + f * (cx(r + 1) - cx(r));
  };
  const txt = { fontFamily: MONO, fontSize: narrow ? 11 : 10.5 };
  const rows = [0, 1].map((h) => marks.filter((k) => k.hub === h));
  return (
    <svg viewBox={`0 0 ${W} ${top + kh + 22}`} role="img" aria-label="Keyboard showing the note of each side's spokes for both hubs"
      style={{ display: "block", width: "100%", height: "auto" }}>
      {whites.map((m) => (
        <g key={m}>
          <rect x={wx(m)} y={top} width={kw} height={kh} fill={KEY.white} stroke={KEY.edge} strokeWidth={1} />
          {NOTE[((m % 12) + 12) % 12] === "C" && <text {...txt} x={wx(m) + kw / 2} y={top + kh - 6} textAnchor="middle" fill={KEY.label}>{noteName(m)}</text>}
        </g>
      ))}
      {whites.map((m) => (isBlack(m + 1) && m + 1 <= hi ? (
        <rect key={"b" + m} x={wx(m) + kw * 0.68} y={top} width={kw * 0.64} height={kh * 0.6} fill={KEY.black} />
      ) : null))}
      {rows.map((row, h) => row.map((k) => {
        const x = px(k.m), y = h ? 36 : 14, size = 6;
        const shape = h === 0
          ? <circle cx={x} cy={y} r={size} fill={k.side ? j.surf : k.color} stroke={k.color} strokeWidth={2.2} />
          : <rect x={x - size} y={y - size} width={2 * size} height={2 * size} fill={k.side ? j.surf : k.color} stroke={k.color} strokeWidth={2.2} />;
        return (
          <g key={`${h}${k.side}`}>
            <line x1={x} x2={x} y1={y + size} y2={top + 4} stroke={k.color} strokeWidth={1.4} strokeDasharray={k.side ? "3 2" : "none"} />
            {shape}
            <text {...txt} x={x + (k.side ? -10 : 10)} y={y + 4} textAnchor={k.side ? "end" : "start"} fill={j.txt} fontWeight={700} style={halo()}>
              {`${HUB_SHORT[h]} ${k.side ? "NDS" : "DS"}`}
            </text>
          </g>
        );
      }))}
    </svg>
  );
}

function SpokePitch({ hubs, names, erd, spokes, offset, tension, narrow }) {
  const [which, setWhich] = React.useState(0);
  const colors = [j.h148, j.h157];
  const data = hubs.map((h) => {
    const a = applyRimOffset(h, offset), g = tightSideFirst(a, erd, spokes), swapped = g !== a;
    const r = build(h, erd, spokes, offset, tension);
    const tDS = swapped ? r.T_NDS : tension, tNDS = swapped ? tension : r.T_NDS;
    return [
      { label: "DS", L: spokeLength(erd, a.ds, a.pds, spokes), T: tDS },
      { label: "NDS", L: spokeLength(erd, a.nds, a.pnds, spokes), T: tNDS },
    ].map((s) => ({ ...s, m: pitchMidi(s.L, s.T) }));
  });
  const marks = data.flatMap((sides, hub) => sides.map((s, side) => ({ hub, side, m: s.m, color: colors[hub] })));
  const d = data[which];
  const gap = d[0].m - d[1].m;
  const say = (s) => `${s.label} spokes (${fmt(s.L)} mm) at ${fmt(s.T)} kgf ring at about ${noteName(s.m)} (${fmt(hz(s.m))} Hz${cents(s.m) ? `, ${cents(s.m) > 0 ? "+" : ""}${cents(s.m)} cents` : ""})`;
  return (
    <>
      <div style={{ display: "flex", flexWrap: "wrap", gap: "10px 14px", marginBottom: 8 }}>
        <ToggleGroup label="HUB" opts={["148x12", "157x12"]} val={["148x12", "157x12"][which]} set={(v) => setWhich(v === "148x12" ? 0 : 1)} activeColor={colors[which]} />
      </div>
      <div style={{ fontFamily: GROT, fontWeight: 700, fontSize: narrow ? 17 : 20, lineHeight: 1.2, color: colors[which], margin: "2px 0 4px" }}>{names[which]}</div>
      <PitchChart sides={d} color={colors[which]} narrow={narrow} />
      <Key items={[[lineSwatch(colors[which]), "drive side (DS)"], [lineSwatch(colors[which], "7 5"), "non-drive side (NDS)"]]} />
      <Readout>{`${say(d[0])}; ${say(d[1])}. That is ${fmt(gap, 1)} semitones apart: the tension gap between the sides, heard. The two curves nearly overlap because both sides' spokes are almost the same length; what separates the notes is tension.`}</Readout>
      <div style={{ margin: "14px 0 0" }}>
        <Keyboard marks={marks} narrow={narrow} />
        <Key items={[
          [<svg width={12} height={12} aria-hidden="true"><circle cx={6} cy={6} r={5} fill={colors[0]} /></svg>, `148 (${names[0]})`],
          [<svg width={12} height={12} aria-hidden="true"><rect x={1} y={1} width={10} height={10} fill={colors[1]} /></svg>, `157 (${names[1]})`],
          [<svg width={12} height={12} aria-hidden="true"><circle cx={6} cy={6} r={4.5} fill="none" stroke={j.muted} strokeWidth={2} /></svg>, "hollow = non-drive side"],
        ]} />
      </div>
    </>
  );
}

// ---------------------------------------------------------------- tab
/** hubs = [hub148, hub157] from the main picker; erd, spokes, tension, offset as elsewhere. */
export default function InsightsTab({ hubs, erd, spokes, tension, offset }) {
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, true);
  const [dir, setDir] = React.useState("SIDEWAYS");
  const colors = [j.h148, j.h157];
  const sel = hubs.map((h) => h.id);

  const data = React.useMemo(() => {
    const res = hubs.map((h) => build(h, erd, spokes, offset, tension));
    const all = [...HUBS_148.map((h) => ({ ...h, std: 0 })), ...HUBS_157.map((h) => ({ ...h, std: 1 }))]
      .map((h) => ({ id: h.id, name: h.name, std: h.std, K_tor: build(h, erd, spokes, offset, tension).K_tor }));
    const sweeps = hubs.map((h, i) => {
      const T_c = res[i].T_c, pts = [], steps = 60;
      for (let k = 0; k <= steps; k++) {
        const T = T_c * k / steps, K = build(h, erd, spokes, offset, T).K_lat;
        if (!(K > 0)) break;
        pts.push([T, K]);
      }
      return { T_c, pts, here: tension < T_c ? res[i].K_lat : null, K0: pts.length ? pts[0][1] : NaN };
    });
    return { res, all, sweeps };
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);

  const { res, all, sweeps } = data;
  const allSorted = [...all].sort((a, b) => b.K_tor - a.K_tor);
  const rank = (id) => allSorted.findIndex((r) => r.id === id) + 1;
  const R = res[0].R_rim / 1000;   // m, same rim for both hubs
  const creep = (K) => 100 / K * Math.PI / 180 * R * 1000;   // mm of rim travel per 100 N·m
  const nsp = res.map((r) => (dir === "SIDEWAYS" ? r.nSP_lat : r.nSP_rad));
  const modes = res.map((r) => r.T_c_modes);
  const lowN = modes.map((ms) => ms.reduce((a, b) => (b.T_c_DS < a.T_c_DS ? b : a)));
  const past = res.map((r) => !(r.T_safety < 100));
  const drop = sweeps.map((s) => (s.here != null ? (1 - s.here / s.K0) * 100 : null));
  const names = hubs.map((h) => h.name);

  return (
    <div ref={wrap}>
      <p style={{ fontSize: 11, color: j.muted, margin: "0 0 12px", lineHeight: 1.6 }}>
        Five more results the other tabs don't show: four from Matthew Ford's work on bicycle wheels and one from John S. Allen's 1984 spoke-pitch test, for your two hubs at the current rim, spoke count, tension and offset. Each one names the study it comes from. The numbers come from the same validated engine as the rest of the Lab, checked against Ford's own bike-wheel-calc code; the pitch chart uses Allen's published table.
      </p>
      {(past[0] || past[1]) && (
        <p style={{ fontSize: 11.5, color: j.warn, margin: "0 0 12px", lineHeight: 1.6 }}>
          {past[0] && past[1] ? "Both builds are" : past[0] ? "The 148 build is" : "The 157 build is"} at or past the rim's buckling tension at these settings, so the stiffness numbers below describe a wheel that would not stay true.
        </p>
      )}

      <Section title="WIND-UP STIFFNESS" subtitle="pedaling + disc-brake torque">
        <Study eq={EQ.windup} part="ch. 2, “Loading case II: tangential point load”" cites={[<>Ford, Matthew. <i>Reinventing the Wheel: Stress Analysis, Stability, and Optimization of the Bicycle Wheel</i>. 2018. Northwestern University, PhD dissertation.</>]} />
        <Lead>Pedaling and disc braking twist the hub against the rim. Wind-up stiffness is how hard the spokes resist that twist: torque per degree of rim rotation relative to the hub. Higher means less wind-up. It depends mostly on flange diameter, so it ranks hubs differently from lateral stiffness.</Lead>
        <WindUp all={all} sel={sel} narrow={narrow} />
        <Key items={[
          [<svg width={10} height={10} aria-hidden="true"><circle cx={5} cy={5} r={4} fill={j.muted} /></svg>, "148x12"],
          [<svg width={10} height={10} aria-hidden="true"><rect x={1} y={1} width={8} height={8} fill={j.muted} /></svg>, "157x12"],
          [<i style={{ display: "inline-block", width: 18, height: 8, background: `linear-gradient(90deg, ${j.h148} 50%, ${j.h157} 50%)` }} />, "thick solid bars: your two hubs"],
        ]} />
        <Readout>
          {res.map((r, i) => `${names[i]}: ${fmt(r.K_tor)} N·m per degree, #${rank(sel[i])} of ${all.length}; 100 N·m of torque moves its rim ${fmt(creep(r.K_tor), 2)} mm relative to the hub.`).join(" ")}
        </Readout>
        <Foot>Smeared-spoke Mode Matrix, units N·m per degree of rim rotation. Spokes are modelled as 3-cross; radial spokes would have almost no wind-up stiffness. Hub-shell and freehub twist are not included.</Foot>
      </Section>

      <Section title="SPOKES SHARING A HIT" subtitle="how far a point load spreads">
        <Study eq={EQ.spread} part="Ford ch. 2, “Smeared spokes approximation” (the Smith-Pippard number), built on Hetényi, Smith and Pippard & Francis" cites={[<>Ford, Matthew. <i>Reinventing the Wheel: Stress Analysis, Stability, and Optimization of the Bicycle Wheel</i>. 2018. Northwestern University, PhD dissertation.</>,
          <>Hetényi, M. <i>Beams on Elastic Foundation</i>. U of Michigan P, 1946.</>,
          <>Smith, Bernard A. “The Bicycle Wheel.” <i>Report of the Meeting of the Australasian Association for the Advancement of Science</i>, vol. 8, 1901, pp. 197–203.</>,
          <>Pippard, A. J. S., and W. E. Francis. “On a Theoretical and Experimental Investigation of the Stresses in a Radially Spoked Wire Wheel under Loads Applied to the Rim.” <i>Philosophical Magazine</i>, vol. 11, no. 69, 1931, pp. 233–85, https://doi.org/10.1080/14786443109461681.</>]} />
        <Lead>A bump or a sideways push at the tire does not load one spoke. The rim spreads it over a short stretch, like a rail on its sleepers. The bracket shows how many spokes sit inside that stretch. Fewer spokes means each one takes a bigger share of the hit.</Lead>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "10px 14px", marginBottom: 8 }}>
          <ToggleGroup label="HIT" opts={["SIDEWAYS", "STRAIGHT DOWN"]} val={dir} set={setDir} activeColor={j.acc} />
        </div>
        <AffectedLength nsp={nsp} narrow={narrow} dir={dir === "SIDEWAYS" ? "sideways" : "straight-down"} />
        <Key items={[[lineSwatch(colors[0]), names[0]], [lineSwatch(colors[1], "7 5"), names[1]]]} />
        <Readout>
          {dir === "SIDEWAYS"
            ? `A sideways hit spreads over ${fmt(nsp[0], 1)} spokes on the ${names[0]} and ${fmt(nsp[1], 1)} on the ${names[1]}.`
            : `A straight-down hit spreads over ${fmt(nsp[0], 2)} spokes on the ${names[0]} and ${fmt(nsp[1], 2)} on the ${names[1]}. The rim sets this, not the hub, so it barely changes from hub to hub.`}
        </Readout>
        <Foot>Curve: Hetényi's deflection shape for a straight beam on an elastic foundation under a point load, scaled to each hub's affected length. Ford uses n<sub>SP</sub> to check when smeared spokes are accurate (more than about one spoke in the affected length). The sideways version uses the combined bending and twisting rim stiffness from bike-wheel-calc's <code>calc_Pn_lat</code>.</Foot>
      </Section>

      <Section title="TENSION SOFTENING" subtitle="tighter is not always stiffer">
        <Study eq={EQ.soften} part="Ford ch. 2, “Lateral stiffness vs. spoke tension”, which compares the theory with Rinard’s measurements" cites={[<>Ford, Matthew. <i>Reinventing the Wheel: Stress Analysis, Stability, and Optimization of the Bicycle Wheel</i>. 2018. Northwestern University, PhD dissertation.</>,
          <>Rinard, Damon. “Wheel Stiffness Test.” <i>SheldonBrown.com</i>, sheldonbrown.com/rinard/wheel.</>]} />
        <Lead>Spoke tension squeezes the rim. Past a point that squeeze makes the wheel softer sideways, and at the buckling tension the stiffness runs out. This is each build's lateral stiffness from no tension up to where it buckles.</Lead>
        {sweeps.every((s) => s.pts.length > 1) ? (
          <>
            <Softening sweeps={sweeps} tension={tension} narrow={narrow} />
            <Key items={[[lineSwatch(colors[0]), names[0]], [lineSwatch(colors[1], "7 5"), names[1]], [<b style={{ color: j.txt }}>×</b>, "buckling tension"]]} />
            <Readout>
              {sweeps.map((s, i) => (drop[i] != null
                ? `At ${fmt(tension)} kgf the ${HUB_SHORT[i]} has ${fmt(drop[i])}% less lateral stiffness than it would at zero tension (${fmt(s.here)} vs ${fmt(s.K0)} N/mm).`
                : `The ${HUB_SHORT[i]} is past its buckling tension at ${fmt(tension)} kgf.`)).join(" ")}
            </Readout>
          </>
        ) : <Readout color={j.warn}>No stiffness curve to draw at these settings.</Readout>}
        <Foot>Smeared-spoke lateral stiffness, the same as the Lab's Lateral Stiffness figure, at each drive-side tension. The curves stop at the discrete-spoke buckling tension the rest of the Lab uses. Ford notes that real wheels are hard to tension past about half their buckling tension, which he gives as the likely reason wheelbuilders rarely see this effect.</Foot>
      </Section>

      <Section title="TACO SHAPE" subtitle="which wave the rim buckles into">
        <Study eq={EQ.taco} part="critical tension for each wave count n" cites={[<>Ford, Matthew, et al. “Buckling of the Bicycle Wheel.” <i>Proceedings of the 2016 Bicycle and Motorcycle Dynamics Conference</i>, 2016, https://doi.org/10.6084/m9.figshare.3856134.</>]} />
        <Lead>Too much spoke tension buckles the rim into side-to-side waves: two waves is the classic potato chip, three or more is a wavy taco. Each wave count has its own buckling tension. The lowest one is the shape this rim would fold into first.</Lead>
        <div style={{ display: "flex", flexWrap: narrow ? "nowrap" : "wrap", gap: narrow ? 10 : 16, alignItems: "center", margin: "0 0 6px" }}>
          {lowN.map((m, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: narrow ? 4 : 8 }}>
              <TacoSketch n={m.n} size={narrow ? 72 : 110} color={colors[i]} />
              <div style={{ fontSize: 10.5, color: j.txt, fontFamily: MONO, lineHeight: 1.5 }}>
                <b>{HUB_SHORT[i]}</b>{`: ${m.n} waves`}<br />
                <span style={{ color: j.muted }}>{`at ${fmt(m.T_c_DS)} kgf`}</span>
              </div>
            </div>
          ))}
        </div>
        <TacoModes modes={modes} tension={tension} narrow={narrow} />
        <Key items={[
          [<i style={{ display: "inline-block", width: 14, height: 10, background: colors[0] }} />, names[0]],
          [<i style={{ display: "inline-block", width: 14, height: 10, border: `1.5px solid ${colors[1]}`, background: `repeating-linear-gradient(45deg, ${colors[1]} 0 2px, transparent 2px 4.5px)` }} />, names[1]],
        ]} />
        <Readout>
          {`Headline buckling tension (each spoke modelled separately, as on the other tabs): ${fmt(res[0].T_c)} kgf for the 148 and ${fmt(res[1].T_c)} kgf for the 157. The per-shape bars come from the paper's quick formula, which reads ${fmt((lowN[0].T_c_DS / res[0].T_c - 1) * 100)}% and ${fmt((lowN[1].T_c_DS / res[1].T_c - 1) * 100)}% higher, so use them for which shape comes first, not for when.`}
        </Readout>
        <Foot>Per-mode critical tension from the smeared, linear approximation inside bike-wheel-calc's <code>calc_buckling_tension</code>, given as the equivalent drive-side tension. Sketches show the rim seen at an angle, with the waves exaggerated; the dotted ring is the true rim.</Foot>
      </Section>

      <Section title="SPOKE PITCH" subtitle="what each side should sound like">
        <Study eq={EQ.pitch} part="the string formula and Table 1" cites={[<>Allen, John S. “A Musical Test for Correct Spoke Tension.” <i>Bike Tech</i>, vol. 3, no. 4, Aug. 1984, pp. 14–16.</>]} />
        <Lead>A plucked spoke is a guitar string: the tighter it is, the higher it rings. John Allen showed in 1984 that the note tells you the stress in the spoke whatever its gauge, so a pitch pipe could check tension. The drive and non-drive spokes sit at different tensions, so they play different notes.</Lead>
        <SpokePitch hubs={hubs} names={names} erd={erd} spokes={spokes} offset={offset} tension={tension} narrow={narrow} />
        <Foot>Allen's measured pitches for double-butted spokes, two semitones lower for the Lab's 2.0 mm plain spokes, at A4 = 440 Hz. On laced wheels he plucks each crossed pair where they cross, and expects a well-built wheel to stay within two or three semitones per side; he puts a typical rear non-drive side about five semitones under the drive side. Real spokes vary, so treat the note as a range check and use a tension meter for numbers. This one is not Ford's work.</Foot>
      </Section>

      <p style={{ fontSize: 9.5, color: j.muted, margin: "4px 0 0", lineHeight: 1.6 }}>
        The first four come from Matthew Ford's Mode Matrix method (PhD thesis, Northwestern University, 2018) and his MIT-licensed bike-wheel-calc library, ported in wheel-physics-core and checked against his code to floating-point precision. Spoke pitch is John S. Allen's 1984 acoustic test. 2.0 mm spokes and the Lab's stock rim throughout.
      </p>
    </div>
  );
}
