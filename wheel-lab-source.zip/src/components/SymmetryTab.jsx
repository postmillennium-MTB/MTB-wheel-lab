import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";
import { computeWheelStrength } from "../physics.js";
import { PHYS_CONSTANTS } from "../data.js";
import WheelDiagram, { DIAGRAM_LAYOUT as DL } from "./WheelDiagram.jsx";
import AnnotationOverlay, { ANNOTATION_STEPS, ANNOTATION_STEP_MS } from "./AnnotationOverlay.jsx";

// How often the countdown bar's progress state updates while annotation
// mode is playing. Small enough to look smooth, large enough not to
// thrash React with re-renders (3000ms step / 60ms tick = 50 steps of bar
// motion, well under what the eye can tell from a true 60fps animation).
const ANNOTATION_TICK_MS = 60;

// kgf -> newtons, so the kgf figures the tab shows and the kN/m stiffness
// computeWheelStrength returns can be combined.
const KGF_TO_N = 9.81;

/**
 * Lateral margin, in mm: how far the rim can move sideways before the
 * non-drive spokes reach zero tension. computeWheelStrength already
 * contains this figure — F_lat (kgf) is exactly K_lat (kN/m) times this
 * deflection — so it is recovered rather than recomputed.
 *
 * WHY THIS TAB COMPARES MARGIN INSTEAD OF F_lat DIRECTLY. This is a
 * recorded trap; please don't "simplify" it back.
 *
 * K_lat carries a rim tension-softening term: as spoke tension approaches
 * the wheel's buckling tension, modelled lateral stiffness collapses. The
 * synthetic 60mm symmetric hub this tab starts from has the LOWEST
 * buckling tension of any wheel in the app (~137-150 kgf at 29"), and the
 * Tension slider above runs to 125 kgf — so the baseline wheel already sits
 * at 80-91% of buckling before the dial is touched. Dishing it drops
 * non-drive tension, which moves the wheel away from buckling and pushes
 * K_lat UP by 6-116%. That rise was cancelling most of the strength loss
 * this tab exists to demonstrate: at 29"/28h/120kgf an 15-point drop in
 * tension balance showed as only -10%, and at 36h/120kgf or 32h/125kgf it
 * flipped sign entirely — the model claimed a dished wheel was STRONGER,
 * which Math.max(0, ...) then hid as a flat "-0%".
 *
 * Comparing margin holds stiffness constant between the two wheels, which
 * is what "one wheel, one variable" promises in the first place. The loss
 * then tracks the tension imbalance the way wheelbuilding experience says
 * it should — roughly 1.2-1.5x the drop in tension balance — and gives the
 * same answer at every spoke count and tension.
 */
function lateralMarginMm(r){return r.F_lat*KGF_TO_N/r.K_lat}

/**
 * SYMMETRY tab: holds total flange width fixed at 60mm and lets the user
 * drag the flanges off-center to see strength/tension-balance tradeoffs
 * in isolation from width changes.
 * @param spokes  spoke count
 * @param erd     rim diameter (mm)
 * @param tension drive-side spoke tension (kgf)
 */
function SymmetryTab({spokes:pn,erd:pe,tension:pt}){
let[ps,pset]=(0,se.useState)(0);
// Annotation mode: a self-playing guided tour of the callouts in
// ANNOTATION_STEPS (see AnnotationOverlay.jsx), cycling automatically
// once switched on.
let[annOn,setAnnOn]=(0,se.useState)(!1),
    [annStep,setAnnStep]=(0,se.useState)(0),
    [annElapsed,setAnnElapsed]=(0,se.useState)(0);
(0,se.useEffect)(()=>{
  if(!annOn)return;
  let id=setInterval(()=>{
    setAnnElapsed(el=>{
      let next=el+ANNOTATION_TICK_MS;
      if(next>=ANNOTATION_STEP_MS){
        setAnnStep(s=>(s+1)%ANNOTATION_STEPS.length);
        return 0;
      }
      return next;
    });
  },ANNOTATION_TICK_MS);
  return()=>clearInterval(id);
},[annOn]);
let toggleAnnotation=()=>{
  setAnnOn(v=>!v);
  setAnnStep(0);
  setAnnElapsed(0);
};
let pW=60,ph=pW/2,pds=+(ph-ps).toFixed(1),pnds=+(ph+ps).toFixed(1);
let pbase=(0,se.useMemo)(()=>computeWheelStrength(pe,{nds:ph,ds:ph,pds:58,pnds:58},2,2,pt,PHYS_CONSTANTS.EIL,PHYS_CONSTANTS.EIR,PHYS_CONSTANTS.GJ,PHYS_CONSTANTS.EA_rim,pn,PHYS_CONSTANTS.modes),[pe,pt,pn]);
let pcur=(0,se.useMemo)(()=>computeWheelStrength(pe,{nds:pnds,ds:pds,pds:58,pnds:58},2,2,pt,PHYS_CONSTANTS.EIL,PHYS_CONSTANTS.EIR,PHYS_CONSTANTS.GJ,PHYS_CONSTANTS.EA_rim,pn,PHYS_CONSTANTS.modes),[pe,pt,pn,ps]);
let pr=Math.round(pcur.ratio);
// Lateral margin now vs. at dead-symmetric, and the strength that margin
// buys at the baseline wheel's stiffness — see lateralMarginMm() above for
// why the comparison is made this way. At the slider's zero position pcap
// is exactly pbase.F_lat, so nothing about the symmetric wheel changes.
let pmargin=lateralMarginMm(pcur),pmarginBase=lateralMarginMm(pbase);
let pcap=pbase.K_lat*pmargin/KGF_TO_N;
let ploss=Math.max(0,Math.round((1-pmargin/pmarginBase)*100));
let pcol=pr>=85?j.ok:pr>=65?j.warn:j.fail;
let pdsT=pt,pndsT=Math.round(pt*pcur.ratio/100);
let pgeo={label:"",tag:"",DS_px:pds*1.95,NDS_px:pnds*1.95,flangeR:pds,flangeL:pnds,DS_angle:(Math.atan(pds/(pe/2))*180/Math.PI).toFixed(1)+"\u00B0",NDS_angle:(Math.atan(pnds/(pe/2))*180/Math.PI).toFixed(1)+"\u00B0"};
let pbow=Math.min(46,(100-pr)/100*60),pop=0.3+0.7*pr/100;
let plk={color:j.acc};
return(0,_.jsxs)(_.Fragment,{children:[
(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderTop:`3px solid ${pcol}`,borderRadius:"0 0 8px 8px",padding:"14px 16px 12px",marginBottom:12},children:[
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:2},children:[
  (0,_.jsx)("div",{style:{fontFamily:"Space Grotesk, system-ui",fontWeight:700,fontSize:14,color:j.txt},children:"One wheel. One variable."}),
  (0,_.jsxs)("button",{onClick:toggleAnnotation,style:{display:"flex",alignItems:"center",gap:5,padding:"5px 10px",borderRadius:6,cursor:"pointer",flexShrink:0,background:annOn?`${pcol}1c`:j.surfl,border:`1.5px solid ${annOn?pcol:j.bdr}`,color:annOn?pcol:j.muted,fontSize:9.5,fontFamily:"Space Grotesk, system-ui",fontWeight:700,letterSpacing:"0.04em"},children:[
    annOn?"\u25cf ":"\u25b6 ","ANNOTATION MODE",
    annOn&&(0,_.jsxs)("span",{style:{fontFamily:"Space Mono, monospace",fontWeight:400,opacity:.75},children:[annStep+1,"/",ANNOTATION_STEPS.length]}),
  ]}),
]}),
(0,_.jsxs)("p",{style:{fontSize:10.5,color:j.muted,margin:"0 0 12px",lineHeight:1.6},children:["Total flange width is locked at ",(0,_.jsx)("strong",{style:{color:j.txt},children:"60 mm"}),". Drag the slider to shift the flanges off-center \u2014 the only thing that changes is ",(0,_.jsx)("em",{children:"balance"}),". Watch what it does to strength, or switch on annotation mode for a guided walkthrough. Uses the Spokes / Rim / Tension settings above."]}),
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:4},children:[
(0,_.jsx)("span",{style:{fontSize:10,color:j.muted},children:"Flange offset from center"}),
(0,_.jsxs)("span",{style:{fontSize:11,color:pcol,fontFamily:"Space Mono, monospace",fontWeight:700},children:[ps.toFixed(1)," mm \u00B7 ",Math.round(ps/ph*100),"% off-center"]})]}),
(0,_.jsx)("input",{type:"range",min:0,max:15,step:.5,value:ps,onChange:pv=>pset(+pv.target.value),style:{width:"100%",accentColor:pcol}}),
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",fontSize:8.5,color:j.dim,fontFamily:"Space Mono, monospace",marginTop:2},children:[(0,_.jsx)("span",{children:"0 = perfectly symmetric"}),(0,_.jsx)("span",{children:"15 = heavily dished"})]}),
(0,_.jsxs)("div",{style:{padding:"6px 4px 0",position:"relative"},children:[
  (0,_.jsx)(WheelDiagram,{geo:pgeo,capKgf:pcap.toFixed(1),color:pcol}),
  annOn&&(0,_.jsx)(AnnotationOverlay,{step:annStep,progress:annElapsed/ANNOTATION_STEP_MS*100,color:pcol,anchors:{dsX:DL.centerX+pgeo.DS_px,ndsX:DL.centerX-pgeo.NDS_px}}),
]})]}),
(0,_.jsxs)("div",{style:{display:"flex",gap:10,marginBottom:12},children:[
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:"LATERAL STRENGTH"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:pcol},children:[pcap.toFixed(1),(0,_.jsx)("span",{style:{fontSize:9,color:j.muted},children:" kgf"})]})]}),
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:"TENSION BALANCE"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:pcol},children:[pr,(0,_.jsx)("span",{style:{fontSize:9,color:j.muted},children:" %"})]})]}),
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:"STRENGTH LOST"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:ploss>0?j.fail:j.ok},children:["\u2212",ploss,(0,_.jsx)("span",{style:{fontSize:9,color:j.muted},children:" %"})]})]})]}),
(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"12px 16px",marginBottom:12},children:[
(0,_.jsx)("div",{style:{fontFamily:"Space Grotesk, system-ui",fontWeight:600,fontSize:12,color:j.txt,letterSpacing:"0.04em",marginBottom:2},children:"SPOKE TENSION GAUGE"}),
(0,_.jsx)("div",{style:{fontSize:10,color:j.muted,marginBottom:6},children:"Two spokes, same wheel. The slack one is where wheels die."}),
(0,_.jsxs)("svg",{viewBox:"0 0 320 168",style:{width:"100%",display:"block",maxWidth:420,margin:"0 auto"},children:[
(0,_.jsx)("line",{x1:20,y1:22,x2:300,y2:22,stroke:j.bdr,strokeWidth:2}),
(0,_.jsx)("line",{x1:20,y1:146,x2:300,y2:146,stroke:j.bdr,strokeWidth:2}),
(0,_.jsx)("text",{x:22,y:14,fill:j.dim,fontSize:7.5,fontFamily:"Space Mono, monospace",children:"HUB FLANGE"}),
(0,_.jsx)("text",{x:22,y:160,fill:j.dim,fontSize:7.5,fontFamily:"Space Mono, monospace",children:"RIM"}),
(0,_.jsx)("path",{d:`M 95 22 Q ${95-pbow} 84 95 146`,fill:"none",stroke:pcol,strokeWidth:4,strokeLinecap:"round",opacity:pop}),
(0,_.jsx)("circle",{cx:95,cy:22,r:5,fill:pcol,opacity:pop}),
(0,_.jsx)("circle",{cx:95,cy:146,r:4,fill:pcol,opacity:pop}),
(0,_.jsx)("text",{x:95,y:38,textAnchor:"middle",fill:j.muted,fontSize:8,letterSpacing:"0.05em",children:"NON-DRIVE SIDE"}),
(0,_.jsxs)("text",{x:95,y:90,textAnchor:"middle",fill:pcol,fontSize:15,fontFamily:"Space Mono, monospace",fontWeight:700,children:[pndsT," kgf"]}),
(0,_.jsx)("text",{x:95,y:102,textAnchor:"middle",fill:pr<60?j.fail:j.muted,fontSize:7.5,children:pr>=95?"taut":pr>=75?"looser":pr>=60?"loose":"going slack"}),
(0,_.jsx)("line",{x1:225,y1:22,x2:225,y2:146,stroke:j.acc,strokeWidth:4,strokeLinecap:"round"}),
(0,_.jsx)("circle",{cx:225,cy:22,r:5,fill:j.acc}),
(0,_.jsx)("circle",{cx:225,cy:146,r:4,fill:j.acc}),
(0,_.jsx)("text",{x:225,y:38,textAnchor:"middle",fill:j.muted,fontSize:8,letterSpacing:"0.05em",children:"DRIVE SIDE"}),
(0,_.jsxs)("text",{x:225,y:90,textAnchor:"middle",fill:j.acc,fontSize:15,fontFamily:"Space Mono, monospace",fontWeight:700,children:[pdsT," kgf"]}),
(0,_.jsx)("text",{x:225,y:102,textAnchor:"middle",fill:j.muted,fontSize:7.5,children:"taut"}),
(0,_.jsx)("line",{x1:160,y1:52,x2:160,y2:118,stroke:j.dim,strokeWidth:1,strokeDasharray:"3,3"}),
(0,_.jsxs)("text",{x:160,y:134,textAnchor:"middle",fill:pcol,fontSize:9,fontFamily:"Space Mono, monospace",fontWeight:700,children:[100-pr,"% gap"]})]}),
pr<60&&(0,_.jsx)("div",{style:{fontSize:9.5,color:j.fail,textAlign:"center",marginTop:4},children:"\u26A0 NDS spokes this loose lose tension cyclically \u2014 nipples back out, fatigue accelerates, wheels fail."})]}),
(0,_.jsxs)("div",{style:{background:j.surfl,border:`1px solid ${j.bdr}`,borderLeft:`3px solid ${j.acc}`,borderRadius:8,padding:"11px 14px",marginBottom:12},children:[
(0,_.jsx)("div",{style:{fontSize:11,color:j.txt,fontWeight:600,fontFamily:"Space Grotesk, system-ui",marginBottom:3},children:"Width didn't change. Symmetry did."}),
(0,_.jsxs)("p",{style:{fontSize:10.5,color:j.muted,margin:0,lineHeight:1.6},children:["At this setting the non-drive spokes carry only ",(0,_.jsxs)("strong",{style:{color:pcol},children:[pr,"%"]})," of drive-side tension and the wheel has given up ",(0,_.jsxs)("strong",{style:{color:ploss>0?j.fail:j.ok},children:[ploss,"%"]})," of its lateral strength \u2014 with the exact same flange width, spokes, rim and tension. This is the trade hiding inside every asymmetric hub: chasing wider flanges at the cost of balance gives some of the gain right back."]})]})]})}

export default SymmetryTab;
