import * as se from "react";
import * as _ from "react/jsx-runtime";
import { theme as j } from "../theme-state.js";
import { computeWheelStrength } from "../physics.js";
import { PHYS_CONSTANTS } from "../data.js";
import WheelDiagram, { DIAGRAM_LAYOUT as DL, hubDiagramGeometry } from "./WheelDiagram.jsx";
import AnnotationOverlay, { ANNOTATION_STEPS, ANNOTATION_STEP_MS } from "./AnnotationOverlay.jsx";
import Pct from "./PercentIcon.jsx";

// How often the countdown bar's progress state updates while annotation
// mode is playing. Small enough to look smooth, large enough not to
// thrash React with re-renders (3000ms step / 60ms tick = 50 steps of bar
// motion, well under what the eye can tell from a true 60fps animation).
const ANNOTATION_TICK_MS = 60;


/**
 * Strength here is computeWheelStrength's F_lat: the first-spoke-slack load
 * from Ford's fully-discrete Mode Matrix (wheel-physics-core), compared
 * directly between the dished and the symmetric wheel.
 *
 * Until October 2026 this tab compared a smeared "lateral margin" (F_lat /
 * K_lat) instead, because the smeared formula made a dished wheel near its
 * buckling tension read as stronger than a symmetric one. Ford's discrete
 * model shows the same thing and treats it as real: close to buckling, the
 * rim's stability rather than spoke slack limits strength, and dishing
 * lowers the non-drive tension and so moves the wheel away from buckling.
 * The 60mm synthetic hub this tab uses has the lowest buckling tension in
 * the app, so the tab says so when the symmetric wheel is near it
 * (NEAR_BUCKLING_PCT) instead of hiding the effect.
 */
const NEAR_BUCKLING_PCT = 75;
const isBuckled = r => !(r.T_safety < 100) || !(r.F_lat > 0);

/**
 * SYMMETRY tab: holds total flange width fixed at 60mm and lets the user
 * drag the flanges off-center to see strength/tension-balance tradeoffs
 * in isolation from width changes.
 * @param spokes  spoke count
 * @param erd     rim diameter (mm)
 * @param tension drive-side spoke tension (kgf)
 */
function SymmetryTab({spokes:pn,erd:pe,tension:pt}){
let[ps,pset]=(0,se.useState)(0);
// Annotation mode: a self-playing guided tour of the callouts in
// ANNOTATION_STEPS (see AnnotationOverlay.jsx), cycling automatically
// once switched on.
let[annOn,setAnnOn]=(0,se.useState)(!1),
    [annStep,setAnnStep]=(0,se.useState)(0),
    [annElapsed,setAnnElapsed]=(0,se.useState)(0);
(0,se.useEffect)(()=>{
  if(!annOn)return;
  let id=setInterval(()=>{
    setAnnElapsed(el=>{
      let next=el+ANNOTATION_TICK_MS;
      if(next>=ANNOTATION_STEP_MS){
        setAnnStep(s=>(s+1)%ANNOTATION_STEPS.length);
        return 0;
      }
      return next;
    });
  },ANNOTATION_TICK_MS);
  return()=>clearInterval(id);
},[annOn]);
let toggleAnnotation=()=>{
  setAnnOn(v=>!v);
  setAnnStep(0);
  setAnnElapsed(0);
};
let pW=60,ph=pW/2,pds=+(ph-ps).toFixed(1),pnds=+(ph+ps).toFixed(1);
let pbase=(0,se.useMemo)(()=>computeWheelStrength(pe,{nds:ph,ds:ph,pds:58,pnds:58},2,2,pt,PHYS_CONSTANTS.EIL,PHYS_CONSTANTS.EIR,PHYS_CONSTANTS.GJ,PHYS_CONSTANTS.EA_rim,pn,PHYS_CONSTANTS.modes),[pe,pt,pn]);
let pcur=(0,se.useMemo)(()=>computeWheelStrength(pe,{nds:pnds,ds:pds,pds:58,pnds:58},2,2,pt,PHYS_CONSTANTS.EIL,PHYS_CONSTANTS.EIR,PHYS_CONSTANTS.GJ,PHYS_CONSTANTS.EA_rim,pn,PHYS_CONSTANTS.modes),[pe,pt,pn,ps]);
let pr=Math.round(pcur.ratio);
// Strength now vs. at dead-symmetric. ploss is negative when dishing a
// near-buckling wheel raises strength (see the comment above), and null
// when either wheel is past buckling.
let pbuck=isBuckled(pcur),pbaseBuck=isBuckled(pbase);
let pcap=pcur.F_lat;
let ploss=pbuck||pbaseBuck?null:Math.round((1-pcur.F_lat/pbase.F_lat)*100);
let pnear=Math.round(pbase.T_safety);
let pcol=pr>=85?j.ok:pr>=65?j.warn:j.fail;
let pdsT=pt,pndsT=Math.round(pt*pcur.ratio/100);
// The tab's synthetic hub: 58mm flanges both sides, the split moved off
// centre by the slider. Same builder the COMPARE tab uses, so the two
// diagrams are drawn at one scale and quote bracing angle on one basis.
let pgeo={label:"",tag:"",...hubDiagramGeometry({ds:pds,nds:pnds,pds:58,pnds:58},pe,pn)};
let pbow=Math.min(46,(100-pr)/100*60),pop=0.3+0.7*pr/100;
let plk={color:j.acc};
return(0,_.jsxs)(_.Fragment,{children:[
(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderTop:`3px solid ${pcol}`,borderRadius:"0 0 8px 8px",padding:"14px 16px 12px",marginBottom:12},children:[
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:2},children:[
  (0,_.jsx)("div",{style:{fontFamily:"Space Grotesk, system-ui",fontWeight:700,fontSize:14,color:j.txt},children:"One wheel. One variable."}),
  (0,_.jsxs)("button",{onClick:toggleAnnotation,style:{display:"flex",alignItems:"center",gap:5,padding:"5px 10px",borderRadius:6,cursor:"pointer",flexShrink:0,background:annOn?`${pcol}1c`:j.surfl,border:`1.5px solid ${annOn?pcol:j.bdr}`,color:annOn?pcol:j.muted,fontSize:9.5,fontFamily:"Space Grotesk, system-ui",fontWeight:700,letterSpacing:"0.04em"},children:[
    annOn?"\u25cf ":"\u25b6 ","ANNOTATION MODE",
    annOn&&(0,_.jsxs)("span",{style:{fontFamily:"Space Mono, monospace",fontWeight:400,opacity:.75},children:[annStep+1,"/",ANNOTATION_STEPS.length]}),
  ]}),
]}),
(0,_.jsxs)("p",{style:{fontSize:10.5,color:j.muted,margin:"0 0 12px",lineHeight:1.6},children:["Total flange width is locked at ",(0,_.jsx)("strong",{style:{color:j.txt},children:"60 mm"}),". Drag the slider to shift the flanges off-center \u2014 the only thing that changes is ",(0,_.jsx)("em",{children:"balance"}),". Watch what it does to strength, or switch on annotation mode for a guided walkthrough. Uses the Spokes / Rim / Tension settings above."]}),
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:4},children:[
(0,_.jsx)("span",{style:{fontSize:10,color:j.muted},children:"Flange offset from center"}),
(0,_.jsxs)("span",{style:{fontSize:11,color:pcol,fontFamily:"Space Mono, monospace",fontWeight:700},children:[ps.toFixed(1)," mm \u00B7 ",Math.round(ps/ph*100),(0,_.jsx)(Pct,{})," off-center"]})]}),
(0,_.jsx)("input",{type:"range",min:0,max:15,step:.5,value:ps,onChange:pv=>pset(+pv.target.value),style:{width:"100%",accentColor:pcol}}),
(0,_.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",fontSize:8.5,color:j.dim,fontFamily:"Space Mono, monospace",marginTop:2},children:[(0,_.jsx)("span",{children:"0 = perfectly symmetric"}),(0,_.jsx)("span",{children:"15 = heavily dished"})]}),
(0,_.jsxs)("div",{style:{padding:"6px 4px 0",position:"relative"},children:[
  (0,_.jsx)(WheelDiagram,{geo:pgeo,capKgf:pbuck?"—":pcap.toFixed(1),color:pcol}),
  annOn&&(0,_.jsx)(AnnotationOverlay,{step:annStep,progress:annElapsed/ANNOTATION_STEP_MS*100,color:pcol,anchors:{dsX:DL.centerX+pgeo.DS_px,ndsX:DL.centerX-pgeo.NDS_px}}),
]})]}),
(0,_.jsxs)("div",{style:{display:"flex",gap:10,marginBottom:12},children:[
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:"LATERAL STRENGTH"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:pcol},children:[pbuck?"—":pcap.toFixed(1),(0,_.jsx)("span",{style:{fontSize:9,color:j.muted},children:" kgf"})]})]}),
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:"TENSION BALANCE"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:pcol},children:[pr,(0,_.jsxs)("span",{style:{fontSize:9,color:j.muted},children:[" ",(0,_.jsx)(Pct,{})]})]})]}),
(0,_.jsxs)("div",{style:{flex:1,background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"10px 8px",textAlign:"center"},children:[(0,_.jsx)("div",{style:{fontSize:8.5,color:j.muted,letterSpacing:"0.06em",marginBottom:4},children:ploss!==null&&ploss<0?"STRENGTH GAINED":"STRENGTH LOST"}),(0,_.jsxs)("div",{style:{fontFamily:"Space Mono, monospace",fontWeight:700,fontSize:19,color:ploss>0?j.fail:j.ok},children:[ploss===null?"—":ploss<0?"+":"−",ploss===null?"":Math.abs(ploss),(0,_.jsxs)("span",{style:{fontSize:9,color:j.muted},children:[" ",(0,_.jsx)(Pct,{})]})]})]})]}),
(pbuck||pbaseBuck||pnear>=NEAR_BUCKLING_PCT)&&(0,_.jsx)("div",{style:{background:j.surfl,border:`1px solid ${j.bdr}`,borderLeft:`3px solid ${j.warn}`,borderRadius:8,padding:"9px 14px",marginBottom:12,fontSize:10.5,color:j.muted,lineHeight:1.6},children:pbuck||pbaseBuck
  ?"At this rim size and tension the "+(pbaseBuck?"symmetric":"dished")+" wheel is at or past its buckling tension in Ford's model, so it has no meaningful first-spoke-slack strength. Lower the tension or pick a smaller rim."
  :"The symmetric wheel is at "+pnear+"% of its buckling tension. This close to buckling the rim's stability, not spoke slack, limits strength in Ford's model, and dishing (which lowers non-drive tension) moves the wheel away from buckling — so a little dish can read as stronger. At lower tension, dishing costs strength at every step."}),
(0,_.jsxs)("div",{style:{background:j.surf,border:`1px solid ${j.bdr}`,borderRadius:8,padding:"12px 16px",marginBottom:12},children:[
(0,_.jsx)("div",{style:{fontFamily:"Space Grotesk, system-ui",fontWeight:600,fontSize:12,color:j.txt,letterSpacing:"0.04em",marginBottom:2},children:"SPOKE TENSION GAUGE"}),
(0,_.jsx)("div",{style:{fontSize:10,color:j.muted,marginBottom:6},children:"Two spokes, same wheel. The slack one is where wheels die."}),
(0,_.jsxs)("svg",{viewBox:"0 0 320 168",style:{width:"100%",display:"block",maxWidth:420,margin:"0 auto"},children:[
(0,_.jsx)("line",{x1:20,y1:22,x2:300,y2:22,stroke:j.bdr,strokeWidth:2}),
(0,_.jsx)("line",{x1:20,y1:146,x2:300,y2:146,stroke:j.bdr,strokeWidth:2}),
(0,_.jsx)("text",{x:22,y:14,fill:j.dim,fontSize:7.5,fontFamily:"Space Mono, monospace",children:"HUB FLANGE"}),
(0,_.jsx)("text",{x:22,y:160,fill:j.dim,fontSize:7.5,fontFamily:"Space Mono, monospace",children:"RIM"}),
(0,_.jsx)("path",{d:`M 95 22 Q ${95-pbow} 84 95 146`,fill:"none",stroke:pcol,strokeWidth:4,strokeLinecap:"round",opacity:pop}),
(0,_.jsx)("circle",{cx:95,cy:22,r:5,fill:pcol,opacity:pop}),
(0,_.jsx)("circle",{cx:95,cy:146,r:4,fill:pcol,opacity:pop}),
(0,_.jsx)("text",{x:95,y:38,textAnchor:"middle",fill:j.muted,fontSize:8,letterSpacing:"0.05em",stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:"NON-DRIVE SIDE"}),
(0,_.jsx)("rect",{x:59,y:77,width:72,height:17,fill:j.surf}),
(0,_.jsxs)("text",{x:95,y:90,textAnchor:"middle",fill:pcol,fontSize:15,fontFamily:"Space Mono, monospace",fontWeight:700,stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:[pndsT," kgf"]}),
(0,_.jsx)("text",{x:95,y:102,textAnchor:"middle",fill:pr<60?j.fail:j.muted,fontSize:7.5,stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:pr>=95?"taut":pr>=75?"looser":pr>=60?"loose":"going slack"}),
(0,_.jsx)("line",{x1:225,y1:22,x2:225,y2:146,stroke:j.acc,strokeWidth:4,strokeLinecap:"round"}),
(0,_.jsx)("circle",{cx:225,cy:22,r:5,fill:j.acc}),
(0,_.jsx)("circle",{cx:225,cy:146,r:4,fill:j.acc}),
(0,_.jsx)("text",{x:225,y:38,textAnchor:"middle",fill:j.muted,fontSize:8,letterSpacing:"0.05em",stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:"DRIVE SIDE"}),
(0,_.jsx)("rect",{x:189,y:77,width:72,height:17,fill:j.surf}),
(0,_.jsxs)("text",{x:225,y:90,textAnchor:"middle",fill:j.acc,fontSize:15,fontFamily:"Space Mono, monospace",fontWeight:700,stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:[pdsT," kgf"]}),
(0,_.jsx)("text",{x:225,y:102,textAnchor:"middle",fill:j.muted,fontSize:7.5,stroke:j.surf,strokeWidth:3,paintOrder:"stroke",strokeLinejoin:"round",children:"taut"}),
(0,_.jsx)("line",{x1:160,y1:52,x2:160,y2:118,stroke:j.dim,strokeWidth:1,strokeDasharray:"3,3"}),
(0,_.jsxs)("text",{x:160,y:134,textAnchor:"middle",fill:pcol,fontSize:9,fontFamily:"Space Mono, monospace",fontWeight:700,children:[100-pr,"% gap"]})]}),
pr<60&&(0,_.jsx)("div",{style:{fontSize:9.5,color:j.fail,textAlign:"center",marginTop:4},children:"\u26A0 NDS spokes this loose lose tension cyclically \u2014 nipples back out, fatigue accelerates, wheels fail."})]}),
(0,_.jsxs)("div",{style:{background:j.surfl,border:`1px solid ${j.bdr}`,borderLeft:`3px solid ${j.acc}`,borderRadius:8,padding:"11px 14px",marginBottom:12},children:[
(0,_.jsx)("div",{style:{fontSize:11,color:j.txt,fontWeight:600,fontFamily:"Space Grotesk, system-ui",marginBottom:3},children:"Width didn't change. Symmetry did."}),
(0,_.jsxs)("p",{style:{fontSize:10.5,color:j.muted,margin:0,lineHeight:1.6},children:["At this setting the non-drive spokes carry only ",(0,_.jsxs)("strong",{style:{color:pcol},children:[pr,(0,_.jsx)(Pct,{})]})," of drive-side tension and the wheel has ",ploss!==null&&ploss<0?"gained ":"given up ",(0,_.jsxs)("strong",{style:{color:ploss>0?j.fail:j.ok},children:[ploss===null?"—":Math.abs(ploss),(0,_.jsx)(Pct,{})]})," of its lateral strength \u2014 with the exact same flange width, spokes, rim and tension. This is the trade hiding inside every asymmetric hub: chasing wider flanges at the cost of balance gives some of the gain right back."]})]})]})}

export default SymmetryTab;
