import * as React from "react";
import { theme as j } from "../theme-state.js";
import { spokeModel, spokeTensions, firstSlackCombined } from "../physics.js";
import Section from "./Section.jsx";
import { reducedMotion } from "./HubFade.jsx";

// PUSH THE WHEEL (COMPARE): both builds side by side under the same sideways
// push at the tire. Press and hold (or drag the slider) and the push grows;
// each spoke fades as it loses tension and turns dashed at zero. The first
// wheel to lose a spoke is marked at that load, its lateral strength, and
// freezes there while the other keeps going until it, too, loses one.
//
// Physics: per-spoke tensions are wheel-physics-core's spokeTensions
// (Matthew Ford's discrete-spoke Mode Matrix, checked spoke by spoke against
// his bike-wheel-calc in that repo's validation/spokes/). They are exact in
// his linear model up to the first spoke going slack, which is why each wheel
// stops at its own first-slack load instead of being drawn past it. The push
// is a point load toward the non-drive side at the spoke point that slackens
// a spoke soonest, the same direction and placement as the spoke ring's
// "Side → NDS". The rim movement readout is load / K_lat (stiffness), shown
// as a number; nothing in the drawing is deflected.

const N2KGF = 9.80665;
const RAMP_MS = 4200;      // hold time to go from zero to the slider's end
const RELEASE_MS = 650;
const OPEN_KEY = "wsl-push-wheel-open";
const fmt = (v, d = 1) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

function readOpen() { try { return localStorage.getItem(OPEN_KEY) !== "0"; } catch (err) { return true; } }

// One wheel face-on, every spoke drawn at its tension under a point load
// (engine signs: lat > 0 toward the engine's NDS) at spoke point `pos`, drawn
// at the bottom. Spokes fade with lost tension and turn dashed at zero.
// `badge` (text) marks a wheel that has reached first slack. Shared with the
// Load Envelope's "spokes at this point" ring.
export function SpokeWheel({ m, pos, lat, rad, badge, color, label, ariaLabel }) {
  const R = 92, Rh = 15, cx = 110, cy = 104;
  const s = m.res.spokes, p0 = s.loadTh[pos];
  const ang = (th) => th - p0 + Math.PI / 2;
  const now = spokeTensions(m.res, { lat, rad, pos });
  const order = s.T.map((_, i) => i).sort((a, b) => (m.realSide(a) === "DS") - (m.realSide(b) === "DS"));
  return (
    <svg viewBox="0 0 220 236" role="img" style={{ display: "block", width: "100%", height: "auto" }} aria-label={ariaLabel}>
      <circle cx={cx} cy={cy} r={R + 8} fill="none" stroke={j.muted} strokeWidth={7} opacity={0.18} />
      <circle cx={cx} cy={cy} r={R} fill="none" stroke={j.txt} strokeWidth={3} />
      {order.map((i) => {
        const a = ang(s.th[i]), ah = ang(s.thHub[i]);
        const f = Math.max(0, now[i] / s.T[i]);
        const slack = now[i] <= 1e-6;
        return (
          <line key={i} x1={cx + Rh * Math.cos(ah)} y1={cy + Rh * Math.sin(ah)} x2={cx + (R - 2) * Math.cos(a)} y2={cy + (R - 2) * Math.sin(a)}
            stroke={slack ? j.slack : j.txt} strokeOpacity={slack ? 1 : 0.15 + 0.85 * Math.min(1, f)}
            strokeWidth={m.realSide(i) === "DS" ? 2.2 : 1.2} strokeLinecap="round" strokeDasharray={slack ? "3 3" : undefined} />
        );
      })}
      <circle cx={cx} cy={cy} r={Rh + 2} fill={j.surf} stroke={j.txt} strokeWidth={1.6} />
      <circle cx={cx} cy={cy} r={5} fill={j.txt} />
      <circle cx={cx} cy={cy + R} r={6} fill={j.surf} stroke={j.slack} strokeWidth={2} />
      {/* Hub color only as a swatch; the label itself is in the text color,
          since a hub color can be under 4.5:1 as small text (Roly-Poly teal). */}
      <rect x={cx - 38} y={cy + R + 16} width={10} height={10} rx={2} fill={color} />
      <text x={cx - 22} y={cy + R + 26} fill={j.txt} style={{ fontFamily: "Space Grotesk, system-ui", fontWeight: 700, fontSize: 13 }}>{label}</text>
      {badge && (
        <g>
          <rect x={cx - 80} y={cy - 13} width={160} height={26} rx={5} fill={j.surf} stroke={j.txt} strokeWidth={1.4} />
          <text x={cx} y={cy + 5} textAnchor="middle" fill={j.txt} style={{ fontFamily: "Space Mono, monospace", fontWeight: 700, fontSize: 11 }}>{badge}</text>
        </g>
      )}
    </svg>
  );
}

// This wheel stops at its own first slack: past it the linear model no
// longer describes the wheel.
function MiniWheel({ c, load, color, label, name }) {
  const gone = load >= c.F - 1e-9;
  return (
    <SpokeWheel m={c.m} pos={c.pos} lat={c.d.lat * Math.min(load, c.F)} rad={0} color={color} label={label}
      badge={gone ? `✕ slack at ${fmt(c.F)} kgf` : null}
      ariaLabel={`${name}: ${gone ? `first spoke slack at ${fmt(c.F)} kgf` : `every spoke under tension at ${fmt(load)} kgf`}`} />
  );
}

/** hubs = [hub148, hub157]; names = display names; build settings as for SpokeRing. */
export default function PushWheel({ hubs, names, erd, spokes, offset, tension }) {
  const [open, setOpen] = React.useState(readOpen);
  const toggle = () => setOpen((o) => { try { localStorage.setItem(OPEN_KEY, o ? "0" : "1"); } catch (err) {} return !o; });
  const [models, setModels] = React.useState(null);
  React.useEffect(() => {
    if (!open) return;
    const id = setTimeout(() => setModels(hubs.map((h) => spokeModel(h, erd, spokes, offset, tension))), 20);
    return () => clearTimeout(id);
  }, [open, hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);

  const [load, setLoad] = React.useState(0);
  const loadRef = React.useRef(0);
  const anim = React.useRef(null);
  const set = (v) => { loadRef.current = v; setLoad(v); };
  const stop = () => { if (anim.current) cancelAnimationFrame(anim.current); anim.current = null; };
  React.useEffect(() => () => stop(), []);
  React.useEffect(() => { stop(); set(0); }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);

  const cases = models && !models.some((m) => m.pastBuckling)
    ? models.map((m) => { const d = { lat: m.toNDS, rad: 0 }, f = firstSlackCombined(m.res, d); return { m, d, F: f.scale, pos: f.pos }; })
    : null;
  const maxF = cases ? Math.max(...cases.map((c) => c.F)) : 1;
  const minF = cases ? Math.min(...cases.map((c) => c.F)) : 1;
  const end = Math.ceil(maxF * 1.08);

  const run = (dir) => {
    stop();
    let last = performance.now();
    const tick = (t) => {
      const dt = t - last; last = t;
      // Half speed once the first wheel has lost a spoke, so there is time
      // to see one wheel stopped while the other is still holding.
      const rate = loadRef.current >= minF ? 0.5 : 1;
      const v = dir > 0
        ? Math.min(maxF, loadRef.current + rate * end * dt / RAMP_MS)
        : Math.max(0, loadRef.current - end * dt / RELEASE_MS);
      set(v);
      if ((dir > 0 && v < maxF) || (dir < 0 && v > 0)) anim.current = requestAnimationFrame(tick);
      else anim.current = null;
    };
    anim.current = requestAnimationFrame(tick);
  };
  const press = (e) => { if (e) e.preventDefault(); run(1); };
  const release = () => { if (reducedMotion()) { stop(); set(0); } else run(-1); };

  const body = () => {
    if (!models) return <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Building both wheels…</p>;
    if (!cases) {
      return <p style={{ fontSize: 11, color: j.warn, margin: "8px 0 0", lineHeight: 1.6 }}>At this rim size and tension a build is at or past the rim's buckling tension, so spoke tensions under a push have no meaningful value. Lower the tension or pick a smaller rim.</p>;
    }
    const [a, b] = cases, colors = [j.h148, j.h157], short = ["148", "157"];
    const weak = a.F <= b.F ? 0 : 1, strong = 1 - weak;
    const gap = Math.round((cases[strong].F / cases[weak].F - 1) * 100);
    const moved = (c) => Math.min(load, c.F) * N2KGF / c.m.res.K_lat;
    let verdict;
    if (load <= 0) verdict = "Press and hold to push both wheels sideways at the tire, with the same force on each. Let go and they spring back.";
    else if (load < cases[weak].F) verdict = `${fmt(load)} kgf sideways on both wheels. Every spoke on both is still under tension; the fading ones are the non-drive spokes giving theirs up.`;
    else if (load < cases[strong].F) verdict = `The ${short[weak]} lost its first spoke at ${fmt(cases[weak].F)} kgf, its lateral strength. The ${short[strong]} is still holding every spoke at ${fmt(load)} kgf. Keep holding.`;
    else verdict = `The ${short[strong]} held until ${fmt(cases[strong].F)} kgf, ${gap}% more than the ${short[weak]}'s ${fmt(cases[weak].F)}. That gap is the strength difference COMPARE reports.`;
    return (
      <>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 10px", lineHeight: 1.6 }}>
          Both of your wheels, the same sideways push at the tire (the dot), toward the non-drive side. Hold the button and watch the spokes fade as they lose tension.
        </p>
        <div style={{ display: "flex", gap: 8, maxWidth: 520, margin: "0 auto" }}>
          {cases.map((c, k) => (
            <div key={k} style={{ flex: 1, minWidth: 0 }}>
              <MiniWheel c={c} load={load} color={colors[k]} label={short[k] + "x12"} name={names[k]} />
              <div style={{ textAlign: "center", fontSize: 9.5, color: j.muted, fontFamily: "Space Mono, monospace", lineHeight: 1.5 }}>
                rim moved <b style={{ color: j.txt }}>{fmt(moved(c), 2)} mm</b><br />stiffness {fmt(c.m.res.K_lat, 0)} N/mm
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", margin: "12px 0 6px" }}>
          <button type="button" onPointerDown={press} onPointerUp={release} onPointerLeave={() => anim.current && release()} onPointerCancel={release}
            onKeyDown={(e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) press(e); }} onKeyUp={(e) => { if (e.key === " " || e.key === "Enter") release(); }}
            onContextMenu={(e) => e.preventDefault()}
            style={{ touchAction: "none", userSelect: "none", WebkitUserSelect: "none", padding: "9px 16px", borderRadius: 6, cursor: "pointer",
              border: `1.5px solid ${j.txt}`, background: j.surfl, color: j.txt, fontFamily: "Space Grotesk, system-ui", fontWeight: 700, fontSize: 12 }}>
            Hold to push
          </button>
          <label style={{ display: "flex", alignItems: "center", gap: 8, flex: "1 1 200px", minWidth: 0, fontSize: 10, color: j.muted, fontFamily: "Space Mono, monospace" }}>
            PUSH
            <input type="range" min={0} max={maxF} step={0.1} value={load} onChange={(e) => { stop(); set(Number(e.target.value)); }}
              aria-label="Sideways push at the tire, kgf" style={{ flex: 1, minWidth: 0, accentColor: j.slack }} />
            <span style={{ color: j.txt, fontWeight: 700, minWidth: 64, textAlign: "right" }}>{fmt(load)} kgf</span>
          </label>
        </div>
        <p role="status" aria-live="polite" style={{ fontSize: 11, color: j.txt, margin: "8px 0 0", lineHeight: 1.6 }}>{verdict}</p>
        <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
          Strength and stiffness are two different numbers here. Strength is the push at which a wheel loses its first spoke (the ✕). Stiffness is how far the rim moves per unit of push (the mm under each wheel). Spoke tensions come from Matthew Ford's discrete-spoke Mode Matrix; they are exact in his model up to the first spoke going slack, so each wheel stops there.
        </p>
      </>
    );
  };

  return (
    <Section title="PUSH THE WHEEL" subtitle={open ? "both wheels, one sideways push · tap to hide" : "both wheels, one sideways push · tap to show"} openState={open} onToggle={toggle}>
      {open && body()}
    </Section>
  );
}
