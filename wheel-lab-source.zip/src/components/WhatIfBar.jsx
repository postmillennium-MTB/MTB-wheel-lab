import * as React from "react";
import { theme as j } from "../theme-state.js";
import ToggleGroup from "./ToggleGroup.jsx";
import { reducedMotion } from "./HubFade.jsx";

// The "what-if" bar: a slim copy of the build controls that pins to the top
// of the screen once the main control panel has scrolled out of view, so a
// reader deep in a chart (the spoke ring sits ~3,000 px down on a phone) can
// change the build and watch the chart answer without scrolling back up.
// It drives the same state as the main panel; nothing here is a second
// source of truth.
//
// Change chips: after any build change, a short-lived strip lists how each
// hub's lateral strength and lateral stiffness moved. Strength and stiffness
// always get their own labelled chip (they are different things: strength
// is the side load at first spoke slack, stiffness is load per mm of rim
// movement). Chips are drawn in the text color with a +/- sign and the hub
// named in words, so no new color pairs are introduced; the hub's color is
// only a small swatch beside its name. Text sits on the panel color (surf)
// or plain buttons in the text color, never in the accent color or muted on
// surfl: Roly-Poly's accent is 3.3:1 and Paperboy's muted on surfl 4.2:1,
// both short of 4.5:1.

const CHIP_MS = 3500;
const short = (name) => name.replace(/\s*1(48|57)x12$/, "");

function useWide() {
  const q = "(min-width: 600px)";
  const get = () => typeof window !== "undefined" && !!window.matchMedia && window.matchMedia(q).matches;
  const [wide, setWide] = React.useState(get);
  React.useEffect(() => {
    if (!window.matchMedia) return;
    const m = window.matchMedia(q), on = () => setWide(m.matches);
    m.addEventListener ? m.addEventListener("change", on) : m.addListener(on);
    return () => (m.removeEventListener ? m.removeEventListener("change", on) : m.removeListener(on));
  }, []);
  return wide;
}

// True once `ref`'s element has scrolled fully above the top of the screen.
export function useScrolledPast(ref) {
  const [past, setPast] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      const on = () => { const r = el.getBoundingClientRect(); setPast(r.bottom < 0); };
      window.addEventListener("scroll", on, { passive: true });
      return () => window.removeEventListener("scroll", on);
    }
    const io = new IntersectionObserver(([en]) => setPast(!en.isIntersecting && en.boundingClientRect.top < 0));
    io.observe(el);
    return () => io.disconnect();
  }, [ref]);
  return past;
}

const fmt = (d, digits) => {
  const r = +d.toFixed(digits);
  return r === 0 ? null : (r > 0 ? "+" : "−") + Math.abs(r).toFixed(digits);
};

// Tracks the two builds' strength and stiffness and returns the deltas from
// the last change, for CHIP_MS. `key` names the build (hubs, spokes, rim,
// tension, offset); `dead` marks a build past buckling (no meaningful
// strength), which gets no chip.
export function useChangeChips(key, m148, m157, dead148, dead157) {
  // A burst of changes (dragging the tension slider through several steps)
  // is measured from the build before the burst began, not step by step, so
  // the chips show the whole effect of the drag.
  const prev = React.useRef(null), base = React.useRef(null);
  const [chips, setChips] = React.useState(null);
  React.useEffect(() => {
    const now = { key, a: { F: m148.F_lat, K: m148.K_lat, dead: dead148 }, b: { F: m157.F_lat, K: m157.K_lat, dead: dead157 } };
    const p = prev.current;
    prev.current = now;
    if (!p || p.key === key) return;
    if (!base.current) base.current = p;
    const o = base.current;
    const side = (a, b) => (a.dead || b.dead ? null : { F: fmt(b.F - a.F, 1), K: fmt(b.K - a.K, 0) });
    setChips({ id: Date.now(), a: side(o.a, now.a), b: side(o.b, now.b) });
  }, [key]);
  React.useEffect(() => {
    if (!chips) return;
    const t = setTimeout(() => { base.current = null; setChips(null); }, CHIP_MS);
    return () => clearTimeout(t);
  }, [chips]);
  return chips;
}

function Chip({ children }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "baseline", gap: 4, padding: "2px 7px", borderRadius: 999, border: `1px solid ${j.bdr}`, background: "transparent", color: j.txt, fontSize: 10, whiteSpace: "nowrap" }}>
      {children}
    </span>
  );
}

// The chip strip itself. Used inside the pinned bar, and on its own just
// under the main control panel while that panel is still on screen.
export function ChangeChips({ chips, colors }) {
  if (!chips) return null;
  const rows = [["148", chips.a, colors[0]], ["157", chips.b, colors[1]]].filter(([, s]) => s && (s.F || s.K));
  const still = rows.length === 0;
  return (
    <div role="status" aria-live="polite" style={{
      display: "flex", flexWrap: "wrap", gap: 5, alignItems: "center", fontFamily: "Space Mono, monospace",
      animation: reducedMotion() ? "none" : "pmrChipIn .25s ease-out both",
    }}>
      <span style={{ fontSize: 9, color: j.muted, fontFamily: "Space Grotesk, system-ui", letterSpacing: "0.06em" }}>THAT CHANGE</span>
      {still && <Chip>no change in lateral strength or stiffness</Chip>}
      {rows.map(([name, s, col]) => (
        <React.Fragment key={name}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 10, fontWeight: 700, color: j.txt }}>
            <span aria-hidden="true" style={{ width: 8, height: 8, borderRadius: 2, background: col }} />{name}
          </span>
          {s.F && <Chip><span style={{ color: j.muted, fontFamily: "system-ui" }}>strength</span><b>{s.F}</b> kgf</Chip>}
          {s.K && <Chip><span style={{ color: j.muted, fontFamily: "system-ui" }}>stiffness</span><b>{s.K}</b> N/mm</Chip>}
        </React.Fragment>
      ))}
    </div>
  );
}

const selStyle = () => ({
  minWidth: 0, maxWidth: "100%", fontFamily: "Space Mono, monospace", fontSize: 10, padding: "4px 5px", borderRadius: 5,
  cursor: "pointer", background: j.surfl, color: j.txt, border: `1px solid ${j.bdr}`,
});

function HubSelect({ label, color, hubs, value, set }) {
  return (
    <label style={{ display: "flex", alignItems: "center", gap: 5, minWidth: 0, flex: "1 1 150px" }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 10, color: j.muted, flexShrink: 0 }}>
        <span aria-hidden="true" style={{ width: 8, height: 8, borderRadius: 2, background: color }} />{label}
      </span>
      <select aria-label={label + " hub"} value={value} onChange={(ev) => set(ev.target.value)} style={{ ...selStyle(), flex: 1 }}>
        {hubs.map((h) => <option key={h.id} value={h.id}>{short(h.name)}</option>)}
      </select>
    </label>
  );
}

function TensionStepper({ value, min, max, step, set }) {
  const btn = (txt, d, lbl) => (
    <button aria-label={lbl} onClick={() => set(Math.min(max, Math.max(min, value + d)))} disabled={value + d < min || value + d > max}
      style={{ width: 24, height: 22, border: `1px solid ${j.bdr}`, borderRadius: 5, background: j.surfl, color: j.txt, cursor: "pointer", fontSize: 13, lineHeight: 1, padding: 0 }}>{txt}</button>
  );
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5, flex: "1 1 220px", minWidth: 200 }}>
      <span style={{ fontSize: 10, color: j.muted, flexShrink: 0 }}>Tension</span>
      {btn("−", -step, "Lower spoke tension")}
      <input type="range" aria-label="Spoke tension" min={min} max={max} step={step} value={value} onChange={(ev) => set(Number(ev.target.value))}
        style={{ flex: 1, minWidth: 50, accentColor: j.acc, height: 4 }} />
      {btn("+", step, "Raise spoke tension")}
      <span style={{ fontSize: 10, color: j.txt, fontFamily: "Space Mono, monospace", fontWeight: 700, flexShrink: 0 }}>{value} kgf</span>
    </div>
  );
}

/**
 * The pinned bar. `showHubs` is false on tabs that don't use the two chosen
 * hubs (Symmetry, Tension Balance, Hub Specs), which then get only the
 * spokes / rim / tension controls and no strength chips.
 */
export default function WhatIfBar({ show, showHubs, hubs148, hubs157, hub148, hub157, setHub148, setHub157,
  spokes, setSpokes, rim, setRim, tension, setTension, chips, colors }) {
  const wide = useWide();
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => { if (!show) setOpen(false); }, [show]);
  if (!show) return null;
  const n148 = (hubs148.find((h) => h.id === hub148) || hubs148[0]).name;
  const n157 = (hubs157.find((h) => h.id === hub157) || hubs157[0]).name;
  const summary = (showHubs ? short(n148) + " vs " + short(n157) + " · " : "") + spokes + "h · " + rim + " · " + tension + " kgf";
  const full = open || wide;
  return (
    <div style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, display: "flex", justifyContent: "center", pointerEvents: "none" }}>
      <div className="pmr-whatif" style={{
        pointerEvents: "auto", width: "100%", maxWidth: 720, background: j.surf, borderBottom: `1px solid ${j.bdr}`,
        boxShadow: `0 2px 10px ${j.txt}22`, padding: "6px 12px", display: "flex", flexDirection: "column", gap: 6,
        animation: reducedMotion() ? "none" : "pmrBarIn .2s ease-out both",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 9, color: j.muted, letterSpacing: "0.1em", fontFamily: "Space Grotesk, system-ui", fontWeight: 700, flexShrink: 0 }}>WHAT IF</span>
          {!full && <span style={{ fontSize: 10.5, color: j.txt, fontFamily: "Space Mono, monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1, minWidth: 0 }}>{summary}</span>}
          {full && <span style={{ flex: 1, fontSize: 10, color: j.muted }}>change the build here and watch the chart below</span>}
          <button onClick={() => setOpen((o) => !o)} aria-expanded={full}
            style={{ flexShrink: 0, padding: "3px 9px", borderRadius: 5, border: `1px solid ${j.bdr}`, background: j.surfl, color: j.txt, fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: "Space Grotesk, system-ui" }}>
            {wide ? (open ? "Less ▴" : "Rim ▾") : open ? "Done ▴" : "Adjust ▾"}
          </button>
          <button onClick={() => { try { window.scrollTo({ top: 0, behavior: reducedMotion() ? "auto" : "smooth" }); } catch (err) {} }}
            aria-label="Back to the full controls" title="Back to the full controls"
            style={{ flexShrink: 0, padding: "3px 7px", borderRadius: 5, border: `1px solid ${j.bdr}`, background: j.surfl, color: j.txt, fontSize: 10, cursor: "pointer" }}>{"↑"}</button>
        </div>
        {full && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 12px", alignItems: "center" }}>
            {showHubs && <HubSelect label="148" color={colors[0]} hubs={hubs148} value={hub148} set={setHub148} />}
            {showHubs && <HubSelect label="157" color={colors[1]} hubs={hubs157} value={hub157} set={setHub157} />}
            <ToggleGroup label="Spokes" opts={["28", "32", "36"]} val={spokes} set={setSpokes} activeColor={j.acc} />
            {(open || !wide) && <ToggleGroup label="Rim" opts={['26"', '27.5"', '29"', '32"']} val={rim} set={setRim} activeColor={j.acc} />}
            <TensionStepper value={tension} min={80} max={125} step={5} set={setTension} />
          </div>
        )}
        {showHubs && <ChangeChips chips={chips} colors={colors} />}
      </div>
    </div>
  );
}
