import * as React from "react";
import { theme as j } from "../theme-state.js";
import { spokeModel, spokeTensions, firstSlackCombined } from "../physics.js";
import ToggleGroup from "./ToggleGroup.jsx";
import Section from "./Section.jsx";
import { useHubFade, useNarrow, fadeStyle, HubFadeControls, HubFadeTitle } from "./HubFade.jsx";

// SPOKE RING: every spoke's tension under one point load at the tire, for
// the two selected hubs. Tensions come from wheel-physics-core's per-spoke
// output (Matthew Ford's discrete-spoke Mode Matrix, checked against his
// bike-wheel-calc in that repo's validation/spokes/), and are exact in his
// linear model up to the first spoke going slack. Past that point a slack
// spoke carries nothing, which the linear model does not know, so the
// colors become an extrapolation and the readout says so.
//
// The load sits at whichever spoke point makes that hub's first spoke go
// slack soonest (a load between spokes is never worse; see the core's
// validation/spokes/ study), drawn at the bottom of the wheel. The hub is
// drawn at about 2x scale so the lacing reads.

const WIDE = { w: 640, h: 470, cx: 200, cy: 200, Rr: 168, Rh: 30, sx: 418, sw: 206, top: 34, bot: 360, below: false };
const NARROW = { w: 420, h: 730, cx: 210, cy: 196, Rr: 170, Rh: 30, sx: 46, sw: 352, top: 478, bot: 640, below: true };
const MODES = ["Straight down", "Side → NDS", "Side → DS"];
const OPEN_KEY = "wsl-spoke-ring-open";
const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

// Load direction, in the engine's signs, for one build and one mode.
function direction(m, mode) {
  if (mode === MODES[0]) return { lat: 0, rad: 1 };
  return { lat: mode === MODES[1] ? m.toNDS : -m.toNDS, rad: 0 };
}

// Color for a spoke at `pct` of its built tension, as in the mockup:
// tighter than built shades toward `taco`, losing tension toward `slack`.
function tensionColor(pct) {
  if (pct <= 0) return j.slack;
  if (pct >= 1) {
    const a = Math.min(1, (pct - 1) / 0.25);
    return a < 0.15 ? j.txt : `color-mix(in srgb, ${j.taco} ${Math.round(a * 100)}%, ${j.txt})`;
  }
  const a = Math.min(1, (1 - pct) / 0.7);
  return a < 0.15 ? j.txt : `color-mix(in srgb, ${j.slack} ${Math.round(a * 100)}%, ${j.txt})`;
}

function readOpen() {
  try { return localStorage.getItem(OPEN_KEY) !== "0"; } catch (err) { return true; }
}

function Ring({ cases, load, mode, shown, narrow }) {
  const L = narrow ? NARROW : WIDE;
  const { cx, cy, Rr, Rh, sx, sw, top, bot } = L;
  const txt = { fill: j.muted, fontFamily: "Space Mono, monospace", fontSize: narrow ? 12.5 : 11 };
  const lbl = { fill: j.txt, fontFamily: "Space Grotesk, system-ui", fontSize: narrow ? 13.5 : 12.5, fontWeight: 500 };
  const tmax = Math.ceil(Math.max(...cases.map((c) => Math.max(...c.T0))) * 1.4 / 40) * 40;
  const Ys = (v) => bot - Math.max(-12, v) / tmax * (bot - top);
  const yTicks = [];
  for (let v = 0; v <= tmax - 10; v += 40) yTicks.push(v);
  const down = mode === MODES[0];
  const fade = fadeStyle();

  const layer = (c, k) => {
    const s = c.m.res.spokes, p0 = s.loadTh[c.pos];
    const ang = (th) => th - p0 + Math.PI / 2;          // load point at the bottom
    const order = s.T.map((_, i) => i).sort((a, b) => (c.m.realSide(a) === "DS") - (c.m.realSide(b) === "DS"));  // NDS under DS
    const rel = s.th.map((th, i) => {
      let a = th - p0;
      while (a > Math.PI) a -= 2 * Math.PI;
      while (a <= -Math.PI) a += 2 * Math.PI;
      return { i, a };
    }).sort((u, v) => u.a - v.a);
    const bw = sw / rel.length;
    return (
      <g key={k} style={{ opacity: shown === k ? 1 : 0, transition: fade }} aria-hidden={shown !== k}>
        {order.map((i) => {
          const a = ang(s.th[i]), ah = ang(s.thHub[i]);
          const pct = c.now[i] / c.T0[i];
          return (
            <line key={i} x1={cx + Rh * Math.cos(ah)} y1={cy + Rh * Math.sin(ah)} x2={cx + (Rr - 2) * Math.cos(a)} y2={cy + (Rr - 2) * Math.sin(a)}
              stroke={tensionColor(pct)} strokeWidth={c.m.realSide(i) === "DS" ? 2.6 : 1.4} strokeLinecap="round"
              strokeDasharray={c.now[i] <= 0 ? "3 4" : undefined} />
          );
        })}
        {rel.map(({ i }, n) => {
          const v = c.now[i], x = sx + n * bw + 1, y0 = Ys(0), y1 = Ys(v);
          return (
            <g key={i}>
              <rect x={x} y={Math.min(y0, y1)} width={Math.max(0.5, bw - 2)} height={Math.max(1.5, Math.abs(y1 - y0))}
                fill={tensionColor(v / c.T0[i])} opacity={c.m.realSide(i) === "DS" ? 1 : 0.62} />
              <line x1={x} x2={x + bw - 2} y1={Ys(c.T0[i])} y2={Ys(c.T0[i])} stroke={j.muted} strokeWidth={1} />
            </g>
          );
        })}
      </g>
    );
  };

  return (
    <svg viewBox={`0 0 ${L.w} ${L.h}`} role="img" aria-label="Wheel with each spoke colored by its tension under the load"
      style={{ display: "block", width: "100%", height: "auto", maxWidth: "100%" }}>
      <circle cx={cx} cy={cy} r={Rr + 14} fill="none" stroke={j.muted} strokeWidth={10} opacity={0.18} />
      <circle cx={cx} cy={cy} r={Rr} fill="none" stroke={j.txt} strokeWidth={4} />
      <text {...lbl} x={sx} y={top - 16}>each spoke, hit in the middle (kgf)</text>
      {yTicks.map((v) => (
        <g key={v}>
          <line x1={sx} x2={sx + sw} y1={Ys(v)} y2={Ys(v)} stroke={j.bdr} strokeWidth={v ? 1 : 1.6} />
          <text {...txt} x={sx - 4} y={Ys(v) + 4} textAnchor="end">{v}</text>
        </g>
      ))}
      {cases.map(layer)}
      <circle cx={cx} cy={cy} r={Rh + 3} fill={j.surf} stroke={j.txt} strokeWidth={2} />
      <circle cx={cx} cy={cy} r={9} fill={j.txt} />
      {down ? (
        <g>
          <line x1={cx - 120} x2={cx + 120} y1={cy + Rr + 22} y2={cy + Rr + 22} stroke={j.muted} strokeWidth={2} />
          <path d={`M${cx},${cy + Rr + 20} l-9,16 h18 z`} fill={j.slack} />
          <text {...lbl} x={narrow ? cx : cx + 16} y={cy + Rr + (narrow ? 58 : 38)} textAnchor={narrow ? "middle" : "start"}>{`ground pushes up · ${fmt(load, 1)} kgf`}</text>
        </g>
      ) : (
        <g>
          <circle cx={cx} cy={cy + Rr} r={9} fill={j.surf} stroke={j.slack} strokeWidth={2.5} />
          <circle cx={cx} cy={cy + Rr} r={3} fill={j.slack} />
          <text {...lbl} x={narrow ? cx : cx + 16} y={cy + Rr + (narrow ? 52 : 34)} textAnchor={narrow ? "middle" : "start"}>
            {`side push toward ${mode === MODES[1] ? "non-drive" : "drive"} side · ${fmt(load, 1)} kgf`}
          </text>
        </g>
      )}
      <text {...txt} x={sx} y={bot + 16}>← half a turn</text>
      <text {...txt} x={sx + sw} y={bot + 16} textAnchor="end">half a turn →</text>
      <text {...txt} x={sx + sw / 2} y={bot + 32} textAnchor="middle" fill={j.slack}>▲ hit</text>
      <text {...txt} x={sx} y={bot + 56}>tick = tension as built</text>
      <text {...txt} x={sx} y={bot + 72}>faded bar = non-drive side</text>
    </svg>
  );
}

const Swatch = ({ bg }) => <i style={{ display: "inline-block", width: 18, height: 3, background: bg, flex: "0 0 auto" }} />;

/**
 * hubs = [hub148, hub157]; names = their display names; erd, spokes,
 * offset, tension as for FailureMap; fade = the hub choice and Play state
 * shared with the failure map (useHubFade()).
 */
export default function SpokeRing({ hubs, names, erd, spokes, offset, tension, fade: shared }) {
  const own = useHubFade();
  const fade = shared || own;
  const [open, setOpen] = React.useState(readOpen);
  const toggle = () => setOpen((o) => {
    try { localStorage.setItem(OPEN_KEY, o ? "0" : "1"); } catch (err) {}
    return !o;
  });
  const [mode, setMode] = React.useState(MODES[0]);
  const [loadSet, setLoad] = React.useState(null);   // null = default for this mode and build
  // Two engine calls; like the failure map's sweep they run after the tab
  // has painted, and the previous ring stays up until the new one is ready.
  const [models, setModels] = React.useState(null);
  React.useEffect(() => {
    if (!open) return;
    const id = setTimeout(() => setModels(hubs.map((h) => spokeModel(h, erd, spokes, offset, tension))), 20);
    return () => clearTimeout(id);
  }, [open, hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);
  React.useEffect(() => setLoad(null), [mode, hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, open);

  const body = () => {
    if (!models) return <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the ring…</p>;
    if (models.some((m) => m.pastBuckling)) {
      return (
        <p style={{ fontSize: 11, color: j.warn, margin: "8px 0 0", lineHeight: 1.6 }}>
          At this rim size and tension {models.every((m) => m.pastBuckling) ? "both builds are" : models[0].pastBuckling ? "the 148 build is" : "the 157 build is"} at or past the rim's buckling tension, so spoke tensions under a load have no meaningful value. Lower the tension or pick a smaller rim.
        </p>
      );
    }
    const first = models.map((m) => {
      const d = direction(m, mode), c = firstSlackCombined(m.res, d);
      return { m, d, F: c.scale, pos: c.pos };
    });
    const maxF = Math.max(...first.map((c) => c.F)), minF = Math.min(...first.map((c) => c.F));
    const step = mode === MODES[0] ? 1 : 0.5;
    const sliderMax = Math.ceil(maxF * 1.3 / step) * step;
    const load = Math.min(sliderMax, loadSet != null ? loadSet : Math.round(minF * 0.8 / step) * step);
    const cases = first.map((c) => ({
      ...c, T0: c.m.res.spokes.T,
      now: spokeTensions(c.m.res, { lat: c.d.lat * load, rad: c.d.rad * load, pos: c.pos }),
    }));

    const k = fade.lastShown, c = cases[k], o = cases[1 - k];
    const side = (i) => (c.m.realSide(i) === "DS" ? "drive-side" : "non-drive-side");
    let lo = 0, hi = 0;
    c.now.forEach((v, i) => {
      if (v / c.T0[i] < c.now[lo] / c.T0[lo]) lo = i;
      if (v - c.T0[i] > c.now[hi] - c.T0[hi]) hi = i;
    });
    const past = load > c.F + 1e-9;
    const short = (n) => (n === 0 ? "148" : "157");
    const verdict = past
      ? `Past first slack on the ${names[k]}, which happens at ${fmt(c.F, 1)} kgf. From here on a slack spoke carries nothing, and Ford's linear model no longer describes the wheel, so the colors are an extrapolation.` +
        (load <= o.F ? ` The ${short(1 - k)} still has every spoke under tension at this load.` : "")
      : `At ${fmt(load, 1)} kgf on the ${names[k]}, the loosest spoke is ${side(lo)} with ${fmt(Math.max(0, c.now[lo]), 1)} kgf left (${fmt(Math.max(0, c.now[lo] / c.T0[lo] * 100))}% of its ${fmt(c.T0[lo])}). The most-loaded spoke picks up ${fmt(c.now[hi] - c.T0[hi], 1)} kgf. The first spoke goes slack at ${fmt(c.F, 1)} kgf, against ${fmt(o.F, 1)} on the ${short(1 - k)}.`;
    const keyRow = { display: "inline-flex", alignItems: "center", gap: 6 };

    return (
      <>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 12px", lineHeight: 1.6 }}>
          Every spoke's tension when the tire takes one hit. Drag the load up and watch which spoke reaches zero first. The hub and Play controls move the failure map too.
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 14px", marginBottom: 10 }}>
          <HubFadeControls fade={fade} />
          <ToggleGroup label="LOAD" opts={MODES} val={mode} set={setMode} />
        </div>
        <HubFadeTitle fade={fade} names={names} narrow={narrow} />
        <Ring cases={cases} load={load} mode={mode} shown={fade.shown} narrow={narrow} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 10px", fontFamily: "Space Mono, monospace" }}>
          <span style={keyRow}><Swatch bg={j.taco} />tighter than built</span>
          <span style={keyRow}><Swatch bg={j.txt} />as built</span>
          <span style={keyRow}><Swatch bg={j.slack} />losing tension</span>
          <span style={keyRow}><Swatch bg={`repeating-linear-gradient(90deg, ${j.slack} 0 3px, transparent 3px 6px)`} />slack</span>
          <span>thick = drive side · thin = non-drive side · hub drawn ~2× scale</span>
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 10, color: j.muted, fontFamily: "Space Mono, monospace" }}>
          LOAD
          <input type="range" min={0} max={sliderMax} step={step} value={load} onChange={(e) => setLoad(Number(e.target.value))}
            aria-label="Load at the tire, kgf" style={{ flex: 1, minWidth: 0, accentColor: j.slack }} />
          <span style={{ color: j.txt, fontWeight: 700, minWidth: 64, textAlign: "right" }}>{fmt(load, 1)} kgf</span>
        </label>
        <p style={{ fontSize: 11, color: past ? j.warn : j.txt, margin: "12px 0 0", lineHeight: 1.6 }}>{verdict}</p>
        <p style={{ fontSize: 9.5, color: j.muted, margin: "8px 0 0", lineHeight: 1.6 }}>
          Spoke tensions come from Matthew Ford's discrete-spoke Mode Matrix, with the load as a point on the rim. They are exact in his model up to the first spoke going slack; the slider runs to 130% of that so you can see what follows, but past it the picture is an extrapolation.
        </p>
      </>
    );
  };

  return (
    <Section title="SPOKE RING" subtitle={open ? "every spoke under one hit · tap to hide" : "every spoke under one hit · tap to show"} openState={open} onToggle={toggle}>
      <div ref={wrap}>{open && body()}</div>
    </Section>
  );
}
