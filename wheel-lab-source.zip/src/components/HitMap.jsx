import * as React from "react";
import { theme as j } from "../theme-state.js";
import { spokeModel } from "../physics.js";
import { IMPACT_SCENARIOS, REFERENCE_RIDER_WEIGHT_KG, RIDE_LOAD_SCALE } from "../data.js";
import ToggleGroup from "./ToggleGroup.jsx";
import Section from "./Section.jsx";
import { HUB_LABELS, useNarrow } from "./HubFade.jsx";
import { Chart, envelope, capacity } from "./LoadEnvelope.jsx";

// HITS ON THE ENVELOPE (SIMULATION). Replaces the old random "chaos" ride.
// The four named hits are plotted as dots on the chosen hub's load envelope
// (DEEP DIVE's chart: every down + sideways load the wheel takes before its
// first spoke goes slack, exact in Matthew Ford's discrete-spoke Mode
// Matrix). Inside or outside the shape is exact in his model. The hit sizes
// are estimates (IMPACT_SCENARIOS in data.js), scaled with rider + bike
// weight the same way as the slow-mo hit below, and the copy says so.
//
// All hits push toward the non-drive side, the side where the envelope is
// narrower (the non-drive spokes start looser).

const fmt = (v, d = 0) => v.toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });

/** A named hit's sideways and straight-down parts (kgf) for this rider + bike weight. */
export function hitLoads(sc, riderKg) {
  const k = Math.pow(riderKg / REFERENCE_RIDER_WEIGHT_KG, 0.85) * RIDE_LOAD_SCALE;
  return { lat: sc.refPeak * k, rad: sc.refDown * k };
}

export default function HitMap({ hubs, names, erd, spokes, offset, tension, riderKg }) {
  const [which, setWhich] = React.useState(0);
  const [envs, setEnvs] = React.useState(null);
  React.useEffect(() => {
    const id = setTimeout(() => setEnvs(hubs.map((h) => {
      const m = spokeModel(h, erd, spokes, offset, tension);
      return m.pastBuckling ? { m } : { m, pts: envelope(m), F_rad: m.res.F_rad };
    })), 20);
    return () => clearTimeout(id);
  }, [hubs[0].id, hubs[1].id, erd, spokes, offset, tension]);
  const wrap = React.useRef(null);
  const narrow = useNarrow(wrap, true);

  const body = () => {
    if (!envs) return <p style={{ fontSize: 10.5, color: j.muted, margin: "8px 0 0" }}>Drawing the envelope…</p>;
    if (envs.some((e) => !e.pts)) {
      return <p style={{ fontSize: 11, color: j.warn, margin: "8px 0 0", lineHeight: 1.6 }}>At this rim size and tension a build is at or past the rim's buckling tension, so there is no load envelope to plot the hits on. Lower the tension or pick a smaller rim.</p>;
    }
    const list = Object.values(IMPACT_SCENARIOS).map((sc, i) => {
      const { lat, rad } = hitLoads(sc, riderKg);
      const caps = envs.map((e) => capacity(e.m, lat, rad));
      return { n: i + 1, sc, lat, rad, caps };
    });
    const hits = list.map((h) => ({ n: h.n, lat: h.lat, rad: h.rad, inside: h.caps[which] > 1 }));
    const xm = Math.ceil(Math.max(...envs.flatMap((e) => e.pts.map((p) => Math.abs(p[0]))), ...list.map((h) => h.lat)) * 1.12 / 5) * 5;
    const ym = Math.ceil(Math.max(...envs.map((e) => e.F_rad), ...list.map((h) => h.rad)) * 1.12 / 50) * 50;
    const colors = [j.h148, j.h157], short = ["148", "157"], o = 1 - which;
    const withCap = envs.map((e) => ({ ...e, cap: Infinity }));
    const nIn = (k) => list.filter((h) => h.caps[k] > 1).length;
    return (
      <>
        <p style={{ fontSize: 10.5, color: j.muted, margin: "6px 0 10px", lineHeight: 1.6 }}>
          <strong style={{ color: j.txt }}>Four hits, each an estimated hit size.</strong> Every hit pushes the wheel down and sideways at once, so each is a dot on the wheel's load envelope (the same shape as DEEP DIVE). Inside the shape every spoke keeps its tension; outside it a spoke goes slack for a moment and the wheel springs back. Inside or outside is exact in Ford's model; the hit sizes are estimates, not measured trail loads, and grow with the Rider+bike slider.
        </p>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "10px 14px", marginBottom: 8 }}>
          <ToggleGroup label="HUB" opts={HUB_LABELS} val={HUB_LABELS[which]} set={(v) => setWhich(HUB_LABELS.indexOf(v))} activeColor={colors[which]} />
        </div>
        <div style={{ fontFamily: "Space Grotesk, system-ui", fontWeight: 700, fontSize: narrow ? 17 : 20, lineHeight: 1.2, color: colors[which], margin: "2px 0 4px" }}>{names[which]}</div>
        <Chart envs={withCap} which={which} names={names} lat={0} rad={0} setPoint={() => {}} narrow={narrow} xm={xm} ym={ym} hits={hits} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: "6px 16px", fontSize: 10, color: j.muted, margin: "8px 0 10px", fontFamily: "Space Mono, monospace" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><i style={{ display: "inline-block", width: 18, height: 3, background: colors[which] }} />{`${short[which]}: no spoke slack inside`}</span>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><i style={{ display: "inline-block", width: 18, height: 3, background: `repeating-linear-gradient(90deg, ${j.muted} 0 3px, transparent 3px 7px)` }} />{short[o]}</span>
          <span>● holds · ◇ a spoke goes slack</span>
        </div>
        <div role="list" style={{ display: "grid", gridTemplateColumns: narrow ? "1fr" : "1fr 1fr", gap: 6 }}>
          {list.map((h) => {
            const ok = h.caps[which] > 1, okO = h.caps[o] > 1;
            return (
              <div role="listitem" key={h.n} style={{ display: "flex", gap: 9, alignItems: "flex-start", padding: "7px 9px", border: `1px solid ${j.bdr}`, borderRadius: 7, background: j.surf }}>
                <span aria-hidden="true" style={{ flex: "0 0 auto", width: 20, height: 20, borderRadius: ok ? "50%" : 3, transform: ok ? "none" : "rotate(45deg) scale(.85)",
                  background: ok ? j.txt : j.surf, border: ok ? "none" : `2px solid ${j.slack}`, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
                  <b style={{ transform: ok ? "none" : "rotate(-45deg)", color: ok ? j.surf : j.txt, fontFamily: "Space Mono, monospace", fontSize: 11 }}>{h.n}</b>
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 11, color: j.txt, fontWeight: 700, fontFamily: "Space Grotesk, system-ui" }}>
                    {h.sc.label}: {ok ? "holds" : "a spoke goes slack"}
                  </div>
                  <div style={{ fontSize: 9.5, color: j.muted, lineHeight: 1.5, fontFamily: "Space Mono, monospace" }}>
                    est. {fmt(h.rad)} down + {fmt(h.lat, 1)} sideways kgf · {fmt(100 / h.caps[which])}% of the {short[which]}'s margin
                  </div>
                  <div style={{ fontSize: 9.5, color: j.muted, lineHeight: 1.5 }}>
                    {okO === ok ? `Same on the ${short[o]} (${fmt(100 / h.caps[o])}%).` : `The ${short[o]} ${okO ? "holds" : "goes slack"} (${fmt(100 / h.caps[o])}%).`}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <p style={{ fontSize: 11, color: j.txt, margin: "10px 0 0", lineHeight: 1.6 }}>
          At this build and {fmt(riderKg)} kg rider + bike, the 148 holds {nIn(0)} of 4 hits and the 157 holds {nIn(1)} of 4.
        </p>
      </>
    );
  };

  return (
    <Section title="HITS ON THE LOAD ENVELOPE" subtitle="estimated hit sizes · exact edge">
      <div ref={wrap}>{body()}</div>
    </Section>
  );
}
