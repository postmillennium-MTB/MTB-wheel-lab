/** @jsxRuntime automatic */
import * as se from "react";
import { HUBS_148, HUBS_157, HUB_SOURCES, PHYS_CONSTANTS } from "../data.js";
import { computeWheelStrength } from "../physics.js";

/**
 * HUB SPECS tab: flange geometry for every hub in the catalogue as one
 * sortable spec sheet.
 *
 * The four measured numbers per hub (DS/NDS center-to-flange, DS/NDS flange
 * diameter) come straight from HUBS_148 / HUBS_157, so a hub added in data.js
 * shows up here with no other change. Everything else is derived from them:
 *   - flange spacing = ds + nds
 *   - mid-flange offset = (nds - ds) / 2, toward the non-drive side
 *   - bracing angles: same spoke geometry as wheel-physics-core's calc()
 *     (3-cross, rim centroid radius ERD/2 + 11 mm)
 *   - tension balance: calc()'s `ratio` (Ford's Mode Matrix method)
 * The derived columns follow the Spokes and Rim controls above. They use the
 * hub alone; the rim-offset slider is not applied, so this is the hub's own
 * geometry. TENSION BALANCE is the tab that includes rim offset.
 *
 * This tab deliberately keeps its own look (the "spec sheet" design Jon
 * approved as a standalone page on 2026-11-04) rather than the active Lab
 * theme: light or dark follows the visitor's system setting. Its palette was
 * checked against the colorblind rule in CLAUDE.md (see the PR).
 */

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&family=Barlow+Condensed:wght@600;700&display=swap');
.hs{
  --bg:#f5f6f4; --panel:#ffffff; --fg:#1d2321; --muted:#5a6461; --rule:#d5dad7;
  --accent:#1f5c73; --chip148:#1f5c73; --chip157-fg:#7a3b00; --chip157-bg:#fbe9d6; --hl:#eef3f5;
  --display:"Barlow Condensed","Arial Narrow",sans-serif; --body:"IBM Plex Sans",system-ui,sans-serif; --mono:"IBM Plex Mono",ui-monospace,monospace;
  position:relative; left:50%; transform:translateX(-50%);
  width:min(1240px, calc(100vw - 32px));
  background:var(--bg); color:var(--fg); font-family:var(--body); font-size:15px; line-height:1.5;
  border:1px solid var(--rule); border-radius:4px;
  padding:28px clamp(14px,2.5vw,28px) 32px; display:grid; gap:24px; text-align:left;
}
@media (prefers-color-scheme: dark){.hs{--bg:#141918;--panel:#1c2220;--fg:#e4e8e6;--muted:#9aa5a1;--rule:#2f3735;--accent:#7cc0d8;--chip148:#7cc0d8;--chip157-fg:#ffcf9e;--chip157-bg:#4a2a0c;--hl:#1f2a2d;color-scheme:dark}}
.hs *{box-sizing:border-box}
.hs header{display:grid;gap:8px;border-bottom:2px solid var(--fg);padding-bottom:14px}
.hs .eyebrow{font-family:var(--mono);font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.hs h1{font-family:var(--display);font-size:clamp(30px,5vw,44px);line-height:1;margin:0;letter-spacing:.01em;text-wrap:balance;font-weight:700}
.hs .lede{max-width:68ch;margin:0;color:var(--muted)}
.hs .top{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:24px;align-items:start}
@media (max-width:820px){.hs .top{grid-template-columns:minmax(0,1fr)}}
.hs .facts{display:grid;gap:10px;margin:0;padding:0;list-style:none}
.hs .facts li{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:baseline}
.hs .facts b{font-family:var(--mono);font-weight:500;font-size:13px;color:var(--accent);min-width:3.5em}
.hs figure{margin:0;background:var(--panel);border:1px solid var(--rule);border-radius:4px;padding:12px}
.hs figure svg{width:100%;height:auto;display:block}
.hs figcaption{font-size:12px;color:var(--muted);margin-top:6px}
.hs .controls{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.hs .controls button{font:500 13px var(--body);padding:6px 12px;border:1px solid var(--rule);background:var(--panel);color:var(--fg);border-radius:3px;cursor:pointer}
.hs .controls button[aria-pressed="true"]{border-color:var(--accent);box-shadow:inset 0 -2px 0 var(--accent)}
.hs .controls button:focus-visible,.hs th button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.hs .controls .hint{font-size:12px;color:var(--muted);margin-left:auto}
.hs .tablebox{overflow-x:auto;background:var(--panel);border:1px solid var(--rule);border-radius:4px}
.hs table{border-collapse:collapse;width:100%;min-width:1080px;font-variant-numeric:tabular-nums}
.hs th,.hs td{padding:7px 10px;border-bottom:1px solid var(--rule);text-align:right;white-space:nowrap}
.hs th{font:600 11.5px/1.25 var(--body);color:var(--muted);vertical-align:bottom;background:var(--panel);white-space:normal}
.hs th button{all:unset;cursor:pointer;display:block}
.hs th[aria-sort] button::after{content:" ↕";opacity:.4}
.hs th[aria-sort="ascending"] button::after{content:" ↑";opacity:1}
.hs th[aria-sort="descending"] button::after{content:" ↓";opacity:1}
.hs th.grp{text-align:center;font-family:var(--mono);font-weight:500;letter-spacing:.06em;text-transform:uppercase;border-bottom:1px solid var(--fg)}
.hs td{font-family:var(--mono);font-size:13.5px}
.hs td.l,.hs th.l{text-align:left}
.hs td.name{font-family:var(--body);font-weight:500;font-size:14px}
.hs td.id{color:var(--muted);font-size:12px}
.hs td.src{font-family:var(--body);font-size:12.5px;color:var(--muted);white-space:normal;min-width:180px;text-align:left}
.hs td.key{font-weight:500}
.hs tbody tr:hover{background:var(--hl)}
.hs .chip{display:inline-block;font:500 12px var(--mono);padding:1px 7px;border-radius:2px}
.hs .c148{color:var(--panel);background:var(--chip148)}
.hs .c157{color:var(--chip157-fg);background:var(--chip157-bg);border:1px solid var(--chip157-fg)}
.hs .none{color:var(--muted)}
.hs .sep td{border-top:2px solid var(--fg)}
.hs .notes{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:20px}
.hs .notes section{min-width:0}
.hs h2{font-family:var(--display);font-size:22px;margin:0 0 6px;letter-spacing:.01em;font-weight:700}
.hs .notes p,.hs .notes li{font-size:14px;max-width:65ch}
.hs .notes p{margin:0 0 10px}
.hs .notes ul{padding-left:18px;margin:0}
.hs code{font-family:var(--mono);font-size:.92em}
.hs .ok{font-weight:600}
.hs footer{font-size:12.5px;color:var(--muted);border-top:1px solid var(--rule);padding-top:12px}
`;

// Spoke bracing angle (deg) from the rim's center plane, using the same spoke
// geometry as wheel-physics-core's calc(): 3-cross, rim centroid radius
// R = ERD/2 + 11 mm, hub end on the flange pitch circle.
function bracingDeg(widthMm, flangeDiaMm, erdMm, spokes) {
  const R = erdMm / 2000 + 0.011;
  const dth = (2 * Math.PI) / (spokes / 2) * 3;
  const Rh = flangeDiaMm / 2000;
  const dv = R - Rh * Math.cos(dth);
  const dw = Rh * Math.sin(dth);
  return (Math.atan(widthMm / 1000 / Math.hypot(dv, dw)) * 180) / Math.PI;
}

function buildRows(erd, spokes) {
  const P = PHYS_CONSTANTS;
  const one = (h, std) => {
    const r = computeWheelStrength(erd, h, 2, 2, 100, P.EIL, P.EIR, P.GJ, P.EA_rim, spokes, P.modes);
    const src = HUB_SOURCES[h.id] || {};
    return {
      id: h.id, name: h.name, std,
      disc: /6-bolt/i.test(h.name) ? "6-bolt" : /centerlock/i.test(h.name) ? "Center Lock" : "",
      ds: h.ds, nds: h.nds, pds: h.pds, pnds: h.pnds,
      spacing: +(h.ds + h.nds).toFixed(2),
      midoff: (h.nds - h.ds) / 2,
      bDS: bracingDeg(h.ds, h.pds, erd, spokes),
      bNDS: bracingDeg(h.nds, h.pnds, erd, spokes),
      ratio: r.ratio,
      source: src.source || "Manufacturer spec (source file not recorded)",
      straightPull: !!src.straightPull,
    };
  };
  const byName = (a, b) => a.name.localeCompare(b.name);
  return [...HUBS_148.map(h => one(h, 148)).sort(byName), ...HUBS_157.map(h => one(h, 157)).sort(byName)];
}

const COLS = [
  { k: "id", t: "ID", cls: "l id" },
  { k: "name", t: "Hub", cls: "l name" },
  { k: "std", t: "Axle", cls: "l", fmt: o => <span className={"chip " + (o.std === 148 ? "c148" : "c157")}>{o.std}</span> },
  { k: "disc", t: "Disc mount", cls: "l", fmt: o => o.disc || <span className="none">not stated</span> },
  { k: "ds", t: "Drive side", cls: "key" },
  { k: "nds", t: "Non-drive side", cls: "key" },
  { k: "pds", t: "Drive side", cls: "key" },
  { k: "pnds", t: "Non-drive side", cls: "key" },
  { k: "spacing", t: "Flange spacing" },
  { k: "midoff", t: "Mid-flange offset", fmt: o => o.midoff.toFixed(2) },
  { k: "bDS", t: "DS bracing °", fmt: o => o.bDS.toFixed(2) },
  { k: "bNDS", t: "NDS bracing °", fmt: o => o.bNDS.toFixed(2) },
  { k: "ratio", t: "Tension balance %", fmt: o => o.ratio.toFixed(1) },
  { k: "src", t: "Source / spoke type", cls: "src", nosort: true,
    fmt: o => <>{o.source}{o.straightPull && <> · <b>straight-pull</b></>}</> },
];

function HubSpecsTab({ spokes, erd, rimLabel }) {
  const rows = se.useMemo(() => buildRows(erd, spokes), [erd, spokes]);
  const [filt, setFilt] = se.useState("all");
  const [sort, setSort] = se.useState({ k: null, dir: 1 });
  const n148 = HUBS_148.length, n157 = HUBS_157.length, total = n148 + n157;

  let shown = rows.filter(o => filt === "all" || String(o.std) === filt);
  if (sort.k) {
    shown = shown.slice().sort((a, b) => {
      const x = a[sort.k], y = b[sort.k];
      const v = typeof x === "number" ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true });
      return v * sort.dir;
    });
  }
  const clickSort = k => setSort(s => (s.k === k ? { k, dir: -s.dir } : { k, dir: 1 }));
  const nStraight = rows.filter(o => o.straightPull).length;

  return (
    <div className="hs">
      <style>{CSS}</style>
      <header>
        <div className="eyebrow">Wheel Strength Lab · shared hub catalogue</div>
        <h1>Rear Hub Spec Sheet</h1>
        <p className="lede">Flange geometry for all {total} rear hubs in the catalogue, {n148} on 148 Boost and {n157} on 157 Super Boost. These are the exact numbers the Lab and the 148 vs 157 widget feed into the wheel model.</p>
      </header>

      <div className="top">
        <ul className="facts">
          <li><b>{total}</b><span><span className="ok">Hubs, one list.</span> The Lab and the 148 vs 157 widget carry the same geometry for every hub, and the shared physics engine's validation list carries the same {total}.</span></li>
          <li><b>4</b><span>Measured numbers per hub: two center-to-flange distances and two flange diameters. Everything else in the table is worked out from those four.</span></li>
          <li><b>J-bend</b><span>All hubs except {nStraight === 2 ? "the two KOM Xeno" : "those marked"}, which are straight-pull. The model treats both the same way.</span></li>
          <li><b>Sort</b><span>Click any column heading to sort by it. Click again to reverse.</span></li>
        </ul>
        <figure>
          <svg viewBox="0 0 320 190" role="img" aria-label="Hub cross-section showing drive-side and non-drive-side center-to-flange distances and flange diameters">
            <line x1="160" y1="14" x2="160" y2="150" stroke="var(--muted)" strokeDasharray="4 3" />
            <text x="160" y="10" textAnchor="middle" fontSize="10" fill="var(--muted)" fontFamily="IBM Plex Mono, monospace">hub center</text>
            <rect x="20" y="88" width="280" height="12" fill="var(--rule)" />
            <rect x="95" y="60" width="8" height="68" fill="var(--fg)" />
            <rect x="196" y="46" width="8" height="96" fill="var(--fg)" />
            <line x1="99" y1="160" x2="160" y2="160" stroke="var(--accent)" strokeWidth="1.5" />
            <line x1="99" y1="154" x2="99" y2="166" stroke="var(--accent)" strokeWidth="1.5" />
            <text x="129" y="178" textAnchor="middle" fontSize="11" fill="var(--fg)" fontFamily="IBM Plex Mono, monospace">NDS c-to-f</text>
            <line x1="160" y1="160" x2="200" y2="160" stroke="var(--accent)" strokeWidth="1.5" strokeDasharray="5 3" />
            <line x1="200" y1="154" x2="200" y2="166" stroke="var(--accent)" strokeWidth="1.5" />
            <text x="166" y="178" textAnchor="start" fontSize="11" fill="var(--fg)" fontFamily="IBM Plex Mono, monospace">DS c-to-f</text>
            <line x1="80" y1="60" x2="80" y2="128" stroke="var(--fg)" strokeWidth="1" />
            <text x="74" y="98" textAnchor="end" fontSize="10" fill="var(--fg)" fontFamily="IBM Plex Mono, monospace">NDS ⌀</text>
            <line x1="218" y1="46" x2="218" y2="142" stroke="var(--fg)" strokeWidth="1" />
            <text x="224" y="98" fontSize="10" fill="var(--fg)" fontFamily="IBM Plex Mono, monospace">DS ⌀</text>
            <text x="24" y="80" fontSize="10" fill="var(--muted)" fontFamily="IBM Plex Sans, sans-serif">disc side</text>
            <text x="296" y="80" textAnchor="end" fontSize="10" fill="var(--muted)" fontFamily="IBM Plex Sans, sans-serif">cassette side</text>
          </svg>
          <figcaption>Schematic, not to scale. Rear view: the drive-side (DS) flange sits closer to center to make room for the cassette, which is what dishes a rear wheel. Flange diameter here is the spoke-hole circle.</figcaption>
        </figure>
      </div>

      <div className="controls" role="group" aria-label="Filter by axle standard">
        {[["all", `All ${total}`], ["148", "148 Boost"], ["157", "157 Super Boost"]].map(([f, label]) => (
          <button key={f} type="button" aria-pressed={filt === f} onClick={() => setFilt(f)}>{label}</button>
        ))}
        <span className="hint">Scroll the table sideways on a phone</span>
      </div>

      <div className="tablebox">
        <table aria-label="Hub specifications">
          <thead>
            <tr>
              <th className="grp l" colSpan={4}>Hub</th>
              <th className="grp" colSpan={2}>Center to flange (mm)</th>
              <th className="grp" colSpan={2}>Flange diameter (mm)</th>
              <th className="grp" colSpan={2}>Worked out (mm)</th>
              <th className="grp" colSpan={3}>At {rimLabel}, {spokes} spokes, 3-cross</th>
              <th className="grp l">Data</th>
            </tr>
            <tr>
              {COLS.map(c => {
                const left = c.cls && c.cls.split(" ").includes("l");
                if (c.nosort) return <th key={c.k} className="l">{c.t}</th>;
                const state = sort.k === c.k ? (sort.dir > 0 ? "ascending" : "descending") : "none";
                return (
                  <th key={c.k} className={left ? "l" : undefined} aria-sort={state}>
                    <button type="button" onClick={() => clickSort(c.k)}>{c.t}</button>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {shown.map((o, i) => {
              const sep = !sort.k && filt === "all" && i > 0 && shown[i - 1].std !== o.std;
              return (
                <tr key={o.id} className={sep ? "sep" : undefined}>
                  {COLS.map(c => <td key={c.k} className={c.cls || undefined}>{c.fmt ? c.fmt(o) : o[c.k]}</td>)}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="notes">
        <section>
          <h2>Reading the columns</h2>
          <ul>
            <li><b>Center to flange</b>: distance from the hub's center line to each flange. These two numbers set how dished the wheel is.</li>
            <li><b>Flange diameter</b>: diameter of the circle through the spoke holes (pitch circle diameter, PCD).</li>
            <li><b>Flange spacing</b>: DS plus NDS. Wider spacing gives a wider spoke triangle, which is the main source of lateral stiffness.</li>
            <li><b>Mid-flange offset</b>: how far the midpoint between the flanges sits toward the disc side. Bigger means more dish.</li>
            <li><b>Bracing angle</b>: the angle each spoke leans in from the rim's center plane. The drive side is always the shallower one.</li>
            <li><b>Tension balance</b>: non-drive spoke tension as a share of drive-side tension. Higher is more even. This is the same figure the TENSION BALANCE tab shows at zero rim offset.</li>
          </ul>
        </section>
        <section>
          <h2>Where the numbers come from</h2>
          <p>The four geometry numbers are the Lab's own hub list, the same one every other tab uses. They are manufacturer published specs. None were measured with calipers. Sources are named where the document was recorded; older entries were entered from manufacturer specs before source files were logged.</p>
          <p>Disc mount is filled in only where the hub's name states it. Some brands publish different flange diameters for 6-bolt and Center Lock versions of the same hub, so for the unlabelled rows, check the mount before relying on the numbers for a build.</p>
        </section>
        <section>
          <h2>Model method</h2>
          <p>Tension balance is computed with the shared physics engine, a port of Matthew Ford's Mode Matrix method (PhD thesis, Northwestern University, 2018) and his <code>bike-wheel-calc</code> library, which it matches to floating-point precision. Bracing angles use the same spoke geometry. The last three columns follow the Spokes and Rim settings above; rim offset is not applied here.</p>
        </section>
      </div>

      <footer>Wheel model math: Matthew T. Ford, <i>A Theoretical Analysis of the Bicycle Wheel</i> (PhD thesis, Northwestern University, 2018), Mode Matrix method, and <code>dashdotrobot/bike-wheel-calc</code> (MIT).</footer>
    </div>
  );
}

export default HubSpecsTab;
