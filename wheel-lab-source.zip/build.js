// Rebuilds the deployable single-file index.html from source.
// Usage: npm run build  (writes ./dist/index.html)
import * as esbuild from "esbuild";
import { mkdirSync, writeFileSync } from "node:fs";

const HTML_HEAD = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wheel Strength Lab — Post Millennium Renaissance</title>
  <meta name="description" content="148mm Boost vs. 157mm Super Boost hub comparison using Ford's Mode Matrix — across Compare, Simulation, and Deep Dive tabs.">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { background: #E8E6EA; }
    #root { min-height: 100vh; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script>
`;

const HTML_TAIL = `
  </script>
</body>
</html>
`;

async function build() {
  const result = await esbuild.build({
    entryPoints: ["src/index.jsx"],
    bundle: true,
    format: "iife",
    minify: true,
    target: ["es2020"],
    write: false,
    logLevel: "info",
  });

  const js = result.outputFiles[0].text;
  mkdirSync("dist", { recursive: true });
  writeFileSync("dist/index.html", HTML_HEAD + js + HTML_TAIL);
  console.log("Built dist/index.html (" + (js.length / 1024).toFixed(1) + " KB of JS)");
}

build().catch((err) => {
  console.error(err);
  process.exit(1);
});
